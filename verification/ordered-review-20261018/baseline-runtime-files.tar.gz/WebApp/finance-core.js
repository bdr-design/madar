(()=>{
'use strict';
const VERSION='3.1.0',TYPES=Object.freeze(['group','air','sea','road','power','bank','mobility']);
const clone=v=>globalThis.structuredClone?structuredClone(v):JSON.parse(JSON.stringify(v));
  const fleetData=()=>{const api=globalThis.GH_FLEET_DATA||(typeof require==='function'?require('./fleet-access-core.js'):null);if(!api)throw new Error('fleet-data-access-unavailable');return api;};
const num=v=>Math.max(0,Number(v)||0), now=s=>Number(s.simSeconds)||0;
// A row of a finance list that may be written here: the row itself, or, for a sealed final document (frozen, see
// FINAL_DOCUMENT), a mutable copy put in its place. Only migrations and identity refreshes rewrite documents this way.
function writableRow(list,index){const row=list[index];if(!row||typeof row!=='object'||!Object.isFrozen(row))return row;const copy=clone(row);list[index]=copy;invalidateFinanceLookupIndexes();return copy;}
let activeExecutionMeta=null,activeEnsureTarget=null,activeEnsureComplete=false;
let activeSettlementBatch=null;
const SETTLEMENT_COMMANDS=new Set(['settle-payable','issue-cheque','settle-cheque']);
function settlementBatchFor(s){const b=activeSettlementBatch;return b&&b.state===s&&globalThis.__GH_DURABLE_COMMAND_CONTEXT__===b.context&&b.context.draft===s&&s.finance===b.finance&&s.companyFinance===b.books&&s.treasury===b.treasury&&s.companyRegistry===b.registry&&s.openedCompanies===b.opened&&globalThis.GH_COMPANY_PLATFORM===b.platform?b:null;}
function invalidateSettlementBatch(s,domain,name){const b=activeSettlementBatch;if(b&&b.state===s&&!(domain==='finance'&&SETTLEMENT_COMMANDS.has(name))){b.ready=false;b.memo.clear();}}
async function withSettlementBatch(s,apply){
 if(typeof apply!=='function'||globalThis.__GH_DURABLE_COMMAND_CONTEXT__?.draft!==s||globalThis.__GH_DURABLE_COMMAND_CONTEXT__?.liveState===s)throw new Error('settlement-batch-requires-durable-draft');
 const previous=activeSettlementBatch;if(previous){if(previous.state!==s||previous.context!==globalThis.__GH_DURABLE_COMMAND_CONTEXT__)throw new Error('settlement-batch-overlap');return apply();}ensure(s);
 const b={state:s,context:globalThis.__GH_DURABLE_COMMAND_CONTEXT__,finance:s.finance,books:s.companyFinance,treasury:s.treasury,ready:true,memo:new Map(),companies:new Set(),ids:null,registry:s.companyRegistry,opened:s.openedCompanies,platform:globalThis.GH_COMPANY_PLATFORM};activeSettlementBatch=b;
 try{return await apply();}finally{b.memo.clear();activeSettlementBatch=previous;}
}
function setCurrentTransactionMemo(key,value){const b=activeSettlementBatch;if(b&&settlementBatchFor(b.state)&&b.ready){b.memo.set(key,value);return;}globalThis.GH_TRANSACTION_CORE?.transactionMemoSet?.(key,value);}

const collectionBatches=new WeakMap();
const COLLECTION_PROFILES=Object.freeze({
 group:{channel:'تحويل تحصيل عملاء المجموعة',source:'مركز تحصيل المجموعة · العملاء المعتمدون',service:'خدمات المجموعة'},
 air:{channel:'تسوية حجوزات وتذاكر وشحن جوي',source:'مركز تحصيل الطيران · وكلاء الحجز والعملاء',service:'تذاكر منفذة وشحن جوي وحجوزات شركات'},
 sea:{channel:'تحويلات فواتير شحن وبوالص بحرية',source:'مركز تحصيل الشحن البحري · الشاحنون ووكلاء الشحن',service:'حاويات وشحنات وعقود نقل بحري'},
 road:{channel:'تحصيل فواتير نقل بعد التسليم',source:'مركز تحصيل اللوجستيات · عملاء النقل والتوزيع',service:'أوامر نقل وتسليم وعقود توزيع'},
 power:{channel:'تسوية فواتير توريد الطاقة',source:'مركز تحصيل الطاقة · مشترو الطاقة والعملاء',service:'طاقة موردة وعقود شراء طاقة'},
 bank:{channel:'تحصيل فوائد ورسوم مصرفية',source:'مركز تحصيل البنك · المقترضون وعملاء الخدمات',service:'فوائد ورسوم خدمات؛ لا تشمل أصل القروض أو الودائع'},
 mobility:{channel:'تسوية نقاط البيع وبوابة الدفع',source:'مركز تحصيل التنقل · مدفوعات الركاب والعملاء',service:'رحلات مكتملة وحسابات تنقل الشركات'},
 insurance:{channel:'تحصيل أقساط التأمين',source:'مركز تحصيل التأمين · حملة الوثائق والوسطاء',service:'أقساط مكتسبة لوثائق المركبات والصحة والممتلكات والتأمين التجاري'},
 realestate:{channel:'تحصيل مبيعات الوحدات والإيجارات',source:'مركز تحصيل العقارات · المشترون والمستأجرون',service:'وحدات مسلّمة وإيجارات شهرية'},
 telecom:{channel:'تحصيل فواتير الاتصالات الشهرية',source:'مركز تحصيل الاتصالات · المشتركين وشرائح السوق',service:'اشتراكات الجوال والإنترنت وخدمات الأعمال'},
  dealership:{channel:'تحصيل فواتير مبيعات المركبات والصيانة',source:'مركز تحصيل الوكالات · العملاء وممولو المركبات',service:'مركبات مباعة ومخزون وخدمات ما بعد البيع'},
  hospitality:{channel:'تسوية حجوزات إقامة وخدمات مجمعة',source:'مركز تسوية حجوزات الفنادق والمنتجعات',service:'ليالي إقامة وخدمات منفذة؛ دورة تنتهي يوم 15'}
});
const GENERIC_COLLECTION_PROFILE=Object.freeze({channel:'تحويل تحصيل مؤسسي',source:'مركز تحصيل العملاء المعتمدين',service:'خدمات تشغيلية مثبتة'});
const COLLECTION_PROFILE_IDS=Object.freeze({
 'holding-revenue-v1':'group','aviation-revenue-v1':'air','marine-revenue-v1':'sea','logistics-revenue-v1':'road','energy-revenue-v1':'power','banking-revenue-v1':'bank','mobility-revenue-v1':'mobility','insurance-revenue-v1':'insurance','realestate-revenue-v1':'realestate'
 ,'telecom-revenue-v1':'telecom','dealership-revenue-v1':'dealership','hospitality-revenue-v1':'hospitality'
});
function collectionProfile(company,s=null){
 const platform=globalThis.GH_COMPANY_PLATFORM,definition=s?platform?.resolveCompany?.(s,company)?.definition:platform?.getDefinition?.(company),profileId=definition?.finance?.collectionProfileId,legacyId=COLLECTION_PROFILE_IDS[profileId];
 return COLLECTION_PROFILES[legacyId||company]||GENERIC_COLLECTION_PROFILE;
}
function platformInstances(s,options={}){const platform=globalThis.GH_COMPANY_PLATFORM;if(!platform?.listInstances)return null;const rows=platform.listInstances(s,{includeGroup:options.includeGroup!==false,openedOnly:false,capability:'finance.book'});if(!Array.isArray(rows))throw new Error('company-platform-invalid-list');return rows.filter(row=>row?.id==='group'||row?.registered===true||row?.opened===true);}
function supportsCompany(s,value,options={}){
 const id=String(value||'').trim();if(!id)return false;const platform=globalThis.GH_COMPANY_PLATFORM;
 if(platform?.resolveCompany){const company=platform.resolveCompany(s,id);if(!company?.known||!company.definition?.capabilities?.includes('finance.book'))return false;if(options.operational===true&&!company.operational)return false;return id==='group'||company.registered||company.opened;}
 return TYPES.includes(id);
}
function companyIdsReference(s,options={}){
 const rows=platformInstances(s,options);if(rows){const ids=rows.map(row=>String(row?.id||row?.record?.id||'')).filter(Boolean).filter(id=>id!=='group');for(const id of Object.keys(s?.companyFinance||{}))if(id!=='group'&&supportsCompany(s,id)&&!ids.includes(id))ids.push(id);if(options.includeGroup!==false)ids.unshift('group');return [...new Set(ids)];}
 return TYPES.filter(id=>options.includeGroup!==false||id!=='group');
}
function companyIds(s,options={}){const batch=settlementBatchFor(s);if(!batch?.ready)return companyIdsReference(s,options);if(!batch.ids)batch.ids=companyIdsReference(s);return options.includeGroup===false?batch.ids.filter(id=>id!=='group'):batch.ids.slice();}
function requireCompany(s,value,options={}){const raw=value==null||String(value).trim()===''?(options.defaultGroup===false?'': 'group'):String(value).trim();if(!raw)throw new Error('company-id-required');const platform=globalThis.GH_COMPANY_PLATFORM;if(platform?.requireCompany){const batch=settlementBatchFor(s),key=`${options.operational===true?'o':'r'}:${raw}`;if(batch?.ready&&batch.companies.has(key))return raw;platform.requireCompany(s,raw,{registered:true,operational:options.operational===true,capability:'finance.book'});if(batch?.ready)batch.companies.add(key);return raw;}if(!TYPES.includes(raw))throw new Error(`company-not-found:${raw}`);return raw;}
function inactiveLegacyCompanyKey(s,id){
 const platform=globalThis.GH_COMPANY_PLATFORM,definition=platform?.getDefinition?.(id);
 return Boolean(definition?.capabilities?.includes('finance.book')&&!supportsCompany(s,id));
}
function metricNumber(value,label,id){
 if(value===null||typeof value==='boolean'||(typeof value==='string'&&!value.trim()))throw new Error(`finance-${label}-value-invalid:${id}`);
 const result=Number(value);if(!Number.isFinite(result))throw new Error(`finance-${label}-value-invalid:${id}`);return result;
}
// Finance accumulators are keyed by company *instance id*, never by an asset,
// route, or sector mode.  This is what lets two companies share an operational
// profile without sharing a book or a daily settlement bucket.
function companyMetricMap(s,source={},label='company-metric',options={}){
 const ids=companyIds(s,{includeGroup:false}),allowed=new Set(ids),result=Object.fromEntries(ids.map(id=>[id,0]));
 if(source==null)return result;if(typeof source!=='object'||Array.isArray(source))throw new Error(`finance-${label}-map-invalid`);
 for(const [id,raw] of Object.entries(source)){
  const value=metricNumber(raw,label,id);
  if(!allowed.has(id)){
   // Build 332/333 persisted all six built-in keys even when a company was not
   // founded.  Zero placeholders are safe to discard; any non-zero orphan is a
   // loss-of-ownership ambiguity and must stop the transaction.
   if(value===0&&inactiveLegacyCompanyKey(s,id)){if(options.preserveLegacyZero===true)result[id]=0;continue;}
   throw new Error(`finance-${label}-company-unknown:${id}`);
  }
  if(options.nonNegative===true&&value<0)throw new Error(`finance-${label}-value-negative:${id}`);
  if(options.integer===true&&(!Number.isSafeInteger(value)||value<0))throw new Error(`finance-${label}-value-not-integer:${id}`);
  result[id]=value;
 }
 return result;
}
function documentProfile(s,t){const platform=globalThis.GH_COMPANY_PLATFORM;if(platform?.resolveDocumentProfile)return platform.resolveDocumentProfile(s,t);const registry=t==='group'?(s.profile||s.companyRegistry?.group||{}):(s.companyRegistry?.[t]||{});return {legalName:registry.legalName||registry.name||(t==='group'?s.profile?.name:null),documentPrefix:registry.documentPrefix||registry.finance?.documentPrefix||(t==='group'?'GH':t.toUpperCase()),accountPrefix:registry.accountPrefix||registry.finance?.accountPrefix||(t==='group'?'GH':t.toUpperCase())};}
function bindSystemDocument(s,document,record,companyId){
 const proofOwner=globalThis.GH_DOCUMENT_PROOF,system=activeExecutionMeta?.systemAuthorized===true&&!globalThis.GH_DOMAIN_COMMANDS?.hasActivePlayerApproval?.();if(!system)return record;
 const authorization=globalThis.GH_AUTHORIZATION,principalId=String(activeExecutionMeta?.authority?.principalId||'').trim(),context=principalId?authorization?.findDelegatedAuthorization?.(s,{domain:'finance',name:activeExecutionMeta.name||'document',companyId,principalId,payload:{documentId:record.documentId,documentType:record.documentType,contentDigest:record.contentDigest}}):null;
 if(context){const proof=authorization.issueProof(s,context,{commandId:activeExecutionMeta.id||record.id,transactionId:globalThis.__GH_DURABLE_COMMAND_CONTEXT__?.transactionId||activeExecutionMeta.id||record.id,documentIds:[record.documentId],documentDigests:[record.contentDigest]});proofOwner.bindAuthorization(s,[{proofId:record.id,documentId:record.documentId,digest:record.contentDigest,document}],proof);}return record;
}
function protectDocument(s,document,type){
 const proofOwner=globalThis.GH_DOCUMENT_PROOF;if(!proofOwner?.sealDocument)return document;const companyId=document.company||document.companyId||'group',system=activeExecutionMeta?.systemAuthorized===true&&!globalThis.GH_DOMAIN_COMMANDS?.hasActivePlayerApproval?.(),record=proofOwner.sealDocument(s,document,{type,companyId,authorizationKind:system?'system-unsealed':'pending-approval'});return bindSystemDocument(s,document,record,companyId);
}
function amendProtectedDocument(s,document,type,transition,mutate){
 const proofOwner=globalThis.GH_DOCUMENT_PROOF;if(!proofOwner?.amendDocument){mutate(document);return null;}if(!document.documentProofId)protectDocument(s,document,type);const companyId=document.company||document.companyId||'group',system=activeExecutionMeta?.systemAuthorized===true&&!globalThis.GH_DOMAIN_COMMANDS?.hasActivePlayerApproval?.(),out=proofOwner.amendDocument(s,document,{transition,mutate,authorizationKind:system?'system-unsealed':'pending-approval'});return bindSystemDocument(s,document,out.record,companyId);
}
function recordCollection(s,{company,amount,reference,invoiceNumbers=[],counterparty='',channel='',grossAmount=amount,deductions=0,sourceRefs=[],purposeCategory='تحصيل إيراد',purposeDetail='',paymentMethod='تحويل/تسوية مصرفية',chequeNumber=null,accountBalanceBefore=null,accountBalanceAfter=null}){
 const profile=collectionProfile(company,s),account=book(s,company).accounts[0],sender=partyMeta(s,counterparty||profile.source,'customer'),detail=String(purposeDetail||profile.service),row={id:reference,reference,at:now(s),company,beneficiaryCompany:company,from:sender.name||counterparty||profile.source,fromPartyId:sender.id,to:account.id,toAccount:account.id,amount,grossAmount,deductions,netAmount:amount,invoiceNumbers:[...invoiceNumbers],sourceRefs:sourceRefs.slice(0,80).map(String),channel:channel||profile.channel,service:profile.service,purposeCategory:String(purposeCategory||'تحصيل إيراد'),purposeDetail:detail,paymentMethod:String(paymentMethod||'تحويل/تسوية مصرفية'),kind:'revenue-collection',collection:true,label:chequeNumber?'تحصيل شيك وارد':'حوالة تحصيل إيراد',status:'منفذة',note:`تحصيل ${invoiceNumbers.join(' · ')} · ${detail}`};if(chequeNumber)row.chequeNumber=String(chequeNumber);
 if(Number.isFinite(Number(accountBalanceBefore)))row.accountBalanceBefore=Number(accountBalanceBefore);if(Number.isFinite(Number(accountBalanceAfter)))row.accountBalanceAfter=Number(accountBalanceAfter);
 protectDocument(s,row,'revenue-collection');insertFinanceTransfer(s,row);ledger(s,company,row);recordWorldFinance(s,{partyId:sender.id,counterparty:row.from,company,direction:'incoming',amount,reference,transferRef:reference,documentNumber:invoiceNumbers[0]||null,note:row.note,settled:true});return row;
}
function companyName(s,t){t=requireCompany(s,t);return globalThis.GH_COMPANY_PLATFORM?.resolveIdentity?.(s,t)?.legalName||globalThis.GH_IDENTITY?.legalName?.(s,t)||documentProfile(s,t).legalName||(t==='group'?(s.profile?.name||'المجموعة'):(s.companyRegistry?.[t]?.legalName||({air:'الطيران',sea:'الشحن البحري',road:'النقل البري',power:'الطاقة',bank:'البنك',mobility:'التنقل الذكي'}[t]||t)));}
function cashPoolEligible(s,t){const definition=globalThis.GH_COMPANY_PLATFORM?.resolveCompany?.(s,t)?.definition;return definition?.finance?.cashPoolEligible!==false;}
const GENERIC_PARTY_NAMES=new Set(['طرف تعاقدي','طرف تعاقدي مسجل','عميل تعاقدي','عميل تعاقدي مسجل','جهة تمويل','مستفيد غير محدد','طرف خارجي']);
function formalCounterparty(s,company,kind,name=''){const value=String(name||'').trim();if(value&&!GENERIC_PARTY_NAMES.has(value))return value;const legal=companyName(s,requireCompany(s,company));return kind==='دخل'?`حساب العملاء المعتمدين — ${legal}`:`حساب الموردين المعتمدين — ${legal}`;}
function partyMeta(s,name,role='counterparty'){const W=globalThis.GH_BUSINESS_WORLD,id=W?.partyIdForName?.(s,name,role)||null,party=id?W?.resolveParty?.(s,id):null;return {id,name:party?.legalName||party?.displayName||String(name||'')};}
function migrateFormalParties(s){if(Number(s.finance.formalPartyMigrationVersion)>=1)return;const invoices=s.finance.invoices||[];for(let index=0;index<invoices.length;index++){const doc=invoices[index];if(doc.documentProofId)continue;const t=requireCompany(s,doc.company),counterparty=formalCounterparty(s,t,doc.kind,doc.counterparty);if(doc.counterparty!==counterparty)writableRow(invoices,index).counterparty=counterparty;}for(const bucket of [s.finance.payables||[],s.finance.receivables||[]])for(const doc of bucket){if(doc.documentProofId)continue;const t=requireCompany(s,doc.company),kind=invoices.find(x=>x.number===doc.number)?.kind||(bucket===s.finance.receivables?'دخل':'مصروف');doc.counterparty=formalCounterparty(s,t,kind,doc.counterparty);}const cheques=s.finance.cheques||[];for(let index=0;index<cheques.length;index++){const cheque=cheques[index];if(cheque.documentProofId)continue;const t=requireCompany(s,cheque.company),linked=invoices.find(x=>x.number===cheque.invoiceNumber),beneficiary=formalCounterparty(s,t,'مصروف',cheque.beneficiary||linked?.counterparty);if(cheque.beneficiary!==beneficiary)writableRow(cheques,index).beneficiary=beneficiary;}s.finance.formalPartyMigrationVersion=1;}
// A financing document is the signed contract at origination, not a mutable running balance. Build 358 used to amend
// that protected document on every principal payment; a long-lived energy loan therefore exhausted the 64-link proof
// chain and stopped the financial day. Current principal lives in this bounded operational register, while every
// movement remains evidenced by its journal, transfer and protected debt-settlement document.
function debtRecord(s,rowOrId){if(rowOrId&&typeof rowOrId==='object')return rowOrId;const id=String(rowOrId||'');return (s.finance?.debtRecords||[]).find(row=>row?.id===id)||null;}
function debtOutstanding(s,rowOrId){const row=debtRecord(s,rowOrId);if(!row)return 0;const entry=s.finance?.debtBalancesById?.[row.id];return num(entry&&typeof entry==='object'?entry.outstanding:row.outstanding);}
function debtStatus(s,rowOrId){const row=debtRecord(s,rowOrId);if(!row)return 'غير موجود';const outstanding=debtOutstanding(s,row);if(outstanding<=.005)return 'مسدد';const entry=s.finance?.debtBalancesById?.[row.id];return String(entry?.status||(outstanding+0.005<num(row.originalAmount)?'مسدد جزئيًا':row.status||'قائم'));}
function setDebtOutstanding(s,rowOrId,value,at=now(s)){const row=debtRecord(s,rowOrId);if(!row)throw new Error(`debt-record-not-found:${String(rowOrId||'')}`);s.finance.debtBalancesById=s.finance.debtBalancesById&&typeof s.finance.debtBalancesById==='object'&&!Array.isArray(s.finance.debtBalancesById)?s.finance.debtBalancesById:{};const outstanding=Math.max(0,num(value)),entry=s.finance.debtBalancesById[row.id]&&typeof s.finance.debtBalancesById[row.id]==='object'?s.finance.debtBalancesById[row.id]:{};entry.outstanding=outstanding;entry.status=outstanding<=.005?'مسدد':outstanding+0.005<num(row.originalAmount)?'مسدد جزئيًا':'قائم';entry.lastMovementAt=num(at);s.finance.debtBalancesById[row.id]=entry;return entry;}
function ensureDebtBalances(s){let balances=s.finance.debtBalancesById;if(!balances||typeof balances!=='object'||Array.isArray(balances))balances={};s.finance.debtBalancesById=balances;const live=new Set();for(const row of s.finance.debtRecords||[]){const id=String(row?.id||'');if(!id)continue;live.add(id);const current=balances[id];if(!current||typeof current!=='object'||Array.isArray(current)||!Number.isFinite(Number(current.outstanding)))setDebtOutstanding(s,row,num(row.outstanding),row.lastPaymentAt??row.issuedAt??now(s));else{current.outstanding=Math.max(0,num(current.outstanding));current.status=current.outstanding<=.005?'مسدد':current.outstanding+0.005<num(row.originalAmount)?'مسدد جزئيًا':String(current.status||row.status||'قائم');current.lastMovementAt=num(current.lastMovementAt);}}for(const id of Object.keys(balances))if(!live.has(id))delete balances[id];s.finance.debtBalanceMigrationVersion=1;return balances;}
function debtView(s,rowOrId){const row=debtRecord(s,rowOrId);if(!row)return null;const entry=s.finance?.debtBalancesById?.[row.id];return {...row,outstanding:debtOutstanding(s,row),status:debtStatus(s,row),...(entry?.lastMovementAt?{lastPaymentAt:entry.lastMovementAt}:{})};}
function adjustDebtOutstanding(s,rowOrId,delta,p={}){ensure(s);const row=debtRecord(s,rowOrId);if(!row)throw new Error(`debt-record-not-found:${String(rowOrId||'')}`);const before=debtOutstanding(s,row),after=Math.max(0,before+Number(delta||0));setDebtOutstanding(s,row,after,p.at??now(s));return {debtId:row.id,before,after,delta:after-before};}
// One-time cross-ledger migration used by Energy Core. It makes each project facility authoritative for its matching
// debt id, then redistributes the unchanged company book total over any other debts. No signed contract is rewritten.
function reconcileDebtBalances(s,p={}){ensure(s);const company=requireCompany(s,p.company),preferred=p.balancesById&&typeof p.balancesById==='object'&&!Array.isArray(p.balancesById)?p.balancesById:{},rows=(s.finance.debtRecords||[]).filter(row=>row.company===company),byId=new Map(rows.map(row=>[row.id,row])),fixed=[];for(const [id,value] of Object.entries(preferred)){const row=byId.get(id);if(row)fixed.push([row,Math.max(0,num(value))]);}const fixedIds=new Set(fixed.map(([row])=>row.id)),others=rows.filter(row=>!fixedIds.has(row.id)),target=Math.max(0,num(book(s,company).debt)),fixedTotal=fixed.reduce((sum,[,value])=>sum+value,0),effectiveFixed=fixedTotal>target+.01&&fixedTotal>0?fixed.map(([row,value])=>[row,value*target/fixedTotal]):fixed,used=effectiveFixed.reduce((sum,[,value])=>sum+value,0),remaining=Math.max(0,target-used),otherTotal=others.reduce((sum,row)=>sum+debtOutstanding(s,row),0);for(const [row,value] of effectiveFixed)setDebtOutstanding(s,row,value);if(others.length){if(otherTotal>.005)for(const row of others)setDebtOutstanding(s,row,debtOutstanding(s,row)*remaining/otherTotal);else{for(const row of others)setDebtOutstanding(s,row,0);setDebtOutstanding(s,others[0],remaining);}}return {company,target,fixed:effectiveFixed.length,others:others.length,reconciled:Math.abs(fixedTotal-effectiveFixed.reduce((sum,[,value])=>sum+value,0))<=.01};}
function backfillDebtRegister(s){if(Number(s.finance.debtRegisterMigrationVersion)>=2)return;for(const t of companyIds(s)){const b=s.companyFinance?.[t],debt=num(b?.debt),registered=(s.finance.debtRecords||[]).filter(x=>x.company===t&&debtOutstanding(s,x)>.005).reduce((n,x)=>n+debtOutstanding(s,x),0),gap=Math.max(0,debt-registered);if(gap>.01)s.finance.debtRecords.unshift({id:`DEBT-CARRY-${t}-B326`,company:t,companyName:companyName(s,t),lender:`رصيد تمويل مرحّل — ${companyName(s,t)}`,type:'رصيد دين مرحّل',liabilityAccount:'التزامات تمويلية مرحّلة',originalAmount:gap,outstanding:gap,issuedAt:now(s),dueDay:null,status:'قائم',legacy:true});}s.finance.debtRegisterMigrationVersion=2;}
function recordWorldFinance(s,p){try{return globalThis.GH_BUSINESS_WORLD?.execute?.({state:s},'record-finance',p)||null;}catch(error){console.warn('business-world finance bridge rejected',error);return null;}}
function makeBook(s,t,balance=0){t=requireCompany(s,t);const c=String(documentProfile(s,t).accountPrefix||t).toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,18)||'CO';return {type:t,companyId:t,accounts:[{id:`${c}-OPER-001`,name:'الحساب الجاري',currency:'USD',balance:num(balance)},{id:`${c}-RES-002`,name:'حساب الاحتياطي',currency:'USD',balance:0}],ledger:[],taxPayable:0,taxPaid:0,vat:{output:0,input:0,creditCarry:0,periodOutputStart:0,periodInputStart:0},debt:0,lastReconciledAt:now(s)};}
function isZeroFinancePlaceholder(book){
 if(!book||typeof book!=='object'||Array.isArray(book))return false;
 const accounts=Array.isArray(book.accounts)?book.accounts:[];
 const numeric=[...accounts.map(row=>row?.balance),book.taxPayable,book.taxPaid,book.taxAccrued,book.debt,...Object.values(book.vat&&typeof book.vat==='object'?book.vat:{})];
 if(numeric.some(value=>value!==undefined&&value!==null&&(!Number.isFinite(Number(value))||Math.abs(Number(value))>.000001)))return false;
 return accounts.length>0&&(!Array.isArray(book.ledger)||book.ledger.length===0)&&(!Array.isArray(book.auditTrail)||book.auditTrail.length===0);
}
function pruneOrphanFinanceBooks(s){
 const books=s.companyFinance&&typeof s.companyFinance==='object'&&!Array.isArray(s.companyFinance)?s.companyFinance:null;if(!books)return;
 const active=new Set((platformInstances(s)||[]).map(row=>String(row?.id||'')).filter(Boolean));
 for(const id of Object.keys(books)){
  if(active.has(id))continue;
  // Build 332/333 persisted zero placeholders for unfounded built-in sectors.
  // They are safe to discard; any non-zero or recorded orphan is a hard stop.
  if(isZeroFinancePlaceholder(books[id])){delete books[id];continue;}
  throw new Error(`finance-company-orphan:${id}`);
 }
}
// The legacy first-book allocation is a one-time load migration.  It used to
// call fleet.count once for every opened company, so C companies caused C full
// fleet passes (and C sets of row views) before the first frame.  Ownership is
// determined from these five fields only; aggregate their exact row classes in
// one pass and reuse the totals for every company.
function fleetOwnerCounts(s){
 const fleet=fleetData(),counts=new Map(),owner=a=>String(a?.ownerCompanyId||a?.companyId||a?.company||globalThis.GH_COMPANY_PLATFORM?.ownerForLegacyAssetMode?.(a?.assetMode||a?.type)||'');
 fleet.forEachFieldClasses(s,['ownerCompanyId','companyId','company','assetMode','type'],(row,count)=>{if(!count)return;const id=owner(row);counts.set(id,(counts.get(id)||0)+count);});
 return counts;
}
function ensure(s){
 if(activeEnsureTarget===s&&activeEnsureComplete||settlementBatchFor(s)?.ready)return s.companyFinance;
 s.finance=s.finance&&typeof s.finance==='object'?s.finance:{};for(const k of ['invoices','payables','receivables','cheques','periods','journalEntries','transfers','payrollReports','dailyCompanyReports','taxSettlements','debtRecords','debtSettlements','intercompanyLoans','intercompanyLoanSettlements','cashPoolSweeps','commercialContracts','customerLoanPaymentReceipts','customerFinancingReceipts','customerSalePaymentReceipts','customerSaleCreditNotes','hospitalityDocuments'])s.finance[k]=Array.isArray(s.finance[k])?s.finance[k]:[];
 s.finance.pendingDailyCash=companyMetricMap(s,s.finance.pendingDailyCash,'pending-daily-cash',{preserveLegacyZero:true});
 s.finance.debtInterestDays=s.finance.debtInterestDays&&typeof s.finance.debtInterestDays==='object'&&!Array.isArray(s.finance.debtInterestDays)?s.finance.debtInterestDays:{};
 s.sectorProfitToday=companyMetricMap(s,s.sectorProfitToday,'sector-profit-today',{preserveLegacyZero:true});
 s.tripProfitAccrued=companyMetricMap(s,s.tripProfitAccrued,'trip-profit');
 s.tripRevenueAccrued=companyMetricMap(s,s.tripRevenueAccrued,'trip-revenue',{nonNegative:true});
 s.tripFuelAccrued=companyMetricMap(s,s.tripFuelAccrued,'trip-fuel',{nonNegative:true});
 s.tripMaintenanceAccrued=companyMetricMap(s,s.tripMaintenanceAccrued,'trip-maintenance',{nonNegative:true});
 s.tripCountAccrued=companyMetricMap(s,s.tripCountAccrued,'trip-count',{integer:true});
 if(s.lastClosedSectorProfit!==undefined)s.lastClosedSectorProfit=companyMetricMap(s,s.lastClosedSectorProfit,'last-closed-sector-profit');
 s.finance.paymentSequence=Math.max(1,Math.floor(Number(s.finance.paymentSequence)||1));s.finance.invoiceSequence=Math.max(1,Math.floor(Number(s.finance.invoiceSequence)||1));s.finance.taxSettlementSequence=Math.max(1,Math.floor(Number(s.finance.taxSettlementSequence)||1));s.finance.debtSettlementSequence=Math.max(1,Math.floor(Number(s.finance.debtSettlementSequence)||1));
 if(!Number.isSafeInteger(Number(s.finance.journalSequence))||Number(s.finance.journalSequence)<0){const archived=s.finance.auditArchive?.records?.journalEntries,rows=[...s.finance.journalEntries,...(Array.isArray(archived)?archived:[])],digestMax=(s.finance.auditArchive?.digests||[]).filter(d=>d?.kind==='journalEntries').reduce((max,d)=>Math.max(max,Number(d?.maxSequence)||0),0);s.finance.journalSequence=Math.max(digestMax,rows.reduce((max,row)=>{const match=/^JE-(\d+)$/.exec(String(row?.id||''));return match?Math.max(max,Number(match[1])||0):max;},0));}else s.finance.journalSequence=Math.floor(Number(s.finance.journalSequence));
 s.treasury=s.treasury&&typeof s.treasury==='object'?s.treasury:{accounts:[],ledger:[],paymentQueue:[]};s.treasury.accounts=Array.isArray(s.treasury.accounts)?s.treasury.accounts:[];s.treasury.ledger=Array.isArray(s.treasury.ledger)?s.treasury.ledger:[];
 while(s.treasury.accounts.length<3){const i=s.treasury.accounts.length;s.treasury.accounts.push({id:['GH-OPER-001','GH-RES-002','GH-INV-003'][i],name:['الحساب الجاري','حساب الاحتياطي','الاستثمارات'][i],currency:'USD',balance:0});}
 const had=s.companyFinance&&typeof s.companyFinance==='object'&&!Array.isArray(s.companyFinance)&&Object.keys(s.companyFinance).length>0;s.companyFinance=had?s.companyFinance:{};
 const ids=companyIds(s);
 s.companyFinance.group=s.companyFinance.group||makeBook(s,'group');s.companyFinance.group.accounts=s.treasury.accounts;
 for(const t of ids){if(!s.companyFinance[t])s.companyFinance[t]=makeBook(s,t);const b=s.companyFinance[t];b.type=t;b.companyId=t;b.accounts=Array.isArray(b.accounts)&&b.accounts.length?b.accounts:makeBook(s,t).accounts;b.ledger=Array.isArray(b.ledger)?b.ledger:[];for(const a of b.accounts)a.balance=Number.isFinite(Number(a.balance))?Number(a.balance):0;b.taxPayable=Number.isFinite(Number(b.taxPayable))?Number(b.taxPayable):0;b.taxPaid=Number.isFinite(Number(b.taxPaid))?Number(b.taxPaid):0;b.debt=Number.isFinite(Number(b.debt))?Number(b.debt):0;b.vat=b.vat&&typeof b.vat==='object'?b.vat:{};for(const k of ['output','input','creditCarry','periodOutputStart','periodInputStart'])b.vat[k]=Number.isFinite(Number(b.vat[k]))?Number(b.vat[k]):0;}
 for(const id of Object.keys(s.companyFinance))if(!ids.includes(id)&&!isZeroFinancePlaceholder(s.companyFinance[id]))throw new Error(`finance-company-unknown:${id}`);
 s.companyFinance.group.accounts=s.treasury.accounts;
 migrateFormalParties(s);backfillDebtRegister(s);ensureDebtBalances(s);
 if(!had&&(s.openedCompanies||[]).length){const opened=s.openedCompanies.map(t=>requireCompany(s,t)).filter(t=>t!=='group'),src=s.treasury.accounts[0],pool=num(src.balance)*.55,ownerCounts=fleetOwnerCounts(s),weights=opened.map(t=>[t,Math.max(1,(ownerCounts.get(t)||0)*2+1)]),sw=weights.reduce((n,x)=>n+x[1],0)||1;let alloc=0;weights.forEach(([t,x],i)=>{const a=i===weights.length-1?Math.max(0,pool-alloc):Math.floor(pool*x/sw);s.companyFinance[t].accounts[0].balance=a;alloc+=a;});src.balance=Math.max(0,num(src.balance)-alloc);}
 s.companyBudgets=s.companyBudgets&&typeof s.companyBudgets==='object'&&!Array.isArray(s.companyBudgets)?s.companyBudgets:{};
 s.finance.centralTreasury=s.finance.centralTreasury&&typeof s.finance.centralTreasury==='object'&&!Array.isArray(s.finance.centralTreasury)?s.finance.centralTreasury:{};const ct=s.finance.centralTreasury;ct.minOperatingCash=ct.minOperatingCash&&typeof ct.minOperatingCash==='object'&&!Array.isArray(ct.minOperatingCash)?ct.minOperatingCash:{};for(const t of ids.filter(x=>x!=='group'))ct.minOperatingCash[t]=num(ct.minOperatingCash[t]);ct.lastPolicyAt=num(ct.lastPolicyAt);ct.lastSweepAt=num(ct.lastSweepAt);backfillPayrollTransfers(s);reconcile(s);return s.companyFinance;
}
// Historical position is not an idempotency boundary. The same owner searches
// the live register first, then full archive records without duplicating writes.
// Build 359 (a million assets): the archive part reads an index of each archived collection by field (built once per
// collection array: the archive's collections are sealed, replaced whole when rows join or leave), so a lookup no longer
// walks every archived row. `fields` is one field or several (a row matching any); `accept` narrows the match.
const ARCHIVE_FIELD_INDEX=new WeakMap();
function archivedCollection(s,bucket){const list=s.finance?.auditArchive?.records?.[bucket==='periods'?'taxPeriods':bucket];return Array.isArray(list)?list:null;}
function findColdArchivedDocument(s,bucket,fields,value,accept=null){
 const kind=bucket==='periods'?'taxPeriods':bucket,pages=Array.isArray(s?.coldArchive?.pages)?s.coldArchive.pages:[],codec=globalThis.GH_STATE_CODEC,keys=Array.isArray(fields)?fields:[fields];if(typeof codec?.coldArchiveRows!=='function')return undefined;
 // Newest page first. Materialized rows are intentionally not cached: a historical lookup may cost I/O/decoding work,
 // but it cannot turn years of cold finance history back into permanent live heap.
 for(let pageAt=pages.length-1;pageAt>=0;pageAt--){const page=pages[pageAt];if(page?.kind!==kind)continue;let rows;try{rows=codec.coldArchiveRows(page);}catch{continue;}for(let at=rows.length-1;at>=0;at--){const row=rows[at];if(row&&keys.some(field=>row[field]===value)&&(!accept||accept(row)))return row;}}
 return undefined;
}
function archivedPositions(list,field,value){
 let indexes=ARCHIVE_FIELD_INDEX.get(list);if(!indexes||indexes.length!==list.length){indexes={length:list.length,byField:new Map()};ARCHIVE_FIELD_INDEX.set(list,indexes);}
 let index=indexes.byField.get(field);if(!index){index=new Map();for(let at=0;at<list.length;at++){const key=list[at]?.[field];if(key===undefined||key===null)continue;const rows=index.get(key);if(rows)rows.push(at);else index.set(key,[at]);}indexes.byField.set(field,index);}
 return index.get(value)||[];
}
function findArchivedDocument(s,bucket,fields,value,accept=null){
 const list=archivedCollection(s,bucket);let best=Infinity;
 if(list)for(const field of Array.isArray(fields)?fields:[fields])for(const at of archivedPositions(list,field,value)){if(at>=best)break;if(list[at]?.[field]===value&&(!accept||accept(list[at])))best=at;}
 return best===Infinity?findColdArchivedDocument(s,bucket,fields,value,accept):list[best];
}
function findFinanceDocument(s,bucket,fields,value,accept=null){
 const live=Array.isArray(s.finance?.[bucket])?s.finance[bucket]:[],keys=Array.isArray(fields)?fields:[fields];
 // Keep only command-local indexes. Predicates still read the current document's status.
 const indexedField=keys.length===1&&(bucket==='cheques'&&['id','requestRef','invoiceNumber'].includes(keys[0])||bucket==='invoices'&&keys[0]==='number'||bucket==='periods'&&keys[0]==='id');
 if(indexedField){
  // A lone cheque settlement keeps its short linear lookup. Allocate a full cheque index only when the same
  // transaction asks again (issue + pay + retry), or already needed the linked-cheque index.
  const tx=globalThis.GH_TRANSACTION_CORE,key=FINANCE_LIST_INDEX_MEMO_PREFIX+bucket,seenKey=key+':lookups',seen=currentTransactionMemo(seenKey)||0;
  if(tx?.isActive?.()||settlementBatchFor(s)?.ready)setCurrentTransactionMemo(seenKey,seen+1);
  const field=keys[0],index=bucket!=='cheques'||seen>0||currentTransactionMemo(key)?financeListIndex(s,bucket):null,matches=index?.byField?.get(field)?.get(value);
  if(index?.byField?.has(field))return matches?.find(row=>!accept||accept(row))||findArchivedDocument(s,bucket,keys,value,accept);
 }
 for(const row of live)if(row&&keys.some(field=>row[field]===value)&&(!accept||accept(row)))return row;
 return findArchivedDocument(s,bucket,keys,value,accept);
}
function hasFinanceDocument(s,bucket,fields,value,accept=null){return !!findFinanceDocument(s,bucket,fields,value,accept);}
const TRANSFER_INDEX_MEMO_KEY='finance.transfer-lookup-index/v1';
const FINANCE_LIST_INDEX_MEMO_PREFIX='finance.list-number-index/v1:';
const DUE_TERMS_INDEX_MEMO_PREFIX='finance.due-terms-index/v1:';
function currentTransactionMemo(key){const b=activeSettlementBatch;if(b&&settlementBatchFor(b.state)&&b.ready)return b.memo.get(key);const tx=globalThis.GH_TRANSACTION_CORE;if(!tx?.isActive?.())return undefined;return tx.transactionMemoGet?.(key);}
function rankLookup(map,key,row,rank){if(key==null)return;const current=map.get(key);if(!current||rank<current.rank)map.set(key,{row,rank});}
function addTransferIndexRow(index,row,rank){rankLookup(index.byReference,row?.reference,row,rank);rankLookup(index.byId,row?.id,row,rank);if(row?.documentNumber&&['payroll-payable','payroll-transfer'].includes(row.kind))rankLookup(index.byPayrollDocument,row.documentNumber,row,rank);}
// The live transfers only; a key missing there is looked up in the archive's index (findArchivedDocument), so a command
// no longer indexes every archived transfer.
function buildTransferLookupIndex(s){
 const index={byReference:new Map(),byId:new Map(),byPayrollDocument:new Map(),nextRank:-1},live=Array.isArray(s.finance?.transfers)?s.finance.transfers:[];
 let rank=0;for(const row of live)addTransferIndexRow(index,row,rank++);return index;
}
const PAYROLL_TRANSFER=row=>['payroll-payable','payroll-transfer'].includes(row.kind);
function transferLookupIndex(s){const tx=globalThis.GH_TRANSACTION_CORE;if(!tx?.isActive?.()&&!settlementBatchFor(s)?.ready)return null;let index=currentTransactionMemo(TRANSFER_INDEX_MEMO_KEY);if(!(index instanceof Object)){index=buildTransferLookupIndex(s);setCurrentTransactionMemo(TRANSFER_INDEX_MEMO_KEY,index);}return index;}
function bestTransferMatch(index,...matches){let found=null;for(const match of matches)if(match&&(!found||match.rank<found.rank))found=match;return found?.row;}
function findTransferByReference(s,reference){const index=transferLookupIndex(s);return index?index.byReference.get(reference)?.row??findArchivedDocument(s,'transfers','reference',reference):findFinanceDocument(s,'transfers','reference',reference);}
function findTransferById(s,id){const index=transferLookupIndex(s);return index?index.byId.get(id)?.row??findArchivedDocument(s,'transfers','id',id):findFinanceDocument(s,'transfers','id',id);}
function findTransferByIdOrReference(s,id){const index=transferLookupIndex(s);return index?bestTransferMatch(index,index.byReference.get(id),index.byId.get(id))??findArchivedDocument(s,'transfers',['reference','id'],id):findFinanceDocument(s,'transfers',['reference','id'],id);}
function findPayrollTransferByDocument(s,number){const index=transferLookupIndex(s);return index?index.byPayrollDocument.get(number)?.row??findArchivedDocument(s,'transfers','documentNumber',number,PAYROLL_TRANSFER):findFinanceDocument(s,'transfers','documentNumber',number,PAYROLL_TRANSFER);}
function buildFinanceListIndex(s,bucket){
 const byNumber=new Map(),byInvoice=bucket==='cheques'?new Map():null,allByNumber=bucket==='receivables'?new Map():null,add=(rows)=>{for(const row of Array.isArray(rows)?rows:[]){if(byInvoice&&row?.invoiceNumber){const n=String(row.invoiceNumber),linked=byInvoice.get(n)||[];linked.push(row);byInvoice.set(n,linked);}const number=row?.number;if(!byNumber.has(number))byNumber.set(number,row);if(allByNumber){let matches=allByNumber.get(number);if(!matches){matches=[];allByNumber.set(number,matches);}matches.push(row);}}};
 const fields=bucket==='cheques'?['id','requestRef','invoiceNumber']:bucket==='periods'?['id']:bucket==='invoices'?['number']:[],byField=new Map(fields.map(field=>[field,new Map()]));
 add(s.finance?.[bucket]);const index={byNumber,allByNumber,byInvoice,byField,source:s.finance?.[bucket],length:s.finance?.[bucket]?.length};
 for(const row of s.finance?.[bucket]||[])addFinanceFieldIndexes(index,row);return index;
}
function addFinanceFieldIndexes(index,row,front=false){for(const [field,map] of index.byField){const key=row?.[field];let matches=map.get(key);if(!matches){matches=[];map.set(key,matches);}if(front)matches.unshift(row);else matches.push(row);}}
function financeListIndex(s,bucket){const tx=globalThis.GH_TRANSACTION_CORE;if(!tx?.isActive?.()&&!settlementBatchFor(s)?.ready)return null;const key=FINANCE_LIST_INDEX_MEMO_PREFIX+bucket;let index=currentTransactionMemo(key);if(!(index instanceof Object)||index.source!==s.finance?.[bucket]||index.length!==s.finance?.[bucket]?.length){index=buildFinanceListIndex(s,bucket);setCurrentTransactionMemo(key,index);}return index;}
function invalidateFinanceLookupIndexes(){const tx=globalThis.GH_TRANSACTION_CORE;if(!tx?.isActive?.()&&!activeSettlementBatch)return;setCurrentTransactionMemo(TRANSFER_INDEX_MEMO_KEY,null);for(const bucket of ['invoices','payables','receivables','periods','cheques'])setCurrentTransactionMemo(FINANCE_LIST_INDEX_MEMO_PREFIX+bucket,null);}
// Invoices: a number missing from the live list is looked up in the archive's index.
function financeRowByNumber(s,bucket,number){const index=financeListIndex(s,bucket),found=index?index.byNumber.get(number):(Array.isArray(s.finance?.[bucket])?s.finance[bucket]:[]).find(row=>row.number===number);if(found||bucket!=='invoices')return found;return findArchivedDocument(s,'invoices','number',number);}
function insertFinanceRow(s,bucket,row){const rows=s.finance[bucket],previousLength=rows.length,result=rows.unshift(row),index=currentTransactionMemo(FINANCE_LIST_INDEX_MEMO_PREFIX+bucket);if(index?.byNumber instanceof Map&&index.source===rows&&index.length===previousLength){index.byNumber.set(row?.number,row);if(index.allByNumber){let matches=index.allByNumber.get(row?.number);if(!matches){matches=[];index.allByNumber.set(row?.number,matches);}matches.unshift(row);}if(index.byInvoice&&row?.invoiceNumber){const n=String(row.invoiceNumber),matches=index.byInvoice.get(n)||[];matches.unshift(row);index.byInvoice.set(n,matches);}addFinanceFieldIndexes(index,row,true);index.length=rows.length;}return result;}
function insertFinanceTransfer(s,row){const result=s.finance.transfers.unshift(row),index=currentTransactionMemo(TRANSFER_INDEX_MEMO_KEY);if(index?.byReference instanceof Map){const rank=index.nextRank--;addTransferIndexRow(index,row,rank);}return result;}
function withCollectionBatch(s,apply){
 if(!s||typeof s!=='object'||typeof apply!=='function')throw new TypeError('finance-collection-batch-invalid');if(!globalThis.GH_TRANSACTION_CORE?.isActive?.())throw new Error('finance-collection-batch-requires-full-transaction');
 const active=collectionBatches.get(s);if(active){active.depth++;try{const value=apply();if(value?.then)throw new Error('finance-collection-batch-must-be-synchronous');return value;}finally{active.depth--;}}
 const batch={depth:1,removedReceivables:new Set()};collectionBatches.set(s,batch);try{const value=apply();if(value?.then)throw new Error('finance-collection-batch-must-be-synchronous');return value;}finally{collectionBatches.delete(s);if(batch.removedReceivables.size)s.finance.receivables=s.finance.receivables.filter(row=>!batch.removedReceivables.has(row));}
}
function removeReceivableByNumber(s,number){
 const index=financeListIndex(s,'receivables'),matches=index?.allByNumber.get(number),batch=collectionBatches.get(s);
 if(batch){for(const row of matches||[])batch.removedReceivables.add(row);if(index){index.byNumber.delete(number);index.allByNumber.delete(number);}return;}
 s.finance.receivables=s.finance.receivables.filter(row=>row.number!==number);if(index){index.byNumber.delete(number);index.allByNumber.delete(number);}
}
// Transaction-local lookup; status is read from each current row, and inserts rebuild the index.
function payableCheques(s,number){const n=String(number),index=financeListIndex(s,'cheques');return index?index.byInvoice.get(n)||[]:(s.finance.cheques||[]).filter(row=>String(row.invoiceNumber||'')===n);}
function dueTermsIndex(s,day){
 const key=`${DUE_TERMS_INDEX_MEMO_PREFIX}${day}`,tx=globalThis.GH_TRANSACTION_CORE,cached=tx?.isActive?.()?tx.transactionMemoGet?.(key):null;if(cached)return cached;
 const index={receivables:new Map(),payables:new Map(),processedReceivables:new Set(),processedPayables:new Set()};
 const add=(bucket,rows)=>{for(const row of rows||[]){if(row?.autoSettle!==true||!Number.isFinite(Number(row.dueDay))||Number(row.dueDay)>day)continue;const company=requireCompany(s,row.company),list=bucket.get(company)||[];list.push(row);bucket.set(company,list);}};
 add(index.receivables,s.finance.receivables);add(index.payables,s.finance.payables);
 if(tx?.isActive?.())setCurrentTransactionMemo(key,index);return index;
}
function nextFinanceTransferReference(s,prefix){
 // Array length is not a sequence: archive trimming must not turn a new payment
 // into a replay of an older one at the same simulation timestamp.
 let sequence=Number(s.finance.transferSequence);
 if(!Number.isSafeInteger(sequence)||sequence<0){
  sequence=0;const inspect=value=>{const match=/^(?:TR|FND|FND-WD)-\d+-(\d+)$/.exec(String(value||''));if(match){const n=Number(match[1]);if(Number.isSafeInteger(n))sequence=Math.max(sequence,n);}};
  for(const rows of [s.finance.transfers,s.finance.auditArchive?.records?.transfers])for(const row of Array.isArray(rows)?rows:[]){inspect(row.id);inspect(row.reference);}
  for(const digest of s.finance.auditArchive?.digests||[])if(digest.kind==='transfers')sequence=Math.max(sequence,Number(digest.maxSequence)||0);
 }
 let reference;do{sequence++;if(!Number.isSafeInteger(sequence))throw new Error('finance-transfer-sequence-exhausted');reference=`${prefix}-${Math.floor(now(s))}-${sequence}`;}while(findTransferByIdOrReference(s,reference));
 s.finance.transferSequence=sequence;return reference;
}
function backfillPayrollTransfers(s){
 if(Number(s.finance.payrollTransferMigrationVersion)>=1)return;
 const index=buildTransferLookupIndex(s),payablesByNumber=new Map();for(const payable of s.finance.payables)if(!payablesByNumber.has(payable?.number))payablesByNumber.set(payable?.number,payable);
 const invoices=s.finance.invoices;
 for(let at=0;at<invoices.length;at++){
  let doc=invoices[at];const payroll=doc?.budgetLine==='payroll'||doc?.payrollShortfall===true;if(!payroll)continue;
  const t=requireCompany(s,doc.company),settled=['مدفوعة','مسددة','محصلة'].includes(doc.status),reportId=String(doc.payrollReportId||''),reference=String(doc.transferReference||`PAYTR-${reportId||doc.number}-${t}${settled?'':'-DUE'}`),existing=bestTransferMatch(index,index.byReference.get(reference),index.byId.get(reference),index.byPayrollDocument.get(doc.number));
  const transferReference=existing?.reference||reference;if(doc.transferReference!==transferReference){doc=writableRow(invoices,at);doc.transferReference=transferReference;}const payable=payablesByNumber.get(doc.number);if(payable){payable.payrollShortfall=true;payable.payrollReportId=payable.payrollReportId||doc.payrollReportId||null;payable.transferReference=doc.transferReference;}
  if(existing)continue;const from=s.companyFinance[t]?.accounts?.[0]?.id||`${String(t).toUpperCase()}-OPER-001`;
  const transfer={id:reference,reference,at:Number(doc.at)||now(s),from,to:doc.counterparty||'حسابات الموظفين',amount:num(doc.total??doc.amount),note:doc.note||`مسير رواتب ${companyName(s,t)}`,company:t,kind:settled?'payroll-transfer':'payroll-payable',label:settled?'حوالة مسير رواتب':'حوالة رواتب مستحقة',status:settled?'منفذة':'مستحقة',documentNumber:doc.number,payrollReportId:doc.payrollReportId||null,migrated:true};
  insertFinanceTransfer(s,transfer);addTransferIndexRow(index,transfer,index.nextRank--);
 }
 s.finance.payrollTransferMigrationVersion=1;
}
function book(s,t='group'){const type=requireCompany(s,t),result=s?.companyFinance?.[type];if(!result||!Array.isArray(result.accounts)||!result.accounts.length)throw new Error(`finance-book-missing:${type}`);return result;}
function operating(s,t='group'){const value=Number(book(s,t).accounts?.[0]?.balance);return Number.isFinite(value)?value:NaN;} function total(s,t='group'){return (book(s,t).accounts||[]).reduce((n,a)=>{const value=Number(a.balance);return n+(Number.isFinite(value)?value:NaN);},0);}
function budgetView(s,t='group'){t=requireCompany(s,t);const period=Math.floor(Math.floor(now(s)/86400)/30),source=s?.companyBudgets?.[t],b=source&&typeof source==='object'?clone(source):{limit:0,spent:0,reserved:0,period,enabled:false,lines:{},spentByLine:{},reservedByLine:{}};for(const k of ['limit','spent','reserved'])b[k]=num(b[k]);b.enabled=!!b.enabled;b.lines=b.lines&&typeof b.lines==='object'?b.lines:{};b.spentByLine=b.spentByLine&&typeof b.spentByLine==='object'?b.spentByLine:{};b.reservedByLine=b.reservedByLine&&typeof b.reservedByLine==='object'?b.reservedByLine:{};for(const k of ['payroll','fuel','maintenance','marketing','insurance','technology','capex','other'])b.lines[k]=num(b.lines[k]);if(Number(b.period)!==period){b.period=period;b.spent=0;b.reserved=0;b.spentByLine={};b.reservedByLine={};}return b;}
function mutableBudget(s,t='group'){ensure(s);t=requireCompany(s,t);const view=budgetView(s,t);s.companyBudgets[t]=view;return view;}
const budget=budgetView;
function lineFor(note='',method=''){const t=`${note} ${method}`.toLowerCase();if(/راتب|رواتب|payroll/.test(t))return'payroll';if(/وقود|fuel/.test(t))return'fuel';if(/صيان|maintenance|mro/.test(t))return'maintenance';if(/تسويق|marketing/.test(t))return'marketing';if(/تأمين|insurance/.test(t))return'insurance';if(/تقنية|technology|software|نظام/.test(t))return'technology';if(/شراء|إنشاء|بناء|أصل|طائرة|سفينة|شاحن|capex/.test(t))return'capex';return'other';}
function remaining(s,t){const b=budget(s,t);return !b.enabled||b.limit<=0?Infinity:Math.max(0,b.limit-b.spent-b.reserved)} function lineRemaining(s,t,l){const b=budget(s,t),lim=num(b.lines[l]);return !b.enabled||lim<=0?Infinity:Math.max(0,lim-num(b.spentByLine[l])-num(b.reservedByLine[l]));}
function canSpend(s,t,a,l=null){a=Number(a);if(!Number.isFinite(a)||a<0)return false;if(s.godMoney&&s.infiniteMoney)return true;return operating(s,t)>=a&&remaining(s,t)>=a&&(!l||lineRemaining(s,t,l)>=a);}
// نفس فحص operating(s,t)>=a الخام + تجاوز الأموال اللانهائية فقط - بلا فحص الميزانية remaining()
// الإضافي الذي تفرضه canSpend، حتى لا يتغير سلوك هذه الدوال حين يكون وضع الإله مطفأً.
function hasFunds(s,t,a){return (s.godMoney&&s.infiniteMoney)||operating(s,t)>=Number(a);}
// Build 358: God Mode funds a shortfall the way a founder would: an incoming transfer from the founder into the account
// of the company that needs it (a founder-investment transfer with its document proof, ledger row and journal against
// the founder's equity). It tops up in round amounts with headroom, so a run of payments arrives as one transfer.
const GOD_MODE_TOPUP_STEP=10000000;
function coverInfiniteFunds(s,t,a,purpose='مصروف'){
 const requested=num(a),shortfall=Math.max(0,requested-operating(s,t));if(!(s.godMoney&&s.infiniteMoney)||shortfall<=0)return 0;
 const amount=Math.ceil((shortfall+Math.max(shortfall,GOD_MODE_TOPUP_STEP*2.5))/GOD_MODE_TOPUP_STEP)*GOD_MODE_TOPUP_STEP;
 founderInvestment(s,{company:t,amount,ref:nextFinanceTransferReference(s,'GOD'),note:`تمويل من المؤسس في وضع التجربة · ${purpose}`,godMode:true});return amount;
}
function consumeBudget(s,t,a,l){const b=mutableBudget(s,t);a=num(a);if(b.enabled&&b.limit>0)b.spent+=a;if(l)b.spentByLine[l]=num(b.spentByLine[l])+a;} // Incurred expenses are liabilities, not discretionary cash spends. Reserve them for budget tracking even when cash or the budget cap is short.
function reserveAccruedObligationBudget(s,t,a,l='other'){a=num(a);if(a<0)return null;const b=mutableBudget(s,t),totalRoom=!b.enabled||b.limit<=0?Infinity:Math.max(0,b.limit-b.spent-b.reserved),lineLimit=num(b.lines[l]),lineRoom=!b.enabled||lineLimit<=0?Infinity:Math.max(0,lineLimit-num(b.spentByLine[l])-num(b.reservedByLine[l])),reserved=Math.max(0,Math.min(a,totalRoom,lineRoom));if(b.enabled&&b.limit>0)b.reserved+=reserved;if(l)b.reservedByLine[l]=num(b.reservedByLine[l])+reserved;return {reserved,unbudgeted:Math.max(0,a-reserved)};}
function reserveBudget(s,t,a,l='other'){a=num(a);if(!canSpend(s,t,a,l))return false;const b=mutableBudget(s,t);if(b.enabled&&b.limit>0)b.reserved+=a;b.reservedByLine[l]=num(b.reservedByLine[l])+a;return true;} function consumeReserved(s,t,a,l='other'){const b=mutableBudget(s,t),held=Math.min(num(a),num(b.reservedByLine[l]));b.reserved=Math.max(0,b.reserved-held);b.reservedByLine[l]=Math.max(0,num(b.reservedByLine[l])-held);consumeBudget(s,t,a,l);} function releaseReserved(s,t,a,l='other'){const b=mutableBudget(s,t),held=Math.min(num(a),num(b.reservedByLine[l]));b.reserved=Math.max(0,b.reserved-held);b.reservedByLine[l]=Math.max(0,num(b.reservedByLine[l])-held);return held;}
function reconcile(s){if(!s.companyFinance)return Number(s.cash)||0;let cash=0,debt=0,taxPayable=0,taxPaid=0;const ids=companyIds(s);for(const id of Object.keys(s.companyFinance))if(!ids.includes(id)&&!isZeroFinancePlaceholder(s.companyFinance[id]))throw new Error(`finance-company-unknown:${id}`);for(const t of ids){const b=s.companyFinance[t];if(!b)continue;for(const account of b.accounts||[]){const value=Number(account.balance);if(!Number.isFinite(value)||value<0)throw new Error(`invalid-account-balance:${t}`);cash+=value;}for(const [key,target] of [['debt','debt'],['taxPayable','taxPayable'],['taxPaid','taxPaid']]){const value=Number(b[key]);if(!Number.isFinite(value)||value<0)throw new Error(`invalid-${key}:${t}`);if(target==='debt')debt+=value;else if(target==='taxPayable')taxPayable+=value;else taxPaid+=value;}}s.cash=cash;s.debt=debt;if(s.finance){s.finance.taxPayable=taxPayable;s.finance.taxPaid=taxPaid;}return s.cash;}
function ledgerEntry(s,e,overrides={}){const owner=globalThis.GH_DOCUMENT_PROOF;return owner?.ledgerProjection?owner.ledgerProjection(s,e,overrides):Object.assign(clone(e),clone(overrides||{}));}
function companyLedger(s,t,e,overrides={}){const row=ledgerEntry(s,e,overrides);book(s,t).ledger.unshift(row);return row;}
function ledger(s,t,e,overrides={}){const row=companyLedger(s,t,e,overrides);s.treasury.ledger.unshift(clone(row));s.treasury.ledger=s.treasury.ledger.slice(0,1200);return row;}
function journal(s,t,desc,lines,ref=''){ensure(s);const rows=(lines||[]).map(x=>({account:String(x.account||''),debit:num(x.debit),credit:num(x.credit)})).filter(x=>x.account&&(x.debit>0||x.credit>0)),dr=rows.reduce((n,x)=>n+x.debit,0),cr=rows.reduce((n,x)=>n+x.credit,0);if(!rows.length||Math.abs(dr-cr)>.02)throw new Error(`قيد غير متوازن: ${desc}`);const sequence=++s.finance.journalSequence,row={id:`JE-${String(sequence).padStart(8,'0')}`,company:t,description:desc,lines:rows,sourceRef:ref,at:now(s)};s.finance.journalEntries.unshift(row);return row;}
function refreshBookTaxPayable(s,company){const b=book(s,company),vat=b.vat||(b.vat={output:0,input:0,creditCarry:0,periodOutputStart:0,periodInputStart:0}),formalDue=(s.finance.periods||[]).filter(row=>row.company===company&&row.status==='مستحق').reduce((sum,row)=>sum+num(row.amount),0),openAccrual=Math.max(0,(num(vat.output)-num(vat.periodOutputStart))-(num(vat.input)-num(vat.periodInputStart))-num(vat.creditCarry));b.taxAccrued=openAccrual;b.taxPayable=formalDue;return b.taxPayable;}
function validCustomerBusinessLocation(s,company,locationId,sourceRef){
 if(globalThis.GH_COMPANY_PLATFORM?.definitionFor?.(s,company)?.capabilities.includes('operations.hospitality'))return String(sourceRef||'').startsWith(`HOSP-INVOICE:${company}:`)&&!!s.hospitality?.companies?.[company]?.properties?.some(row=>row.facilityId===locationId&&row.companyId===company);
 const kind=company==='telecom'?'telecom-branch':company==='dealership'?'dealership-branch':'';if(!kind)return false;
 if((Array.isArray(s.customHubs)?s.customHubs:[]).some(row=>row?.id===locationId&&row.owned===true&&String(row.ownerCompanyId||row.company||'')===company&&row.kind===kind))return true;
 const rows=s.customerCompanies?.companies?.[company];if(!rows)return false;const ref=String(sourceRef||'');
 if(company==='telecom')return [...(rows.subscriptions||[]),...(rows.cohorts||[])].some(row=>row.branchId===locationId&&(ref.startsWith(`TEL-INV-${row.id}-`)||ref.startsWith(`TEL-COHORT-INV-${row.id}-`)));
 return [...(rows.sales||[]),...(rows.servicePlans||[])].some(row=>row.branchId===locationId&&(ref===`AUTO-SALE-${row.id}`||ref.startsWith(`AUTO-SERVICE-INV-${row.id}-`)));
}
const cents=value=>Math.round((Number(value)+Number.EPSILON)*100)/100;
function companyTaxNumber(s,company){const id=requireCompany(s,company),registry=id==='group'?(s.profile||{}):(s.companyRegistry?.[id]||{});return String(registry.taxId||registry.taxNumber||'غير مسجل');}
// The game's existing 15% simulation policy is retained for all countries. Country names are resolved once, never
// by scanning facilities or the fleet. These defaults are a game policy, not a table of official foreign tax rates.
const TAX_POLICY='simulation-vat-15-v1',taxCountries=new Map([['السعودية','SA'],['الإمارات','AE'],['الإمارات العربية المتحدة','AE'],['عُمان','OM'],['عمان','OM'],['سلطنة عمان','OM'],['الهند','IN'],['دولي','INT'],['غير محدد','INT']]);
let taxCountryNamesReady=false;
function taxCountryCode(value){
 const country=String(value||'السعودية').trim();if(/^[A-Z]{2}$/.test(country))return country;
 if(taxCountries.has(country))return taxCountries.get(country);
 if(!taxCountryNamesReady){taxCountryNamesReady=true;try{const names=new Intl.DisplayNames(['ar'],{type:'region'});for(const code of 'AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW'.split(' '))taxCountries.set(names.of(code),code);}catch(_error){}}
 return taxCountries.get(country)||country.slice(0,80);
}
function invoiceTaxProfile(s,company,p={}){
 const country=String(p.businessLocationCountry||p.taxCountry||s.companyRegistry?.[company]?.country||globalThis.GH_GAME_LIFECYCLE?.locationFor?.(s.profile)?.country||s.profile?.country||'السعودية').slice(0,80),jurisdiction=String(p.taxJurisdiction||taxCountryCode(country)),code=String(p.taxCode||(p.taxable!==false?'standard':'exempt'));
 const exempt=code==='financial-interest'||code==='residential-rent'&&jurisdiction==='SA',rate=p.taxable===false||exempt?0:(p.taxRate==null?.15:Number(p.taxRate));
 if(!Number.isFinite(rate)||rate<0||rate>1)throw new Error('invoice-tax-rate-invalid');
 return {country,jurisdiction,code,rate,source:TAX_POLICY};
}
function invoice(s,{kind,amount,note,method='تحويل بنكي',taxable=true,taxCode=null,taxRate=null,taxJurisdiction=null,taxCountry='',taxComponents=null,status='مدفوعة',company='group',counterparty='',counterpartyPartyId=null,number=null,dueDay=null,sourceRef=null,settlementAccount=null,paymentTerms=null,businessLocationId=null,businessLocationName='',businessLocationCity='',businessLocationCountry=''}={}){
 ensure(s);company=requireCompany(s,company);amount=num(amount);const profile=invoiceTaxProfile(s,company,{taxable,taxCode,taxRate,taxJurisdiction,taxCountry,businessLocationCountry}),code=profile.code,rate=profile.rate;let componentRows=null,tax=rate>0?cents(amount*(rate/(1+rate))):0;if(taxComponents!=null){if(!Array.isArray(taxComponents)||!taxComponents.length||taxComponents.length>4)throw new Error('invoice-tax-components-invalid');componentRows=taxComponents.map(part=>{const value=Number(part?.amount),rule=invoiceTaxProfile(s,company,{taxable,taxCode:profile.code,taxRate:profile.rate,taxCountry:profile.country,taxJurisdiction:profile.jurisdiction,...part});if(!Number.isFinite(value)||value<0)throw new Error('invoice-tax-component-amount-invalid');const vat=rule.rate>0?cents(value*rule.rate/(1+rule.rate)):0;return {description:String(part.description||rule.code).slice(0,180),quantity:1,unitPrice:value-vat,taxable:rule.rate>0?value-vat:0,vat,total:value,taxCode:rule.code,taxRate:rule.rate};});if(Math.abs(componentRows.reduce((sum,row)=>sum+row.total,0)-amount)>.005)throw new Error('invoice-tax-components-unbalanced');tax=cents(componentRows.reduce((sum,row)=>sum+row.vat,0));}const subtotal=Math.max(0,amount-tax),prefix=String(documentProfile(s,company).documentPrefix||company).toUpperCase(),doc=number||`${prefix}-${String(s.finance.invoiceSequence).padStart(6,'0')}`;if(!number)s.finance.invoiceSequence++;const rawCounterparty=formalCounterparty(s,company,kind,counterparty),directParty=counterpartyPartyId?globalThis.GH_BUSINESS_WORLD?.resolveParty?.(s,String(counterpartyPartyId)):null;if(counterpartyPartyId&&!directParty)throw new Error('invoice-counterparty-party-not-found');const cp=directParty?{id:directParty.id,name:directParty.legalName||directParty.displayName||rawCounterparty}:partyMeta(s,rawCounterparty,kind==='دخل'?'customer':'supplier'),settled=['مدفوعة','مسددة','محصلة'].includes(status),row={number:doc,company,companyName:companyName(s,company),accountId:book(s,company).accounts[0].id,kind,amount,subtotal,tax,total:amount,taxCode:componentRows?'mixed':code,taxRate:rate,taxJurisdiction:profile.jurisdiction,taxCountry:profile.country,taxPolicySource:profile.source,...(componentRows?{lines:componentRows}:{}),taxNumber:companyTaxNumber(s,company),note:String(note||''),method,status,counterparty:cp.name||rawCounterparty,counterpartyPartyId:cp.id,at:now(s)};if(dueDay!=null)row.dueDay=dueDay;else if(!settled)row.dueDay=Math.floor(now(s)/86400)+30;if(sourceRef)row.sourceRef=String(sourceRef);if(businessLocationId){const locationId=String(businessLocationId).trim();if(!/^[A-Za-z0-9][A-Za-z0-9._:-]{1,79}$/.test(locationId)||!validCustomerBusinessLocation(s,company,locationId,sourceRef))throw new Error('invoice-business-location-invalid');row.businessLocationId=locationId;row.businessLocationName=String(businessLocationName||'').slice(0,120);row.businessLocationCity=String(businessLocationCity||'').slice(0,80);row.businessLocationCountry=String(businessLocationCountry||'').slice(0,80);}if(settlementAccount)row.settlementAccount=String(settlementAccount);if(!settled&&Number(paymentTerms)>0){row.paymentTermsDays=Math.floor(Number(paymentTerms));row.autoSettle=true;}protectDocument(s,row,kind==='دخل'?'invoice-receivable':'invoice-payable');insertFinanceRow(s,'invoices',row);recordWorldFinance(s,{partyId:cp.id,counterparty:row.counterparty,company,direction:kind==='دخل'?'incoming':'outgoing',amount,reference:sourceRef||doc,documentNumber:doc,note:row.note,settled:false});if(!settled)insertFinanceRow(s,kind==='دخل'?'receivables':'payables',{...row});const vat=book(s,company).vat;if(tax>0){if(kind==='دخل')vat.output=cents(vat.output+tax);else vat.input=cents(vat.input+tax);}refreshBookTaxPayable(s,company);const cash=book(s,company).accounts[0].id,counter=kind==='دخل'?'ذمم مدينة':'ذمم دائنة',settlement=settlementAccount?String(settlementAccount):cash;journal(s,company,`${doc} · ${note}`,kind==='دخل'?[{account:settled?settlement:counter,debit:amount},{account:'إيرادات تشغيلية',credit:subtotal},{account:'ضريبة مخرجات VAT',credit:tax}]:[{account:'مصروف تشغيلي',debit:subtotal},{account:'ضريبة مدخلات VAT',debit:tax},{account:settled?settlement:counter,credit:amount}],sourceRef||doc);return row;
}
function syncInvoiceIndex(s,document){for(const bucket of ['payables','receivables']){const row=financeRowByNumber(s,bucket,document.number);if(!row||row===document)continue;for(const key of Object.keys(row))delete row[key];Object.assign(row,clone(document));}return document;}
function amendInvoice(s,document,transition,mutate){amendProtectedDocument(s,document,document.documentType||(document.kind==='دخل'?'invoice-receivable':'invoice-payable'),transition,mutate);return syncInvoiceIndex(s,document);}
function invoiceOutstanding(document){return Math.max(0,Number(document?.total??document?.amount??0)-Number(document?.amountPaid||0));}
function postCustomerInvoicePayment(s,invoice,amount,reference,{cashAlreadyPosted=false,channel='تحويل بنكي'}={}){
 const company=requireCompany(s,invoice.company),account=book(s,company).accounts[0],amountNum=Number(amount),ref=String(reference||'').trim(),outstanding=invoiceOutstanding(invoice),paymentFingerprint=JSON.stringify({company,invoiceNumber:invoice.number,amount:amountNum,cashAlreadyPosted:Boolean(cashAlreadyPosted),channel:String(channel)});
 if(invoice.kind!=='دخل'||invoice.status==='ملغاة'||!Number.isFinite(amountNum)||amountNum<=0||!ref)throw new Error('customer-invoice-payment-invalid');
 const prior=s.finance.customerSalePaymentReceipts.find(row=>row.reference===ref);
 if(prior){if(prior.fingerprint!==paymentFingerprint)throw new Error('customer-invoice-payment-reference-conflict');return {receiptId:prior.id||ref,reference:ref,invoiceNumber:invoice.number,company,amount:amountNum,remaining:num(prior.outstandingAmount),idempotent:true};}
 const priorTransfer=findTransferByReference(s,ref);
 if(priorTransfer){const matches=priorTransfer.kind==='customer-financing'&&priorTransfer.toCompany===company&&priorTransfer.documentNumber===invoice.number&&Math.abs(num(priorTransfer.amount)-amountNum)<.01&&Boolean(cashAlreadyPosted);if(!matches)throw new Error('customer-invoice-payment-reference-conflict');return {receiptId:ref,reference:ref,invoiceNumber:invoice.number,company,amount:amountNum,remaining:invoiceOutstanding(invoice),idempotent:true};}
 if(amountNum>outstanding+.01)throw new Error('customer-invoice-payment-invalid');
 const balanceBefore=num(account.balance);if(!cashAlreadyPosted)account.balance+=amountNum;
 const newPaid=Number(invoice.amountPaid||0)+amountNum,remaining=Math.max(0,Number(invoice.total??invoice.amount)-newPaid),fullyPaid=remaining<=.01;
 amendInvoice(s,invoice,'invoice-collected',document=>{document.amountPaid=newPaid;document.outstandingAmount=remaining;document.status=fullyPaid?'محصلة':'محصلة جزئيا';document.lastPaymentReference=ref;document.paymentMethod=channel;if(fullyPaid){document.settledAt=now(s);document.transferReference=ref;}});
 const receivable=financeRowByNumber(s,'receivables',invoice.number);if(fullyPaid)removeReceivableByNumber(s,invoice.number);else if(receivable){receivable.originalTotal=Number(invoice.total??invoice.amount);receivable.amount=remaining;receivable.total=remaining;receivable.amountPaid=newPaid;receivable.outstandingAmount=remaining;receivable.status='مستحقة';}
 journal(s,company,`تحصيل ${invoice.number} · ${channel}`,[{account:account.id,debit:amountNum},{account:'ذمم مدينة',credit:amountNum}],ref);
 const receipt={id:ref,reference:ref,company,invoiceNumber:invoice.number,customerId:invoice.counterpartyPartyId||null,counterparty:invoice.counterparty||'',amount:amountNum,amountPaid:newPaid,outstandingAmount:remaining,cashAlreadyPosted:Boolean(cashAlreadyPosted),payerSource:String(channel),status:'منفذة',fingerprint:paymentFingerprint,at:now(s)};
 protectDocument(s,receipt,'revenue-collection');s.finance.customerSalePaymentReceipts.unshift(receipt);s.finance.customerSalePaymentReceipts=s.finance.customerSalePaymentReceipts.slice(0,1200);
 if(!cashAlreadyPosted)recordCollection(s,{company,amount:amountNum,reference,invoiceNumbers:[invoice.number],counterparty:invoice.counterparty||'',channel,purposeCategory:'تحصيل ذمم العملاء',purposeDetail:invoice.note||`تحصيل فاتورة ${invoice.number}`,paymentMethod:channel,accountBalanceBefore:balanceBefore,accountBalanceAfter:num(account.balance)});
 reconcile(s);return {receiptId:ref,reference:ref,company,invoiceNumber:invoice.number,amount:amountNum,amountPaid:newPaid,remaining,idempotent:false};
}
function receiveCustomerSalePayment(s,p={}){
 const company=requireCompany(s,p.company),invoiceNumber=String(p.invoiceNumber||''),reference=String(p.reference||'').trim(),customerId=String(p.customerId||''),amount=Number(p.amount);
 if(!reference||reference.length>120||!customerId||!Number.isFinite(amount)||amount<=0||String(p.payerSource||'customer-down-payment')!=='customer-down-payment')throw new Error('customer-sale-payment-invalid');
 const invoice=financeRowByNumber(s,'invoices',invoiceNumber);if(!invoice||invoice.company!==company||invoice.kind!=='دخل'||invoice.counterpartyPartyId!==customerId)throw new Error('customer-sale-payment-invoice-mismatch');
 return postCustomerInvoicePayment(s,invoice,amount,reference,{cashAlreadyPosted:false,channel:'دفعة مقدمة من العميل'});
}
function cancelCustomerSaleInvoice(s,p={}){
 const company=requireCompany(s,p.company),invoiceNumber=String(p.invoiceNumber||''),reference=String(p.reference||'').trim(),saleId=String(p.saleId||''),reason=String(p.reason||'رفض تمويل العميل').slice(0,160);
 if(company!=='dealership'||!invoiceNumber||!reference||reference.length>120||!saleId)throw new Error('customer-sale-cancellation-invalid');
 const fingerprint=JSON.stringify({company,invoiceNumber,saleId,reason}),prior=s.finance.customerSaleCreditNotes.find(row=>row.reference===reference);if(prior){if(prior.fingerprint!==fingerprint)throw new Error('customer-sale-credit-reference-conflict');return clone(prior);}
 const invoice=financeRowByNumber(s,'invoices',invoiceNumber),receivable=financeRowByNumber(s,'receivables',invoiceNumber);if(!invoice||invoice.company!==company||invoice.kind!=='دخل'||invoice.sourceRef!==`AUTO-SALE-${saleId}`)throw new Error('customer-sale-cancellation-invoice-mismatch');
 if(Number(invoice.amountPaid)>0||invoiceOutstanding(invoice)<.01||!receivable)throw new Error('customer-sale-invoice-already-settled');
 const amount=Number(invoice.total??invoice.amount),vat=Number(invoice.tax)||0,subtotal=Number(invoice.subtotal)||Math.max(0,amount-vat),invoicePeriod=calendarMonthForDay(Math.floor(Number(invoice.at||0)/86400)),currentPeriod=calendarMonthForDay(Math.floor(now(s)/86400)),closed=s.finance.periods.some(row=>row.company===company&&row.periodKey===invoicePeriod),creditCarry=closed||invoicePeriod!==currentPeriod,note=`إشعار دائن ${invoiceNumber} · ${reason}`,creditNote={id:reference,reference,company,invoiceNumber,saleId,amount,subtotal,tax:vat,counterparty:invoice.counterparty,counterpartyPartyId:invoice.counterpartyPartyId,note,reason,status:'معتمد',kind:'customer-sale-credit-note',taxTreatment:creditCarry?'credit-carry':'open-period-reversal',fingerprint,at:now(s)};
 amendInvoice(s,invoice,'invoice-cancelled',document=>{document.status='ملغاة';document.cancelledAt=now(s);document.creditNoteReference=reference;document.cancelReason=reason;document.outstandingAmount=0;});removeReceivableByNumber(s,invoiceNumber);
 const taxBook=book(s,company);if(creditCarry)taxBook.vat.creditCarry+=vat;else taxBook.vat.output=Math.max(0,num(taxBook.vat.output)-vat);refreshBookTaxPayable(s,company);journal(s,company,note,[{account:'مردودات وإشعارات دائنة',debit:subtotal},{account:creditCarry?'رصيد ضريبي دائن مرحل':'ضريبة مخرجات VAT',debit:vat},{account:'ذمم مدينة',credit:amount}],reference);
 protectDocument(s,creditNote,'audit-invoice');s.finance.customerSaleCreditNotes.unshift(creditNote);s.finance.customerSaleCreditNotes=s.finance.customerSaleCreditNotes.slice(0,800);return clone(creditNote);
}
function receiveCustomerLoanPayment(s,p={}){
 const company=requireCompany(s,p.company||'bank'),reference=String(p.reference||'').trim(),contractId=String(p.contractId||''),customerId=String(p.customerId||''),principalAmount=Number(p.principalAmount),interestAmount=Number(p.interestAmount),amount=principalAmount+interestAmount;
 if(company!=='bank'||!reference||reference.length>120||!contractId||!customerId||![principalAmount,interestAmount,amount].every(Number.isFinite)||principalAmount<0||interestAmount<0||amount<=0)throw new Error('customer-loan-payment-invalid');
 const customerParty=globalThis.GH_BUSINESS_WORLD?.resolveParty?.(s,customerId);if(!customerParty)throw new Error('customer-loan-payment-party-not-found');
 const fingerprint=JSON.stringify({company,contractId,customerId,principalAmount,interestAmount,amount,payerSource:'customer'}),prior=s.finance.customerLoanPaymentReceipts.find(row=>row.reference===reference)||findTransferByReference(s,reference);
 if(prior){if(prior.fingerprint!==fingerprint)throw new Error('customer-loan-payment-reference-conflict');return {...clone(prior),idempotent:true};}
 const account=book(s,company).accounts[0],before=num(account.balance);account.balance+=amount;
 const lines=[{account:account.id,debit:amount}];if(principalAmount>0)lines.push({account:'محفظة القروض',credit:principalAmount});if(interestAmount>0)lines.push({account:'إيرادات فوائد قروض',credit:interestAmount});journal(s,company,`قسط قرض عميل ${customerId} · ${contractId}`,[...lines],reference);
 const customerName=String(customerParty.legalName||customerParty.displayName||customerParty.name||p.customerName||customerId),note=`تحصيل قسط ${contractId}`,receipt={id:reference,receiptId:reference,reference,company,contractId,customerId,customerName,counterparty:customerName,counterpartyPartyId:customerId,from:customerName,fromPartyId:customerId,to:account.id,toAccount:account.id,amount,principalAmount,interestAmount,status:'posted',payerSource:'customer',kind:'customer-loan-payment',label:'قسط تمويل عميل محصل',note,direction:'incoming',postedAt:now(s),accountBalanceBefore:before,accountBalanceAfter:num(account.balance),fingerprint};protectDocument(s,receipt,'revenue-collection');s.finance.customerLoanPaymentReceipts.unshift(receipt);s.finance.customerLoanPaymentReceipts=s.finance.customerLoanPaymentReceipts.slice(0,1200);
 const transfer={id:reference,reference,at:receipt.postedAt,from:customerName,to:account.id,fromPartyId:customerId,counterparty:customerName,counterpartyPartyId:customerId,toAccount:account.id,amount,contractId,customerId,customerName,principalAmount,interestAmount,kind:'customer-loan-payment',label:'قسط تمويل عميل محصل',note,direction:'incoming',status:'posted',fingerprint};insertFinanceTransfer(s,transfer);ledger(s,company,receipt,{kind:'customer-loan-payment',label:'قسط تمويل عميل محصل',note,direction:'incoming'});reconcile(s);return clone(receipt);
}
function disburseCustomerLoanToSale(s,p={}){
 const from=requireCompany(s,p.fromCompany||'bank'),to=requireCompany(s,p.toCompany),contractId=String(p.contractId||''),sourceSaleId=String(p.sourceSaleId||''),orderId=String(p.orderId||''),customerId=String(p.customerId||''),reference=String(p.reference||`CUST-DISB-${contractId}`).trim(),proFormaReference=String(p.proFormaReference||''),downPaymentReference=String(p.downPaymentReference||''),amount=Number(p.amount),invoiceAmount=Number(p.invoiceAmount),downPayment=num(p.downPayment),loanPrincipal=Number(p.loanPrincipal),originationFee=Number(p.originationFee)||0;
 if(from!=='bank'||to!=='dealership'||!contractId||!sourceSaleId||!orderId||!customerId||!reference||reference.length>120||proFormaReference!==`AUTO-ORDER-${sourceSaleId}`||downPayment>.01||downPaymentReference||![amount,invoiceAmount,loanPrincipal,originationFee].every(Number.isFinite)||amount<=0||invoiceAmount<=0||Math.abs(invoiceAmount-amount)>.02||loanPrincipal<=0||originationFee<0||Math.abs(loanPrincipal-originationFee-amount)>.02)throw new Error('customer-financing-disbursement-invalid');
 const fingerprint=JSON.stringify({from,to,contractId,sourceSaleId,orderId,customerId,amount,invoiceAmount,downPayment,downPaymentReference,proFormaReference,loanPrincipal,originationFee}),prior=s.finance.customerFinancingReceipts.find(row=>row.reference===reference)||findTransferByReference(s,reference);
 if(prior){const matches=prior.fingerprint===fingerprint||(!prior.fingerprint&&prior.kind==='customer-financing'&&prior.fromCompany===from&&prior.toCompany===to&&prior.contractId===contractId&&prior.sourceSaleId===sourceSaleId&&prior.orderId===orderId&&prior.customerId===customerId&&Math.abs(num(prior.amount)-amount)<.01);if(!matches)throw new Error('customer-financing-reference-conflict');return {...clone(prior),receiptId:prior.receiptId||reference,idempotent:true};}
 const bank=globalThis.GH_BANKING_CORE?.ensure?.(s),contract=bank?.customerLoanContracts?.find(row=>row.id===contractId),portfolio=contract&&bank.loanPortfolios?.find(row=>row.id===contract.portfolioId);
 if(!contract||contract.customerId!==customerId||contract.sourceSaleId!==sourceSaleId||contract.orderId!==orderId||Math.abs(Number(contract.originalPrincipal)-loanPrincipal)>.02||!portfolio||portfolio.disbursementRecipient!=='customer-sale')throw new Error('customer-financing-contract-mismatch');
 let invoiceDoc=findFinanceDocument(s,'invoices','sourceRef',`AUTO-SALE-${sourceSaleId}`,row=>row.company===to&&row.kind==='دخل');
 const saleRow=s.customerCompanies?.companies?.dealership?.sales?.find(row=>row.id===sourceSaleId),businessLocation=saleRow?.branchId?{businessLocationId:saleRow.branchId,businessLocationName:saleRow.branchName||'',businessLocationCity:saleRow.branchCity||'',businessLocationCountry:saleRow.branchCountry||''}:{};
 if(!invoiceDoc)invoiceDoc=invoice(s,{company:to,kind:'دخل',amount:invoiceAmount,note:`بيع مركبة للعميل · ${orderId}`,method:'فاتورة بيع وكالة سيارات',taxable:true,status:'مستحقة',counterparty:String(p.customerName||'عميل وكالة السيارات'),counterpartyPartyId:customerId,sourceRef:`AUTO-SALE-${sourceSaleId}`,...businessLocation});
 if(p.invoiceNumber&&String(p.invoiceNumber)!==invoiceDoc.number)throw new Error('customer-financing-sale-invoice-reference-conflict');
 if(invoiceDoc.company!==to||invoiceDoc.kind!=='دخل'||invoiceDoc.sourceRef!==`AUTO-SALE-${sourceSaleId}`||invoiceDoc.counterpartyPartyId!==customerId||Math.abs(Number(invoiceDoc.total??invoiceDoc.amount)-invoiceAmount)>.02)throw new Error('customer-financing-sale-invoice-mismatch');
 const receivable=financeRowByNumber(s,'receivables',invoiceDoc.number);if(!receivable||Math.abs(invoiceOutstanding(invoiceDoc)-amount)>.02)throw new Error('customer-financing-sale-invoice-mismatch');
 const bankAccount=book(s,from).accounts[0],sellerAccount=book(s,to).accounts[0];if(num(bankAccount.balance)+.01<amount)throw new Error('customer-financing-bank-liquidity');const balanceBefore=num(bankAccount.balance);bankAccount.balance-=amount;sellerAccount.balance+=amount;
 journal(s,from,`صرف تمويل عميل لشراء مركبة · ${orderId}`,[{account:'تمويلات عملاء مستحقة للتحويل',debit:amount},{account:bankAccount.id,credit:amount}],reference);
 const invoicePayment=postCustomerInvoicePayment(s,invoiceDoc,amount,reference,{cashAlreadyPosted:true,channel:'تمويل سيارة من البنك'});
 const receipt={id:reference,documentId:`FINREC-${contractId}`,receiptId:reference,reference,company:from,counterparty:companyName(s,to),fromCompany:from,toCompany:to,sourceSaleId,orderId,proFormaReference,invoiceNumber:invoiceDoc.number,downPaymentReference:null,contractId,customerId,amount,invoiceAmount,downPayment:0,loanPrincipal,originationFee,status:'posted',postedAt:now(s),fingerprint};protectDocument(s,receipt,'intercompany-transfer');
 const transfer={id:reference,reference,at:now(s),from:bankAccount.id,to:sellerAccount.id,fromCompany:from,toCompany:to,beneficiaryCompany:to,amount,note:`تمويل شراء سيارة للعميل · ${orderId}`,kind:'customer-financing',label:'تمويل عميل منفذ',status:'منفذة',documentNumber:invoiceDoc.number,customerId,sourceSaleId,contractId,orderId,fingerprint};protectDocument(s,transfer,'intercompany-transfer');insertFinanceTransfer(s,transfer);ledger(s,from,transfer);companyLedger(s,to,transfer);
 s.finance.customerFinancingReceipts.unshift(receipt);s.finance.customerFinancingReceipts=s.finance.customerFinancingReceipts.slice(0,400);reconcile(s);return {...receipt,invoicePayment};
}
function issueInvoice(s,p={}){
 const kind=p.kind==='مصروف'?'مصروف':p.kind==='دخل'?'دخل':null,amount=Number(p.amount),status=String(p.status||'مستحقة');
 if(!kind)throw new Error('invoice-kind-invalid');
 if(!Number.isFinite(amount)||amount<=0)throw new Error('invoice-amount-invalid');
 if(!['مستحقة','مدفوعة','مسددة','محصلة'].includes(status))throw new Error('invoice-status-invalid');
 return invoice(s,{...p,kind,amount,status});
}
function registerCommercialContract(s,p={}){
 ensure(s);const id=String(p.id||p.reference||'').trim(),company=requireCompany(s,p.company),contractType=String(p.contractType||'عقد تجاري').trim(),counterparty=String(p.counterparty||'').trim();if(!id)throw new Error('commercial-contract-id-required');if(!counterparty)throw new Error('commercial-contract-counterparty-required');
 const sourceRefs=(Array.isArray(p.sourceRefs)?p.sourceRefs:[]).map(String).slice(0,80),terms=p.terms&&typeof p.terms==='object'&&!Array.isArray(p.terms)?clone(p.terms):{},amount=num(p.amount),fingerprint=JSON.stringify([company,contractType,counterparty,amount,Number(p.startDay)||0,Number(p.endDay)||0,terms,sourceRefs]),prior=findFinanceDocument(s,'commercialContracts','id',id);
 if(prior){if(prior.requestFingerprint!==fingerprint)throw new Error('commercial-contract-reference-conflict');return clone(prior);}
 const document={id,reference:id,company,companyName:companyName(s,company),contractType,title:String(p.title||contractType),counterparty,amount,currency:String(p.currency||'USD'),issuedAt:now(s),startDay:Number.isFinite(Number(p.startDay))?Number(p.startDay):Math.floor(now(s)/86400),endDay:Number.isFinite(Number(p.endDay))?Number(p.endDay):null,status:String(p.status||'موقع وساري'),terms,sourceRefs,linkedDocumentNumbers:(Array.isArray(p.linkedDocumentNumbers)?p.linkedDocumentNumbers:[]).map(String).slice(0,80),linkedTransferReferences:(Array.isArray(p.linkedTransferReferences)?p.linkedTransferReferences:[]).map(String).slice(0,80),requestFingerprint:fingerprint};
 protectDocument(s,document,'commercial-contract');s.finance.commercialContracts.unshift(document);
 const rows=[],archived=[];let ordinary=0,hospitality=0;
 for(const row of s.finance.commercialContracts){
  const hotel=globalThis.GH_COMPANY_PLATFORM?.definitionFor?.(s,row.company)?.capabilities.includes('operations.hospitality')||String(row.id||'').includes('HOSP-');
  if(hotel){if(hospitality++<64)rows.push(row);else archived.push(row);}else if(ordinary++<400)rows.push(row);
 }
 s.finance.commercialContracts=rows;
 if(archived.length){const archive=s.finance.auditArchive=s.finance.auditArchive||{records:{},digests:[]};archive.records=archive.records||{};archive.records.commercialContracts=[...(archive.records.commercialContracts||[]),...archived];}
 return clone(document);
}
function updateCommercialContractStatus(s,p={}){
 ensure(s);const id=String(p.id||p.reference||'').trim(),status=String(p.status||'').trim(),document=s.finance.commercialContracts.find(row=>row.id===id);if(!id)throw new Error('commercial-contract-id-required');if(!document)throw new Error('commercial-contract-not-found');if(status!=='منتهي')throw new Error('commercial-contract-status-unsupported');if(document.status===status)return clone(document);
 amendProtectedDocument(s,document,'commercial-contract','contract-expired',row=>{row.status=status;row.statusAt=now(s);if(p.endedAt!=null)row.endedAt=Number(p.endedAt)||now(s);if(p.reason)row.statusReason=String(p.reason);});return clone(document);
}
// Build 378: the cash the group's bank may pay out to the group under the capital conservation buffer (banking-core).
const bankDistributable=s=>{const value=Number(globalThis.GH_BANKING_CORE?.distributableCash?.(s));return Number.isFinite(value)?value:Infinity;};
function transfer(s,p,{bankFacility=false}={}){ensure(s);const a=num(p.amount),from=requireCompany(s,p.from,{defaultGroup:false}),to=requireCompany(s,p.to,{defaultGroup:false}),reference=String(p.ref||p.reference||nextFinanceTransferReference(s,'TR'));if(from===to||a<=0)throw new Error('invalid-transfer');const prior=findTransferByIdOrReference(s,reference);if(prior){if(prior.fromCompany!==from||prior.toCompany!==to||Math.abs(num(prior.amount)-a)>.01)throw new Error('transfer-reference-conflict');return {transferred:true,status:'transferred',from,to,amount:a,reference,idempotent:true};}if(!hasFunds(s,from,a))throw new Error('insufficient-cash');if(from==='bank'&&!bankFacility&&a>bankDistributable(s)+.01)throw new Error('bank-distribution-restricted');coverInfiniteFunds(s,from,a,'تحويل داخلي');const fa=book(s,from).accounts[0],ta=book(s,to).accounts[0];fa.balance-=a;ta.balance+=a;const e={id:reference,reference,at:now(s),from:fa.id,to:ta.id,fromCompany:from,toCompany:to,amount:a,note:p.note||'تحويل داخلي',kind:'intercompany',label:'حوالة داخلية منفذة',status:'منفذة',company:from,beneficiaryCompany:to};protectDocument(s,e,'intercompany-transfer');insertFinanceTransfer(s,{...e});ledger(s,from,e);companyLedger(s,to,e);journal(s,from,e.note,[{account:'استثمار/ذمم بين شركات المجموعة',debit:a},{account:fa.id,credit:a}],reference);journal(s,to,e.note,[{account:ta.id,debit:a},{account:'رأس مال/ذمم بين شركات المجموعة',credit:a}],reference);reconcile(s);return {transferred:true,status:'transferred',from,to,amount:a,reference,idempotent:false,documentProofId:e.documentProofId,contentDigest:e.contentDigest};}
// Only banking-core calls this internal posting path after its projected credit checks. It is not a finance command.
function transferBankFacility(s,p){if(p.from!=='bank'||!/^CF-[1-9][0-9]*$/.test(String(p.ref||'')))throw new Error('bank-facility-transfer-invalid');return transfer(s,p,{bankFacility:true});}
function settleIntercompanyInterest(s,p={}){
 ensure(s);const from=requireCompany(s,p.from||p.company,{defaultGroup:false}),to=requireCompany(s,p.to||'bank'),amount=num(p.amount),reference=String(p.ref||p.reference||'').trim();
 if(from==='bank'||to!=='bank'||amount<=0)throw new Error('invalid-intercompany-interest');
 if(!reference)throw new Error('intercompany-interest-reference-required');
 const note=String(p.note||`فائدة تسهيل ائتماني · ${reference}`),requestFingerprint=JSON.stringify([from,to,amount,note]),prior=findTransferByIdOrReference(s,reference);
 if(prior){if(prior.kind!=='intercompany-interest'||prior.fromCompany!==from||prior.toCompany!==to||Math.abs(num(prior.amount)-amount)>.01||prior.requestFingerprint&&prior.requestFingerprint!==requestFingerprint)throw new Error('intercompany-interest-reference-conflict');return {settled:true,from,to,amount:0,reference,idempotent:true,cashPostedRevenue:0};}
 if(!hasFunds(s,from,amount))throw new Error('insufficient-interest-cash');
 const payer=book(s,from),receiver=book(s,to),payerName=companyName(s,from),bankName=companyName(s,to);
 coverInfiniteFunds(s,from,amount,'تسوية فائدة');payer.accounts[0].balance-=amount;receiver.accounts[0].balance+=amount;
 const expense=invoice(s,{kind:'مصروف',amount,note,method:'تسوية فائدة داخلية',taxable:false,taxCode:'financial-interest',status:'مدفوعة',company:from,counterparty:bankName,sourceRef:reference});
 const income=invoice(s,{kind:'دخل',amount,note:`دخل ${note}`,method:'تسوية فائدة داخلية',taxable:false,taxCode:'financial-interest',status:'محصلة',company:to,counterparty:payerName,sourceRef:reference});
 const event={at:now(s),from:payer.accounts[0].id,to:receiver.accounts[0].id,amount,note,kind:'intercompany-interest',company:from,beneficiaryCompany:to,reference,expenseDocumentNumber:expense.number,incomeDocumentNumber:income.number};
 Object.assign(event,{id:reference,status:'منفذة',collection:true,channel:collectionProfile(to,s).channel,service:'تحصيل فائدة تسهيل ائتماني',grossAmount:amount,deductions:0,invoiceNumbers:[income.number],sourceRefs:[reference],fromCompany:from,toCompany:to,requestFingerprint});protectDocument(s,event,'intercompany-interest');amendInvoice(s,expense,'invoice-transfer-linked',doc=>{doc.transferReference=reference;});amendInvoice(s,income,'invoice-transfer-linked',doc=>{doc.transferReference=reference;});insertFinanceTransfer(s,{...event});ledger(s,from,event);companyLedger(s,to,event);reconcile(s);
 return {settled:true,from,to,amount,reference,expenseInvoiceNumber:expense.number,incomeInvoiceNumber:income.number,idempotent:false,cashPostedRevenue:amount};
}
// Build 358 (owner review): the group's power company sells electricity to the other group companies. One settlement a
// buyer a day: an expense document for the buyer, an income document for the power company and the cash transfer
// between their current accounts, linked like an intercompany interest settlement. Untaxed inside the group, as
// intercompany interest is.
function settleIntercompanySupply(s,p={}){
 ensure(s);const from=requireCompany(s,p.from||p.company),to=requireCompany(s,p.to,{defaultGroup:false}),amount=num(p.amount),reference=String(p.ref||p.reference||'').trim(),mwh=num(p.mwh);
 if(from===to||amount<=0)throw new Error('invalid-intercompany-supply');
 if(!reference)throw new Error('intercompany-supply-reference-required');
 const note=String(p.note||`توريد كهرباء داخلي · ${reference}`),requestFingerprint=JSON.stringify([from,to,amount,note]),prior=findTransferByIdOrReference(s,reference);
 if(prior){if(prior.kind!=='intercompany-energy'||prior.fromCompany!==from||prior.toCompany!==to||Math.abs(num(prior.amount)-amount)>.01||prior.requestFingerprint&&prior.requestFingerprint!==requestFingerprint)throw new Error('intercompany-supply-reference-conflict');return {settled:true,from,to,amount:0,reference,idempotent:true,cashPostedRevenue:0};}
 if(!hasFunds(s,from,amount))throw new Error('insufficient-supply-cash');
 const payer=book(s,from),receiver=book(s,to),payerName=companyName(s,from),sellerName=companyName(s,to);
 coverInfiniteFunds(s,from,amount,'توريد كهرباء داخلي');payer.accounts[0].balance-=amount;receiver.accounts[0].balance+=amount;
 const expense=invoice(s,{kind:'مصروف',amount,note,method:'توريد داخلي بين شركات المجموعة',taxable:false,taxCode:'intercompany-tax-group',status:'مدفوعة',company:from,counterparty:sellerName,sourceRef:reference});
 const income=invoice(s,{kind:'دخل',amount,note:`دخل ${note}`,method:'توريد داخلي بين شركات المجموعة',taxable:false,taxCode:'intercompany-tax-group',status:'محصلة',company:to,counterparty:payerName,sourceRef:reference});
 const event={at:now(s),from:payer.accounts[0].id,to:receiver.accounts[0].id,amount,note,kind:'intercompany-energy',company:from,beneficiaryCompany:to,reference,expenseDocumentNumber:expense.number,incomeDocumentNumber:income.number,mwh};
 Object.assign(event,{id:reference,status:'منفذة',collection:true,channel:collectionProfile(to,s).channel,service:'تحصيل توريد كهرباء داخلي',grossAmount:amount,deductions:0,invoiceNumbers:[income.number],sourceRefs:[reference],fromCompany:from,toCompany:to,requestFingerprint});protectDocument(s,event,'intercompany-energy');amendInvoice(s,expense,'invoice-transfer-linked',doc=>{doc.transferReference=reference;});amendInvoice(s,income,'invoice-transfer-linked',doc=>{doc.transferReference=reference;});insertFinanceTransfer(s,{...event});ledger(s,from,event);companyLedger(s,to,event);reconcile(s);
 return {settled:true,from,to,amount,mwh,reference,expenseInvoiceNumber:expense.number,incomeInvoiceNumber:income.number,idempotent:false,cashPostedRevenue:amount};
}
function settleIntercompanyService(s,p={}){
 ensure(s);const from=requireCompany(s,p.from||p.company),to=requireCompany(s,p.to,{defaultGroup:false}),amount=num(p.amount),reference=String(p.ref||p.reference||'').trim();
 if(from===to||amount<=0)throw new Error('invalid-intercompany-service');if(!reference)throw new Error('intercompany-service-reference-required');
 const serviceCategory=String(p.serviceCategory||'خدمات داخل المجموعة'),note=String(p.note||`${serviceCategory} · ${reference}`),requestFingerprint=JSON.stringify([from,to,amount,note,serviceCategory]),prior=findTransferByIdOrReference(s,reference);
 if(prior){if(prior.kind!=='intercompany-service'||prior.fromCompany!==from||prior.toCompany!==to||Math.abs(num(prior.amount)-amount)>.01||prior.requestFingerprint&&prior.requestFingerprint!==requestFingerprint)throw new Error('intercompany-service-reference-conflict');return {settled:true,from,to,amount:0,reference,idempotent:true,cashPostedRevenue:0};}
 const budgetLine=p.line?String(p.line):null;if(budgetLine?!canSpend(s,from,amount,budgetLine):!hasFunds(s,from,amount))throw new Error('insufficient-service-cash-or-budget');const payer=book(s,from),receiver=book(s,to),payerName=companyName(s,from),sellerName=companyName(s,to);
 coverInfiniteFunds(s,from,amount,'خدمة داخل المجموعة');const payerBefore=num(payer.accounts[0].balance),receiverBefore=num(receiver.accounts[0].balance);payer.accounts[0].balance-=amount;receiver.accounts[0].balance+=amount;if(budgetLine)consumeBudget(s,from,amount,budgetLine);
 const expense=invoice(s,{kind:'مصروف',amount,note,method:'تسوية خدمة بين شركات المجموعة',taxable:false,taxCode:String(p.taxCode||'intercompany-tax-group'),status:'مدفوعة',company:from,counterparty:sellerName,sourceRef:reference});
 const income=invoice(s,{kind:'دخل',amount,note:`دخل ${note}`,method:'تسوية خدمة بين شركات المجموعة',taxable:false,taxCode:String(p.taxCode||'intercompany-tax-group'),status:'محصلة',company:to,counterparty:payerName,sourceRef:reference});
 const event={id:reference,reference,at:now(s),from:payer.accounts[0].id,to:receiver.accounts[0].id,fromCompany:from,toCompany:to,company:from,beneficiaryCompany:to,amount,grossAmount:amount,netAmount:amount,deductions:0,note,serviceCategory,kind:'intercompany-service',label:'حوالة خدمة بين شركات المجموعة',status:'منفذة',collection:true,channel:collectionProfile(to,s).channel,service:serviceCategory,expenseDocumentNumber:expense.number,incomeDocumentNumber:income.number,invoiceNumbers:[income.number],sourceRefs:(Array.isArray(p.sourceRefs)?p.sourceRefs:[reference]).map(String).slice(0,80),requestFingerprint,payerBalanceBefore:payerBefore,payerBalanceAfter:num(payer.accounts[0].balance),receiverBalanceBefore:receiverBefore,receiverBalanceAfter:num(receiver.accounts[0].balance)};
 protectDocument(s,event,'intercompany-service');amendInvoice(s,expense,'invoice-transfer-linked',doc=>{doc.transferReference=reference;if(budgetLine)doc.budgetLine=budgetLine;});amendInvoice(s,income,'invoice-transfer-linked',doc=>{doc.transferReference=reference;});insertFinanceTransfer(s,{...event});ledger(s,from,event);companyLedger(s,to,event);reconcile(s);
 // receiverInClose: the seller's own close already reports this income (the bank's fees, through its transaction fees).
 if(p.closeOwned!==true&&budgetLine!=='capex'){notePnl(s,from,0,amount);if(p.receiverInClose!==true)notePnl(s,to,amount,0);}
 return {settled:true,from,to,amount,reference,expenseInvoiceNumber:expense.number,incomeInvoiceNumber:income.number,idempotent:false,cashPostedRevenue:amount,transfer:event};
}
function settleInsuranceClaims(s,p={}){
 ensure(s);const company=requireCompany(s,p.company||'insurance'),amount=num(p.amount),day=Math.max(0,Math.floor(Number(p.day)||Math.floor(now(s)/86400))),reference=String(p.reference||p.ref||`INS-CLAIM-PAY-${day}`),prior=findTransferByIdOrReference(s,reference);
 if(amount<=0)throw new Error('invalid-insurance-claim-payment');if(prior){if(prior.kind!=='insurance-claim-payment'||prior.company!==company||Math.abs(num(prior.amount)-amount)>.01)throw new Error('insurance-claim-payment-reference-conflict');return {paid:0,amount:0,reference,idempotent:true};}if(!hasFunds(s,company,amount))throw new Error('insufficient-claim-cash');
 coverInfiniteFunds(s,company,amount,'مطالبات تأمين مستحقة');const account=book(s,company).accounts[0],balanceBefore=num(account.balance);account.balance-=amount;const beneficiary=String(p.beneficiary||'حملة الوثائق والمستفيدون'),entry=journal(s,company,`سداد مطالبات تأمين مستحقة · يوم ${day}`,[{account:'مخصص مطالبات تأمين',debit:amount},{account:account.id,credit:amount}],reference),transfer={id:reference,reference,at:now(s),day,from:account.id,to:beneficiary,amount,company,kind:'insurance-claim-payment',label:'حوالة سداد مطالبات تأمين',status:'منفذة',note:String(p.note||`سداد المطالبات التي حل أجلها في اليوم ${day}`),purposeCategory:'تسوية مطالبات تأمين',purposeDetail:'مطالبات مستحقة بعد مهلة التسوية التعاقدية',paymentMethod:'حوالة مطالبات مجمعة',taxCode:'insurance-claim',journalEntryId:entry.id,accountBalanceBefore:balanceBefore,accountBalanceAfter:num(account.balance),sourceRefs:(Array.isArray(p.sourceRefs)?p.sourceRefs:[]).map(String).slice(0,80)};
 protectDocument(s,transfer,'insurance-claim-payment');insertFinanceTransfer(s,{...transfer});ledger(s,company,transfer);reconcile(s);return {paid:amount,amount,reference,idempotent:false,transfer};
}
function bulkTransfer(s,p){const rows=Array.isArray(p.rows)?p.rows:[],seen=new Set(),clean=[];for(const x of rows){const t=requireCompany(s,x.company,{defaultGroup:false}),a=num(x.amount);if(t==='group'||a<=0)continue;if(seen.has(t))throw new Error('duplicate-beneficiary');seen.add(t);clean.push({company:t,amount:a});}if(!clean.length)throw new Error('empty-bulk-transfer');const total=clean.reduce((n,x)=>n+x.amount,0);if(!hasFunds(s,'group',total))throw new Error('insufficient-cash');const batch=p.batchId||`BULK-${Math.floor(now(s))}-${s.finance.transfers.length+1}`;for(const x of clean)transfer(s,{from:'group',to:x.company,amount:x.amount,note:`${p.note||'توزيع رأسمالي'} · ${batch}`,ref:`${batch}-${x.company}`});return {total,count:clean.length,batchId:batch};}
function centralTreasuryPolicy(s){ensure(s);return clone(s.finance.centralTreasury);}
function setCentralTreasuryPolicy(s,p={}){ensure(s);const ct=s.finance.centralTreasury,rows=p.minOperatingCash&&typeof p.minOperatingCash==='object'?p.minOperatingCash:{};for(const key of Object.keys(rows))requireCompany(s,key,{defaultGroup:false});for(const t of companyIds(s,{includeGroup:false}))if(Object.prototype.hasOwnProperty.call(rows,t))ct.minOperatingCash[t]=num(rows[t]);ct.lastPolicyAt=now(s);return clone(ct);}
function cashPoolSweep(s,p={}){
 ensure(s);const ct=s.finance.centralTreasury,companies=(Array.isArray(p.companies)?p.companies:(s.openedCompanies||[])).map(t=>requireCompany(s,t,{defaultGroup:false})).filter(t=>t!=='group'&&cashPoolEligible(s,t)),batch=String(p.batchId||`POOL-${Math.floor(now(s))}-${s.finance.cashPoolSweeps.length+1}`),rows=[];
 if(s.finance.cashPoolSweeps.some(x=>x.id===batch))return clone(s.finance.cashPoolSweeps.find(x=>x.id===batch));
 for(const t of [...new Set(companies)]){const available=num(book(s,t).accounts[0].balance),floor=num(ct.minOperatingCash[t]),surplus=Math.max(0,available-floor),requested=p.amounts&&Object.prototype.hasOwnProperty.call(p.amounts,t)?num(p.amounts[t]):surplus,amount=Math.min(surplus,requested,t==='bank'?bankDistributable(s):Infinity);if(amount>.01){transfer(s,{from:t,to:'group',amount,note:`Cash Pool · فائض ${companyName(s,t)}`,ref:`${batch}-${t}`});rows.push({company:t,amount,floor,balanceBefore:available,balanceAfter:available-amount});}}
 const out={id:batch,at:now(s),rows,total:rows.reduce((n,x)=>n+x.amount,0),status:rows.length?'منفذ':'لا يوجد فائض'};s.finance.cashPoolSweeps.unshift(out);s.finance.cashPoolSweeps=s.finance.cashPoolSweeps.slice(0,120);ct.lastSweepAt=now(s);return clone(out);
}
function accrueIntercompanyLoan(s,loan){const day=Math.floor(now(s)/86400),last=Math.max(0,Number(loan.lastAccrualDay??loan.issuedDay??day)),elapsed=Math.max(0,day-last);if(elapsed&&num(loan.outstandingPrincipal)>0){loan.accruedInterest=num(loan.accruedInterest)+num(loan.outstandingPrincipal)*Math.max(0,Number(loan.annualRate)||0)*elapsed/365;loan.lastAccrualDay=day;}return loan;}
function issueIntercompanyLoan(s,p={}){
 ensure(s);const lender=requireCompany(s,p.lender||'group'),borrower=requireCompany(s,p.borrower,{defaultGroup:false}),amount=num(p.amount),annualRate=Math.max(0,Number(p.annualRate)||0),termDays=Math.max(1,Math.floor(Number(p.termDays)||365)),id=String(p.id||p.reference||`ICL-${Math.floor(now(s))}-${s.finance.intercompanyLoans.length+1}`);
 const note=String(p.note||`تمويل داخلي من ${companyName(s,lender)} إلى ${companyName(s,borrower)}`),requestFingerprint=JSON.stringify([lender,borrower,amount,annualRate,termDays,note]);if(lender===borrower||amount<=0)throw new Error('invalid-intercompany-loan');const prior=s.finance.intercompanyLoans.find(x=>x.id===id);if(prior){if(prior.requestFingerprint&&prior.requestFingerprint!==requestFingerprint||prior.lender!==lender||prior.borrower!==borrower||Math.abs(num(prior.originalPrincipal)-amount)>.01||Number(prior.annualRate)!==annualRate||Number(prior.dueDay)-Number(prior.issuedDay)!==termDays)throw new Error('intercompany-loan-reference-conflict');return clone(prior);}if(!hasFunds(s,lender,amount))throw new Error('insufficient-cash');coverInfiniteFunds(s,lender,amount,'تغطية تمويل داخلي في وضع اللعب');const lb=book(s,lender),bb=book(s,borrower),la=lb.accounts[0],ba=bb.accounts[0],day=Math.floor(now(s)/86400);la.balance-=amount;ba.balance+=amount;
 const ev={id,reference:id,at:now(s),from:la.id,to:ba.id,fromCompany:lender,toCompany:borrower,amount,note,kind:'intercompany-loan-principal',label:'تمويل بين شركات المجموعة',status:'منفذة',company:lender,beneficiaryCompany:borrower,requestFingerprint};protectDocument(s,ev,'intercompany-loan-principal');insertFinanceTransfer(s,{...ev});ledger(s,lender,ev);companyLedger(s,borrower,ev);journal(s,lender,ev.note,[{account:'قروض وذمم على شركات المجموعة',debit:amount},{account:la.id,credit:amount}],id);journal(s,borrower,ev.note,[{account:ba.id,debit:amount},{account:'قروض وذمم لشركات المجموعة',credit:amount}],id);
 const loan={id,lender,borrower,companyName:companyName(s,borrower),lenderName:companyName(s,lender),originalPrincipal:amount,outstandingPrincipal:amount,annualRate,issuedDay:day,lastAccrualDay:day,dueDay:day+termDays,accruedInterest:0,interestPaid:0,principalPaid:0,status:'قائم',createdAt:now(s),requestFingerprint,principalTransferProofId:ev.documentProofId,principalTransferContentDigest:ev.contentDigest};s.finance.intercompanyLoans.unshift(loan);reconcile(s);return clone(loan);
}
function repayIntercompanyLoan(s,p={}){
 ensure(s);const id=String(p.id||p.loanId||''),loan=s.finance.intercompanyLoans.find(x=>x.id===id);if(!loan)throw new Error('intercompany-loan-not-found');const ref=String(p.reference||`ICLSET-${id}-${s.finance.intercompanyLoanSettlements.length+1}`),requestToken=p.amount==null?'FULL':num(p.amount),requestFingerprint=JSON.stringify([id,requestToken]),prior=s.finance.intercompanyLoanSettlements.find(x=>x.id===ref);if(prior){if(prior.loanId!==id||prior.requestFingerprint&&prior.requestFingerprint!==requestFingerprint||p.amount!=null&&Math.abs(num(prior.requestedAmount)-num(p.amount))>.01)throw new Error('intercompany-loan-settlement-reference-conflict');return clone(prior);}accrueIntercompanyLoan(s,loan);if(loan.status==='مسدد')return clone(loan);const borrower=loan.borrower,lender=loan.lender,bb=book(s,borrower),lb=book(s,lender),ba=bb.accounts[0],la=lb.accounts[0],due=num(loan.outstandingPrincipal)+num(loan.accruedInterest),request=p.amount==null?due:num(p.amount),amount=Math.min(due,request);if(amount<=0)throw new Error('invalid-repayment');if(!hasFunds(s,borrower,amount))throw new Error('insufficient-cash');coverInfiniteFunds(s,borrower,amount,'تغطية سداد تمويل داخلي في وضع اللعب');const interest=Math.min(num(loan.accruedInterest),amount),principal=Math.min(num(loan.outstandingPrincipal),amount-interest);ba.balance-=amount;la.balance+=amount;
 if(principal>0){journal(s,borrower,`سداد أصل ${id}`,[{account:'قروض وذمم لشركات المجموعة',debit:principal},{account:ba.id,credit:principal}],`${ref}-P-B`);journal(s,lender,`تحصيل أصل ${id}`,[{account:la.id,debit:principal},{account:'قروض وذمم على شركات المجموعة',credit:principal}],`${ref}-P-L`);}if(interest>0){const borrowerName=companyName(s,borrower),lenderName=companyName(s,lender);const expense=invoice(s,{kind:'مصروف',amount:interest,note:`فائدة تمويل داخلي ${id}`,method:'تسوية بين شركات المجموعة',taxable:false,status:'مدفوعة',company:borrower,counterparty:lenderName,sourceRef:ref});const income=invoice(s,{kind:'دخل',amount:interest,note:`دخل فائدة تمويل داخلي ${id}`,method:'تسوية بين شركات المجموعة',taxable:false,status:'محصلة',company:lender,counterparty:borrowerName,sourceRef:ref});amendInvoice(s,expense,'invoice-transfer-linked',doc=>{doc.transferReference=ref;});amendInvoice(s,income,'invoice-transfer-linked',doc=>{doc.transferReference=ref;});}
 loan.outstandingPrincipal=Math.max(0,num(loan.outstandingPrincipal)-principal);loan.accruedInterest=Math.max(0,num(loan.accruedInterest)-interest);loan.principalPaid=num(loan.principalPaid)+principal;loan.interestPaid=num(loan.interestPaid)+interest;loan.status=loan.outstandingPrincipal<=.01&&loan.accruedInterest<=.01?'مسدد':(Math.floor(now(s)/86400)>Number(loan.dueDay)?'متأخر':'قائم');const ev={id:ref,reference:ref,at:now(s),from:ba.id,to:la.id,fromCompany:borrower,toCompany:lender,amount,principal,interest,note:`سداد تمويل داخلي ${id}`,kind:'intercompany-loan-settlement',label:'سداد تمويل بين شركات المجموعة',status:'منفذة',company:borrower,beneficiaryCompany:lender,loanId:id,requestedAmount:p.amount==null?due:num(p.amount),requestFingerprint};protectDocument(s,ev,'intercompany-loan-settlement');insertFinanceTransfer(s,{...ev});ledger(s,borrower,ev);companyLedger(s,lender,ev);const settlement={...ev,remainingPrincipal:loan.outstandingPrincipal,remainingInterest:loan.accruedInterest};s.finance.intercompanyLoanSettlements.unshift(settlement);s.finance.intercompanyLoanSettlements=s.finance.intercompanyLoanSettlements.slice(0,240);reconcile(s);return clone(settlement);
}
function intercompanyLoanSnapshot(s){ensure(s);const day=Math.floor(now(s)/86400);return s.finance.intercompanyLoans.map(row=>{const out=clone(row),last=Math.max(0,Number(out.lastAccrualDay??out.issuedDay??day)),elapsed=Math.max(0,day-last);if(elapsed&&num(out.outstandingPrincipal)>0)out.accruedInterest=num(out.accruedInterest)+num(out.outstandingPrincipal)*Math.max(0,Number(out.annualRate)||0)*elapsed/365;if(out.status!=='مسدد'&&day>Number(out.dueDay))out.status='متأخر';return out;});}
function transferReserve(s,p){const toReserve=p.toReserve!==undefined?!!p.toReserve:String(p.direction||'')!=='to-operating',b=book(s,p.company),src=toReserve?b.accounts[0]:b.accounts[1],dst=toReserve?b.accounts[1]:b.accounts[0],a=num(p.amount);if(a<=0)throw new Error('invalid-amount');if(!(s.godMoney&&s.infiniteMoney)&&num(src.balance)<a)throw new Error('insufficient-cash');if(s.godMoney&&s.infiniteMoney&&num(src.balance)<a){const shortfall=a-num(src.balance),reference=`INF-${p.company}-${String((Number(s.finance?.journalSequence)||0)+1).padStart(8,'0')}`;src.balance+=shortfall;journal(s,p.company,'تغطية احتياطي في وضع اللعب',[{account:src.id,debit:shortfall},{account:'حقوق ملكية وضع اللعب',credit:shortfall}],reference);}src.balance-=a;dst.balance+=a;const e={at:now(s),from:src.id,to:dst.id,amount:a,note:toReserve?'تحويل إلى الاحتياطي':'إعادة من الاحتياطي',company:p.company};ledger(s,p.company,e);journal(s,p.company,e.note,[{account:dst.id,debit:a},{account:src.id,credit:a}],p.ref||'');reconcile(s);return {amount:a,toReserve,from:src.id,to:dst.id};}
function spend(s,p){const t=requireCompany(s,p.company),a=num(p.amount),line=p.line||lineFor(p.note,p.method);if(!canSpend(s,t,a,line))throw new Error('insufficient-funds-or-budget');const b=book(s,t);coverInfiniteFunds(s,t,a,'مصروف');b.accounts[0].balance-=a;consumeBudget(s,t,a,line);if(p.closeOwned!==true&&line!=='capex')notePnl(s,t,0,a);const doc=invoice(s,{kind:'مصروف',amount:a,note:p.note,method:p.method||'تحويل بنكي',taxable:p.taxable!==false,taxCode:p.taxCode,taxRate:p.taxRate,taxJurisdiction:p.taxJurisdiction,taxCountry:p.taxCountry,taxComponents:p.taxComponents,status:p.status||'مدفوعة',company:t,counterparty:p.counterparty||''});if((p.status||'مدفوعة')==='مدفوعة'){const e={at:now(s),from:b.accounts[0].id,to:doc.counterparty,toPartyId:doc.counterpartyPartyId||null,amount:a,note:p.note,company:t,kind:'cash-document',documentNumber:doc.number,reference:doc.number,status:'منفذة'};ledger(s,t,e);recordWorldFinance(s,{partyId:doc.counterpartyPartyId,counterparty:doc.counterparty,company:t,direction:'outgoing',amount:a,reference:doc.number,transferRef:doc.number,documentNumber:doc.number,note:p.note,settled:true});}reconcile(s);return doc;}
function payPayroll(s,p={}){
  const t=requireCompany(s,p.company),a=num(p.amount),b=book(s,t),reportId=String(p.reportId||''),transferId=String(p.reference||`PAYTR-${reportId||Math.floor(now(s)/86400)}-${t}`),prior=findTransferByIdOrReference(s,transferId);
  if(prior){if(prior.company!==t||Math.abs(num(prior.amount)-a)>.01||String(prior.payrollReportId||'')!==reportId)throw new Error('payroll-reference-conflict');const priorDoc=findFinanceDocument(s,'invoices','number',prior.documentNumber);return priorDoc||{number:prior.documentNumber||transferId,company:t,amount:prior.amount,transferReference:transferId,idempotent:true};}
  if(a<=0)throw new Error('invalid-payroll-amount');if(!hasFunds(s,t,a))throw new Error('insufficient-payroll-cash');
  coverInfiniteFunds(s,t,a,'رواتب');b.accounts[0].balance-=a;consumeBudget(s,t,a,'payroll');
  const doc=invoice(s,{kind:'مصروف',amount:a,note:p.note||`مسير رواتب ${companyName(s,t)}`,method:'تحويل رواتب',taxable:false,status:'مدفوعة',company:t,counterparty:'حسابات الموظفين'});
  amendInvoice(s,doc,'invoice-payroll-classified',row=>{row.payrollReportId=reportId||null;row.budgetLine='payroll';row.transferReference=transferId;});
  const transfer={id:transferId,reference:transferId,at:now(s),from:b.accounts[0].id,to:'حسابات الموظفين',amount:a,note:doc.note,company:t,kind:'payroll-transfer',label:'حوالة مسير رواتب',status:'منفذة',documentNumber:doc.number,payrollReportId:doc.payrollReportId};protectDocument(s,transfer,'payroll-transfer');insertFinanceTransfer(s,{...transfer});ledger(s,t,transfer);reconcile(s);return doc;
}
function accruePayroll(s,p={}){
  const t=requireCompany(s,p.company),a=num(p.amount),number=String(p.number||`PAY-${t.toUpperCase()}-${Math.floor(now(s)/86400)}`),reportId=p.reportId||null;
  if(a<=0)throw new Error('invalid-payroll-amount');const existing=findFinanceDocument(s,'invoices','number',number);if(existing){if(existing.company!==t||Math.abs(num(existing.total??existing.amount)-a)>.01||String(existing.payrollReportId||'')!==String(reportId||''))throw new Error('payroll-accrual-reference-conflict');return existing;}
  const doc=invoice(s,{kind:'مصروف',amount:a,note:p.note||`رواتب مستحقة · ${companyName(s,t)}`,method:'تحويل رواتب',taxable:false,status:'مستحقة',company:t,counterparty:'حسابات الموظفين',number,dueDay:p.dueDay??Math.floor(now(s)/86400)});
  amendInvoice(s,doc,'invoice-payroll-classified',row=>{row.budgetLine='payroll';row.payrollShortfall=true;row.payrollReportId=reportId;});
  const payable=s.finance.payables.find(row=>row.number===number);
  const transferId=`PAYTR-${reportId||number}-${t}-DUE`,transfer={id:transferId,reference:transferId,at:now(s),from:book(s,t).accounts[0].id,to:'حسابات الموظفين',amount:a,note:doc.note,company:t,kind:'payroll-payable',label:'حوالة رواتب مستحقة',status:'مستحقة',documentNumber:number,payrollReportId:reportId};if(!Boolean(findTransferById(s,transferId))){protectDocument(s,transfer,'payroll-payable');insertFinanceTransfer(s,{...transfer});}amendInvoice(s,doc,'invoice-transfer-linked',row=>{row.transferReference=transferId;});ledger(s,t,transfer,{from:'ذمم رواتب مستحقة',kind:'payroll-accrual'});return doc;
}
function recordPayrollReport(s,p={}){const report=clone(p.report||{}),id=String(report.id||'');if(!id||!Array.isArray(report.lines))throw new Error('invalid-payroll-report');const fingerprint=JSON.stringify(report),existing=s.finance.payrollReports.find(row=>row.id===id);if(existing){if(existing.requestFingerprint&&existing.requestFingerprint!==fingerprint)throw new Error('payroll-report-reference-conflict');return existing;}report.at=Number.isFinite(Number(report.at))?Number(report.at):now(s);report.total=report.lines.reduce((sum,line)=>sum+num(line.amount),0);report.paid=report.lines.reduce((sum,line)=>sum+num(line.paid),0);report.due=Math.max(0,report.total-report.paid);report.status=report.due>0?'مسجل مع رواتب مستحقة':'مصروف بالكامل';report.requestFingerprint=fingerprint;protectDocument(s,report,'payroll-report');s.finance.payrollReports.unshift(report);s.finance.payrollReports=s.finance.payrollReports.slice(0,120);return report;}
// Build 375 (owner: every company's documents, costs and revenue must meet): an expense or income document made outside
// the daily close (campaigns, maintenance, incidents, fines, licences, intercompany premiums, claims and fees) is the
// company's profit too. Each is noted here once, and the next daily close adds the noted totals to the company's
// report (takeOffClosePnl). Capital spending, the close's own postings (closeOwned) and internal rent are not.
// The holding's own documents are not noted, except its investment results (allowGroup): listed dividends, realized
// gains and losses, and the income of its stakes, which the close adds to the group's result.
function notePnl(s,t,revenue,expense,{allowGroup=false}={}){if(!t||(t==='group'&&!allowGroup))return;const box=s.finance.offClosePnl=s.finance.offClosePnl&&typeof s.finance.offClosePnl==='object'&&!Array.isArray(s.finance.offClosePnl)?s.finance.offClosePnl:{};const row=box[t]=box[t]&&typeof box[t]==='object'?box[t]:{revenue:0,expense:0};row.revenue=num(row.revenue)+num(revenue);row.expense=num(row.expense)+num(expense);}
function takeOffClosePnl(s){ensure(s);const box=s.finance.offClosePnl&&typeof s.finance.offClosePnl==='object'&&!Array.isArray(s.finance.offClosePnl)?s.finance.offClosePnl:{},out={};for(const [t,row] of Object.entries(box))out[t]={revenue:num(row?.revenue),expense:num(row?.expense)};s.finance.offClosePnl={};return out;}
function accrue(s,p){const t=requireCompany(s,p.company),a=num(p.amount),line=p.line||lineFor(p.note,p.method||'قيد مستحق');const budgetReservation=reserveAccruedObligationBudget(s,t,a,line);if(!budgetReservation)throw new Error('insufficient-budget');const doc=invoice(s,{kind:'مصروف',amount:a,note:p.note,method:p.method||'قيد مستحق',taxable:p.taxable!==false,taxCode:p.taxCode,taxRate:p.taxRate,taxJurisdiction:p.taxJurisdiction,taxCountry:p.taxCountry,taxComponents:p.taxComponents,status:'مستحقة',company:t,counterparty:p.counterparty||'',dueDay:p.dueDay,number:p.number,paymentTerms:p.paymentTerms});amendInvoice(s,doc,'invoice-accrual-classified',row=>{row.budgetLine=line;row.budgetReserved=budgetReservation.reserved;row.budgetUnbudgetedAmount=budgetReservation.unbudgeted;row.budgetObligation=true;});ledger(s,t,{at:now(s),from:'ذمم دائنة',to:doc.counterparty,amount:a,note:p.note,company:t,kind:'accrual-document',documentNumber:doc.number});if(p.closeOwned!==true&&line!=='capex')notePnl(s,t,0,a);return doc;}
function credit(s,p){
 const t=requireCompany(s,p.company),a=Number(p.amount),profile=collectionProfile(t,s);if(!Number.isFinite(a)||a<=0)throw new Error('invalid-revenue-collection');
 if(p.sourceRefs!==undefined&&!Array.isArray(p.sourceRefs))throw new Error('invalid-collection-source-refs');
 const reference=String(p.reference||p.ref||`RCPT-${t}-${s.finance.invoiceSequence}`),prior=findTransferByReference(s,reference);
 if(prior){if(prior.company!==t||Math.abs(prior.amount-a)>.01)throw new Error('collection-reference-conflict');return financeRowByNumber(s,'invoices',prior.invoiceNumbers?.[0])||{transferReference:reference,idempotent:true};}
 const day=Number(p.periodDay),hasDay=p.periodDay!==undefined&&Number.isSafeInteger(day)&&day>=0,cursors=s.finance.revenueCollectionDays||{};if(p.periodDay!==undefined&&!hasDay)throw new Error('invalid-collection-period');
 if(hasDay&&Number.isFinite(cursors[t])&&day<=cursors[t])return {transferReference:reference,idempotent:true};
 // Build 358: payment terms. With termsDays the customer pays on the due day: the invoice stays a receivable and the
 // daily close collects it then (settle-due-terms) under the same reference; without, it is collected at once.
 const termsDays=Math.max(0,Math.floor(num(p.termsDays)));
 if(termsDays>0){const open=findFinanceDocument(s,'invoices','sourceRef',reference,row=>row.kind==='دخل');if(open){if(open.company!==t||Math.abs(num(open.total)-a)>.01)throw new Error('collection-reference-conflict');return open;}}
 const doc=invoice(s,{kind:'دخل',amount:a,note:p.note||profile.service,method:profile.channel,taxable:p.taxable!==false,taxCode:p.taxCode,taxRate:p.taxRate,taxJurisdiction:p.taxJurisdiction,taxCountry:p.taxCountry,taxComponents:p.taxComponents,status:'مستحقة',company:t,counterparty:p.counterparty||profile.source,counterpartyPartyId:p.counterpartyPartyId||p.customerId||null,sourceRef:reference,businessLocationId:p.businessLocationId,businessLocationName:p.businessLocationName,businessLocationCity:p.businessLocationCity,businessLocationCountry:p.businessLocationCountry,...(termsDays>0?{dueDay:Math.floor(now(s)/86400)+termsDays,paymentTerms:termsDays}:{})});
 if(termsDays<=0)collectReceivable(s,{number:doc.number,company:t,reference,channel:profile.channel,sourceRefs:p.sourceRefs||[]});
 // investmentResult: a holding's income or the gain (negative: loss) of a stake sale, the group's investment result.
 if(Number.isFinite(Number(p.investmentResult))&&Number(p.investmentResult)!==0){const r=Number(p.investmentResult);notePnl(s,t,Math.max(0,r),Math.max(0,-r),{allowGroup:true});}
 if(hasDay){s.finance.revenueCollectionDays={...cursors,[t]:day};}return doc;
}
function collectReceivable(s,p){
 if(p.sourceRefs!==undefined&&!Array.isArray(p.sourceRefs))throw new Error('invalid-collection-source-refs');
 const n=String(p.number||''),item=financeRowByNumber(s,'receivables',n),inv=financeRowByNumber(s,'invoices',n);
 if(!item){if(inv?.status==='محصلة'&&inv.transferReference){if(p.company&&p.company!==inv.company)throw new Error('collection-company-mismatch');return {company:inv.company,amount:0,reference:inv.transferReference,idempotent:true};}throw new Error('receivable-not-found');}
 const t=requireCompany(s,item.company),a=Number(item.total??item.amount),b=book(s,t),reference=String(p.reference||`RCPT-${t}-${n}`);
 if(!inv||inv.kind!=='دخل'||inv.company!==t||(p.company&&p.company!==t)||!Number.isFinite(a)||a<=0||Math.abs(invoiceOutstanding(inv)-a)>.01)throw new Error('invalid-receivable-collection');
 if(findTransferByReference(s,reference))throw new Error('collection-reference-conflict');
 const balanceBefore=num(b.accounts[0].balance);b.accounts[0].balance+=a;const balanceAfter=num(b.accounts[0].balance);amendInvoice(s,inv,'invoice-collected',doc=>{doc.status='محصلة';doc.settledAt=now(s);doc.transferReference=reference;});removeReceivableByNumber(s,n);
 journal(s,t,`تحصيل ${n} · ${collectionProfile(t,s).channel}`,[{account:b.accounts[0].id,debit:a},{account:'ذمم مدينة',credit:a}],reference);
 recordCollection(s,{company:t,amount:a,reference,invoiceNumbers:[n],counterparty:inv.counterparty,channel:p.channel,sourceRefs:p.sourceRefs||[],purposeCategory:'تحصيل فاتورة/إيراد',purposeDetail:inv.note||collectionProfile(t,s).service,accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter});reconcile(s);return {company:t,amount:a,reference,idempotent:false,balanceBefore,balanceAfter};
}
// One player approval can collect every currently-open customer balance.  The existing per-invoice and due-date
// collection paths stay untouched.  A real incoming cheque cannot have multiple drawers, so the command creates one
// deposited cheque for each company + customer pair and links every invoice covered by that cheque.
function collectReceivablesByCheque(s,p={}){
 const companyFilter=p.company&&p.company!=='all'?requireCompany(s,p.company):null,requested=Array.isArray(p.numbers)?new Set(p.numbers.map(String)):null;
 const rows=s.finance.receivables.filter(row=>(!companyFilter||requireCompany(s,row.company)===companyFilter)&&(!requested||requested.has(String(row.number))));
 if(!rows.length)return {count:0,cheques:0,amount:0,companies:[]};
 const groups=new Map();
 for(const item of rows){
  const n=String(item.number||''),inv=financeRowByNumber(s,'invoices',n),t=requireCompany(s,item.company),a=Number(item.total??item.amount);
  if(!inv||inv.kind!=='دخل'||inv.company!==t||!Number.isFinite(a)||a<=0||Math.abs(invoiceOutstanding(inv)-a)>.01)throw new Error(`invalid-receivable-collection:${n}`);
  const drawer=String(inv.counterparty||item.counterparty||collectionProfile(t,s).source).trim();if(!drawer)throw new Error(`receivable-drawer-required:${n}`);
  const key=`${t}\u0000${drawer}`,group=groups.get(key)||{company:t,drawer,rows:[],amount:0};group.rows.push({item,inv,number:n,amount:a});group.amount+=a;groups.set(key,group);
 }
 const out={count:0,cheques:0,amount:0,companies:[],chequeIds:[]};
 withCollectionBatch(s,()=>{
  for(const group of groups.values()){
   const t=group.company,b=book(s,t),account=b.accounts[0],balanceBefore=num(account.balance),prefix=String(documentProfile(s,t).documentPrefix||t).toUpperCase(),id=`${prefix}-RCV-CHQ-${String(s.finance.paymentSequence++).padStart(6,'0')}`,numbers=group.rows.map(row=>row.number);
   if(findFinanceDocument(s,'cheques','id',id)||findTransferByIdOrReference(s,`${id}-DEP`))throw new Error('receivable-cheque-reference-conflict');
   const payee=companyName(s,t),drawerParty=partyMeta(s,group.drawer,'customer'),cheque={id,chequeNumber:id,company:t,companyName:payee,direction:'incoming',drawer:drawerParty.name||group.drawer,drawerPartyId:drawerParty.id,draweeBank:'بنك العميل المسحوب عليه',accountId:account.id,currency:'USD',amount:group.amount,note:`تحصيل جماعي للذمم · ${numbers.length} فاتورة`,purposeCategory:'تحصيل ذمم مدينة',purposeDetail:`إيداع شيك وارد يغطي ${numbers.length} فاتورة`,paymentMethod:'شيك وارد',beneficiary:payee,issuePlace:String(s.profile?.hq||'الرياض، المملكة العربية السعودية'),paymentPlace:'حساب الشركة الجاري',authorizedSignatory:'العميل/الجهة الدافعة',dueDay:Math.floor(now(s)/86400),status:'محصل',issuedAt:now(s),depositedAt:now(s),clearedAt:now(s),invoiceNumbers:numbers.slice(0,100),type:'شيك تحصيل وارد'};
   protectDocument(s,cheque,'receivable-cheque');insertFinanceRow(s,'cheques',cheque);account.balance+=group.amount;const balanceAfter=num(account.balance),reference=`${id}-DEP`;
   for(const row of group.rows){amendInvoice(s,row.inv,'invoice-collected',doc=>{doc.status='محصلة';doc.settledAt=now(s);doc.transferReference=reference;doc.collectionChequeId=id;doc.paymentMethod='شيك وارد';});removeReceivableByNumber(s,row.number);}
   journal(s,t,`تحصيل جماعي بشيك وارد · ${id}`,[{account:account.id,debit:group.amount},{account:'ذمم مدينة',credit:group.amount}],reference);
   recordCollection(s,{company:t,amount:group.amount,reference,invoiceNumbers:numbers,counterparty:group.drawer,channel:'إيداع وتحصيل شيك وارد',purposeCategory:'تحصيل ذمم مدينة',purposeDetail:cheque.purposeDetail,paymentMethod:'شيك وارد',chequeNumber:id,accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter});
   out.count+=group.rows.length;out.cheques++;out.amount+=group.amount;out.chequeIds.push(id);if(!out.companies.includes(t))out.companies.push(t);
  }
 });
 reconcile(s);return out;
}
// Build 358: on its due day a receivable with payment terms is collected (under the reference of its revenue) and a
// supplier payable with payment terms is paid by transfer when the company's account covers it; one it cannot cover
// stays open for the player (no overdraft). Rows without terms are never touched here.
function settleDueTerms(s,p={}){
 const day=Math.floor(num(p.day??Math.floor(now(s)/86400))),out={day,...(p.company?{company:requireCompany(s,p.company)}:{}),collected:0,collectedAmount:0,paid:0,paidAmount:0,unpaid:0};
 const company=p.company?requireCompany(s,p.company):null,index=dueTermsIndex(s,day),bounded=Number.isSafeInteger(Number(p.maxRows))&&Number(p.maxRows)>0,maxRows=bounded?Number(p.maxRows):Infinity,rowsFor=(bucket,processed)=>{const rows=company?(bucket.get(company)||[]):[...bucket.values()].flat();return rows.filter(row=>!processed.has(row));};
 const receivables=rowsFor(index.receivables,index.processedReceivables).slice(0,maxRows);for(const row of receivables)index.processedReceivables.add(row);
 withCollectionBatch(s,()=>{for(const row of receivables){const inv=financeRowByNumber(s,'invoices',row.number),reference=inv?.sourceRef&&!findTransferByReference(s,inv.sourceRef)?inv.sourceRef:undefined;const r=collectReceivable(s,{number:row.number,company:row.company,reference});out.collected++;out.collectedAmount+=num(r.amount);}});
 // A payable with an outstanding cheque is settled when that cheque is cashed, never also by transfer.
 const payables=rowsFor(index.payables,index.processedPayables).slice(0,Math.max(0,maxRows-receivables.length));for(const row of payables)index.processedPayables.add(row);
 for(const row of payables){if(payableCheques(s,row.number).some(cheque=>cheque.status==='صادر')){out.chequePending=(out.chequePending||0)+1;continue;}const t=requireCompany(s,row.company),a=num(row.total??row.amount);if(!hasFunds(s,t,a)){out.unpaid++;continue;}const r=settlePayable(s,{number:row.number,method:'transfer'});out.paid++;out.paidAmount+=num(r.amount);}
 if(bounded)out.remaining=rowsFor(index.receivables,index.processedReceivables).length+rowsFor(index.payables,index.processedPayables).length;
 return out;
}
// Build 358: why a cheque cannot be issued for a payable (null when it can), checked before a bulk command dispatches,
// so one such payable is skipped with its reason instead of rejecting the whole batch.
function payableChequeBlocker(s,number){
 const n=String(number||''),item=financeRowByNumber(s,'payables',n);if(!item)return 'payable-not-found';
 const inv=findFinanceDocument(s,'invoices','number',n);if(!inv)return 'cheque-linked-payable-not-found';
 if(inv.payrollShortfall===true||item.payrollShortfall===true)return 'payroll-cheque-not-supported';
 if(inv.kind!=='مصروف'||['مدفوعة','مسددة','محصلة'].includes(inv.status))return 'cheque-linked-invoice-not-payable';
 if(payableCheques(s,n).some(ch=>ch?.status==='صادر'))return 'cheque-already-issued';
 let t;try{t=requireCompany(s,item.company);}catch{return 'cheque-linked-company-mismatch';}if(requireCompany(s,inv.company)!==t)return 'cheque-linked-company-mismatch';
 const a=num(item.total??item.amount);if(a<=0||Math.abs(num(inv.total??inv.amount)-a)>.01)return 'cheque-linked-amount-mismatch';
 return null;
}
function settlePayable(s,p){
  const n=String(p.number||''),item=financeRowByNumber(s,'payables',n);if(!item)throw new Error('payable-not-found');
  const t=requireCompany(s,item.company),a=num(item.total??item.amount),inv=findFinanceDocument(s,'invoices','number',n),line=inv?.budgetLine||item.budgetLine||lineFor(inv?.note||item.note||'',inv?.method||item.method||''),reserved=num(inv?.budgetReserved),budgetObligation=inv?.budgetObligation===true,payroll=inv?.payrollShortfall===true||item.payrollShortfall===true,linkedReport=s.finance.payrollReports.find(row=>row.id===(inv?.payrollReportId||item.payrollReportId)||row.lines?.some(reportLine=>reportLine.dueRef===n)),reportId=linkedReport?.id||null,b=book(s,t),method=String(p.method||'transfer');
  if(method==='cheque'){
    if(payroll)throw new Error('payroll-cheque-not-supported');
    const beneficiary=formalCounterparty(s,t,'مصروف',inv?.counterparty||item.counterparty),cheque=issueCheque(s,{company:t,amount:a,beneficiary,invoiceNumber:n,note:inv?.note||item.note||`سداد ${n}`,dueDay:p.dueDay??item.dueDay,requestRef:p.requestRef||`PAYABLE-CHQ-${n}`,draweeBank:p.draweeBank,issuePlace:p.issuePlace,paymentPlace:p.paymentPlace,authorizedSignatory:p.authorizedSignatory});
    return {company:t,amount:a,method:'cheque',status:'issued',chequeId:cheque.id,reference:cheque.id,idempotent:cheque.idempotent===true};
  }
  if(method!=='transfer')throw new Error('invalid-payable-settlement-method');
  const linkedCheques=payableCheques(s,n);if(linkedCheques.some(cheque=>cheque.status==='صادر'))throw new Error('payable-cheque-pending');const returnedCheques=linkedCheques.filter(cheque=>cheque.status==='مرتجع');
  if(!hasFunds(s,t,a))throw new Error('insufficient-cash');if(!payroll&&!reserved&&!budgetObligation&&!canSpend(s,t,a,line))throw new Error('insufficient-budget');
  coverInfiniteFunds(s,t,a,'ذمم مستحقة');const balanceBefore=num(b.accounts[0].balance);b.accounts[0].balance-=a;const balanceAfter=num(b.accounts[0].balance),budgetedAmount=Math.min(a,reserved);if(budgetedAmount>0)consumeReserved(s,t,budgetedAmount,line);if(!budgetObligation&&a>budgetedAmount)consumeBudget(s,t,a-budgetedAmount,line);
  if(inv)amendInvoice(s,inv,'invoice-payable-settled',doc=>{doc.status='مسددة';doc.settledAt=now(s);doc.budgetReserved=0;doc.paymentMethod='تحويل بنكي';if(!payroll)doc.transferReference=`PAY-${n}`;});s.finance.payables=s.finance.payables.filter(x=>x.number!==n);
  if(payroll&&linkedReport){const reportLine=linkedReport.lines?.find(row=>row.dueRef===n||(row.company===t&&num(row.due)>0));if(reportLine)amendProtectedDocument(s,linkedReport,'payroll-report','payroll-report-settled',report=>{const line=report.lines?.find(row=>row.dueRef===n||(row.company===t&&num(row.due)>0));line.paid=num(line.paid)+a;line.due=Math.max(0,num(line.amount)-num(line.paid));line.settledAt=now(s);report.paid=report.lines.reduce((sum,row)=>sum+num(row.paid),0);report.total=report.lines.reduce((sum,row)=>sum+num(row.amount),0);report.due=Math.max(0,report.total-report.paid);report.status=report.due>0?'مسجل مع رواتب مستحقة':'مصروف بالكامل';if(report.due===0)report.settledAt=now(s);});}
  const beneficiary=formalCounterparty(s,t,payroll?'مصروف':'مصروف',inv?.counterparty||item.counterparty),payee=partyMeta(s,beneficiary,payroll?'employee':'supplier'),purpose=inv?.note||item.note||`سداد ${n}`,note=`${payroll?'صرف رواتب مستحقة':'سداد'} ${n} · ${purpose}`;journal(s,t,note,[{account:'ذمم دائنة',debit:a},{account:b.accounts[0].id,credit:a}],n);let reference='';
  if(payroll){const formal=findPayrollTransferByDocument(s,n);reference=formal?.reference||`PAYTR-${reportId||n}-${t}-DUE`;if(formal){amendProtectedDocument(s,formal,formal.documentType||'payroll-payable','payroll-transfer-settled',row=>{row.kind='payroll-transfer';row.label='حوالة رواتب مستحقة منفذة';row.status='منفذة';row.from=b.accounts[0].id;row.settledAt=now(s);});}else{const payrollTransfer={id:reference,reference,at:now(s),from:b.accounts[0].id,to:payee.name||beneficiary,toPartyId:payee.id,amount:a,note,company:t,kind:'payroll-transfer',label:'حوالة رواتب مستحقة منفذة',status:'منفذة',documentNumber:n,payrollReportId:reportId};protectDocument(s,payrollTransfer,'payroll-transfer');insertFinanceTransfer(s,payrollTransfer);}}
  const transferRef=reference||`PAY-${n}`,entry={id:transferRef,at:now(s),from:b.accounts[0].id,to:payee.name||beneficiary,toPartyId:payee.id,amount:a,note,purposeCategory:payroll?'رواتب':'سداد ذمة مورد',purposeDetail:purpose,paymentMethod:'تحويل بنكي',label:payroll?'حوالة رواتب مستحقة منفذة':'حوالة سداد ذمة',company:t,kind:payroll?'payroll-transfer':'payable-settlement',documentNumber:n,payrollReportId:reportId,reference:transferRef,status:'منفذة',accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter};
  if(returnedCheques.length){entry.cancelledChequeIds=returnedCheques.map(cheque=>cheque.id);for(const cheque of returnedCheques)amendProtectedDocument(s,cheque,'cheque','cheque-cancelled',row=>{row.status='ملغى';row.cancelledAt=now(s);row.cancelReason='سداد الذمة بتحويل بنكي بعد ارتجاع الشيك';row.settlementReference=transferRef;});}
  if(!payroll){protectDocument(s,entry,'payable-settlement');insertFinanceTransfer(s,{...entry});}ledger(s,t,entry);if(!payroll)recordWorldFinance(s,{partyId:payee.id,counterparty:entry.to,company:t,direction:'outgoing',amount:a,reference:transferRef,transferRef,documentNumber:n,note,settled:true});reconcile(s);return {company:t,amount:a,payroll,reportId,method:'transfer',reference:transferRef,balanceBefore,balanceAfter};
}
function payTaxes(s,p){
 const t=requireCompany(s,p.company),periods=s.finance.periods.filter(x=>requireCompany(s,x.company)===t&&x.status==='مستحق'),a=cents(periods.reduce((n,x)=>n+num(x.amount),0)),b=book(s,t);if(a<=0)return {company:t,amount:0,count:0};if(!hasFunds(s,t,a))throw new Error('insufficient-cash');
 // Build 358: VAT is paid by a cheque drawn to the tax authority and cashed at once (no government transfer); the
 // settlement sheet keeps its number and records the cheque as its payment reference.
 coverInfiniteFunds(s,t,a,'ضريبة');const account=b.accounts[0],sequence=s.finance.taxSettlementSequence++,settlementId=`TAX-SET-${t==='group'?'GH':t.toUpperCase()}-${String(sequence).padStart(6,'0')}`,taxAuthority=String(p.taxAuthority||'هيئة الزكاة والضريبة والجمارك'),purposeDetail=`تسوية ${periods.map(x=>x.period).join(' · ')}`;
 const cheque=issueCheque(s,{company:t,amount:a,beneficiary:taxAuthority,note:'سداد ضريبة القيمة المضافة المستحقة',purposeCategory:'سداد ضريبة القيمة المضافة',purposeDetail,requestRef:`TAX-CHQ-${settlementId}`}),paymentReference=cheque.id;
 const balanceBefore=num(account.balance);account.balance-=a;const balanceAfter=num(account.balance);amendProtectedDocument(s,cheque,'cheque','cheque-cleared',row=>{row.status='مصروف';row.clearedAt=now(s);row.taxSettlementId=settlementId;});
 const entry=journal(s,t,`صرف ${cheque.id} · سداد فترات ضريبة القيمة المضافة المستحقة`,[{account:'ضريبة VAT مستحقة',debit:a},{account:account.id,credit:a}],paymentReference);
 ledger(s,t,{at:now(s),from:account.id,to:taxAuthority,amount:a,note:`صرف شيك سداد ضريبة القيمة المضافة · ${cheque.id}`,purposeCategory:'سداد ضريبة القيمة المضافة',purposeDetail,paymentMethod:'شيك مصرفي',chequeNumber:cheque.id,label:'صرف شيك ضريبي',company:t,kind:'tax-settlement',documentNumber:settlementId,reference:paymentReference,status:'منفذة',accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter});
 const registry=t==='group'?s.profile:(s.companyRegistry?.[t]||{}),settlement={id:settlementId,settlementNumber:settlementId,company:t,companyName:companyName(s,t),taxAuthority,taxNumber:companyTaxNumber(s,t),taxType:'ضريبة القيمة المضافة (VAT)',periodIds:periods.map(x=>x.id),periods:periods.map(x=>x.period),originalAmount:a,adjustments:0,amountPaid:a,remaining:0,accountId:account.id,accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter,paidAt:now(s),paymentMethod:'شيك مصرفي',chequeId:cheque.id,paymentReference,journalEntryId:entry.id,status:'مسددة بالكامل'};protectDocument(s,settlement,'tax-settlement');s.finance.taxSettlements.unshift(settlement);s.finance.taxSettlements=s.finance.taxSettlements.slice(0,400);
 b.taxPaid=cents(b.taxPaid+a);periods.forEach(period=>amendProtectedDocument(s,period,'vat-assessment','vat-assessment-paid',row=>{row.status='مسدد';row.paidAt=now(s);row.settlementId=settlementId;row.paymentReference=paymentReference;row.journalEntryId=entry.id;}));refreshBookTaxPayable(s,t);reconcile(s);return {company:t,amount:a,count:periods.length,settlementId,chequeId:cheque.id,paymentMethod:'cheque',paymentReference,journalEntryId:entry.id,settlement};
}
function issueCheque(s,p){
  const t=requireCompany(s,p.company),a=num(p.amount),invoiceNumber=String(p.invoiceNumber||''),linked=invoiceNumber?findFinanceDocument(s,'invoices','number',invoiceNumber):null,payable=invoiceNumber?financeRowByNumber(s,'payables',invoiceNumber):null,requestRef=String(p.requestRef||'');
  if(invoiceNumber){if(!linked||!payable)throw new Error('cheque-linked-payable-not-found');if(requireCompany(s,linked.company)!==t||requireCompany(s,payable.company)!==t)throw new Error('cheque-linked-company-mismatch');if(linked.kind!=='مصروف'||['مدفوعة','مسددة','محصلة'].includes(linked.status))throw new Error('cheque-linked-invoice-not-payable');if(Math.abs(num(linked.total??linked.amount)-a)>.01||Math.abs(num(payable.total??payable.amount)-a)>.01)throw new Error('cheque-linked-amount-mismatch');const beneficiary=String(p.beneficiary||'').trim(),counterparty=String(linked.counterparty||payable.counterparty||'').trim();if(beneficiary&&counterparty&&beneficiary!==counterparty)throw new Error('cheque-linked-beneficiary-mismatch');const existing=findFinanceDocument(s,'cheques','invoiceNumber',invoiceNumber,row=>row.status==='صادر');if(existing)return {...existing,idempotent:true};}
  if(requestRef){const prior=findFinanceDocument(s,'cheques','requestRef',requestRef,row=>!['مرتجع','ملغى'].includes(row.status));if(prior){if(prior.company!==t||Math.abs(num(prior.amount)-a)>.01||String(prior.invoiceNumber||'')!==invoiceNumber||String(prior.beneficiary)!==String(p.beneficiary||linked?.counterparty||''))throw new Error('cheque-request-conflict');return {...prior,idempotent:true};}}
  if(a<=0)throw new Error('invalid-cheque-amount');const beneficiary=formalCounterparty(s,t,'مصروف',String(p.beneficiary||linked?.counterparty||payable?.counterparty||'').trim());if(!beneficiary)throw new Error('cheque-beneficiary-required');
  const payee=partyMeta(s,beneficiary,'supplier'),id=`${String(documentProfile(s,t).documentPrefix||t).toUpperCase()}-CHQ-${String(s.finance.paymentSequence++).padStart(6,'0')}`,issuer=companyName(s,t),dueDay=Math.max(Math.floor(now(s)/86400),Math.floor(Number(p.dueDay) || linked?.dueDay || payable?.dueDay || Math.floor(now(s)/86400))),purpose=String(p.note||linked?.note||payable?.note||'سداد التزام تجاري');
  const r={id,chequeNumber:id,company:t,companyName:issuer,drawer:issuer,draweeBank:String(p.draweeBank||'Ventora Treasury Bank'),accountId:book(s,t).accounts[0].id,currency:String(p.currency||'USD'),amount:a,note:purpose,purposeCategory:String(p.purposeCategory||(invoiceNumber?'سداد ذمة بالشيك':'دفعة تجارية بالشيك')),purposeDetail:String(p.purposeDetail||purpose),paymentMethod:'شيك مصرفي',beneficiary:payee.name||beneficiary,beneficiaryPartyId:payee.id,issuePlace:String(p.issuePlace||s.profile?.hq||'الرياض، المملكة العربية السعودية'),paymentPlace:String(p.paymentPlace||'المركز المالي الرئيسي'),authorizedSignatory:String(p.authorizedSignatory||s.profile?.founder||'المفوض بالتوقيع'),dueDay,status:'صادر',issuedAt:now(s),invoiceNumber,requestRef:requestRef||null,type:p.type||'شيك مصرفي'};
  const chequeIndex=financeListIndex(s,'cheques'),replacementCandidates=chequeIndex?new Set([...(invoiceNumber?chequeIndex.byField.get('invoiceNumber').get(invoiceNumber)||[]:[]),...(requestRef?chequeIndex.byField.get('requestRef').get(requestRef)||[]:[])]):s.finance.cheques;
  for(const old of replacementCandidates)if(old.status==='مرتجع'&&(invoiceNumber&&old.invoiceNumber===invoiceNumber||requestRef&&old.requestRef===requestRef))amendProtectedDocument(s,old,'cheque','cheque-cancelled',row=>{row.status='ملغى';row.replacedBy=id;row.cancelledAt=now(s);row.cancelReason='إعادة إصدار الشيك المرتجع';});
  protectDocument(s,r,'cheque');insertFinanceRow(s,'cheques',r);if(linked)amendInvoice(s,linked,'invoice-cheque-issued',row=>{row.chequeId=id;row.paymentMethod='شيك مصرفي';row.status='شيك صادر';});return r;
}
// Validate the forward posting, never recover a small movement by subtracting huge balances.
// Called inside the financial transaction; evidence is bounded and allocated only on failure.
function assertAccountPosting(s,receipt,expected={}){
 const company=expected.company??receipt?.company,account=book(s,company).accounts[0],before=receipt?.balanceBefore,after=receipt?.balanceAfter,amount=receipt?.amount,actual=account.balance;
 const expectedAfter=before+amount;
 if(receipt?.company!==company||receipt?.accountId!==account.id||!String(receipt?.reference||'').trim()||expected.reference!==undefined&&receipt.reference!==expected.reference||expected.balanceBefore!==undefined&&before!==expected.balanceBefore||expected.amount!==undefined&&amount!==expected.amount||![before,after,amount,actual,expectedAfter].every(Number.isFinite)||after!==expectedAfter||actual!==after){
  const error=new Error(expected.code||`finance-account-posting-mismatch:${company}`);error.code='FINANCE_ACCOUNT_POSTING_MISMATCH';
  error.postingEvidence={company:String(company).slice(0,120),accountId:String(account.id).slice(0,120),reference:String(receipt?.reference||'').slice(0,160),before,after,appliedAmount:amount,expectedAfter,actual,difference:actual-expectedAfter};throw error;
 }
 return true;
}
function unchangedDailySettlement(s,company,reference,details){const account=book(s,company).accounts[0],balance=account.balance;const result={company,amount:0,reference,accountId:account.id,balanceBefore:balance,balanceAfter:balance,...details};assertAccountPosting(s,result,{company,reference});return result;}
function chequeResult(c,settled,reason,posting=null){return {id:c.id,settled,status:settled?'settled':'bounced',reason,company:c.company,amount:c.amount,invoiceNumber:c.invoiceNumber||null,requestRef:c.requestRef||null,...(posting?{posting}: {})};}
function chequeFunding(s,t,a,c,inv,lineOverride=null){
 const line=lineOverride||inv?.budgetLine||lineFor(c.note,'شيك'),reserved=num(inv?.budgetReserved),budgetObligation=inv?.budgetObligation===true;
 const blocker=!hasFunds(s,t,a)?'insufficient-cash':!reserved&&!budgetObligation&&!canSpend(s,t,a,line)?'insufficient-budget':null;
 return {line,reserved,budgetObligation,blocker};
}
// The bulk action checks the same funding rule as settlement before dispatching. A blocked cheque stays issued rather
// than bouncing or aborting payments for other companies; the individual settlement command keeps its bounce behavior.
function chequeFundingBlocker(s,c){
 if(!c)throw new Error('cheque-not-found');const t=requireCompany(s,c.company),a=num(c.amount),inv=c.invoiceNumber?financeRowByNumber(s,'invoices',c.invoiceNumber):null;
 return chequeFunding(s,t,a,c,inv).blocker;
}
function settleCheque(s,p){
 const c=findFinanceDocument(s,'cheques','id',p.id);if(!c)throw new Error('cheque-not-found');if(c.status==='ملغى')throw new Error('cheque-cancelled');if(c.status==='مصروف')return chequeResult(c,true,'already-settled');
 const t=requireCompany(s,c.company),a=num(c.amount),inv=c.invoiceNumber?financeRowByNumber(s,'invoices',c.invoiceNumber):null,payable=c.invoiceNumber?financeRowByNumber(s,'payables',c.invoiceNumber):null;
 if(c.invoiceNumber){if(!inv||!payable)throw new Error('cheque-linked-payable-not-found');if(requireCompany(s,inv.company)!==t||requireCompany(s,payable.company)!==t)throw new Error('cheque-linked-company-mismatch');if(inv.kind!=='مصروف'||['مدفوعة','مسددة','محصلة'].includes(inv.status))throw new Error('cheque-linked-invoice-not-payable');if(Math.abs(num(inv.total??inv.amount)-a)>.01||Math.abs(num(payable.total??payable.amount)-a)>.01)throw new Error('cheque-linked-amount-mismatch');const counterparty=String(inv.counterparty||payable.counterparty||'').trim();if(counterparty&&String(c.beneficiary||'').trim()!==counterparty)throw new Error('cheque-linked-beneficiary-mismatch');}
 const funding=chequeFunding(s,t,a,c,inv,p.line),line=funding.line,reserved=funding.reserved,budgetObligation=funding.budgetObligation,b=book(s,t);
 if(funding.blocker){amendProtectedDocument(s,c,'cheque','cheque-returned',row=>{row.status='مرتجع';row.returnedAt=now(s);});if(inv)amendInvoice(s,inv,'invoice-cheque-returned',row=>{row.status='شيك مرتجع';});return chequeResult(c,false,'insufficient-funds-or-budget');}
 coverInfiniteFunds(s,t,a,'صرف شيك');const balanceBefore=b.accounts[0].balance;b.accounts[0].balance-=a;const budgetedAmount=Math.min(a,reserved);if(budgetedAmount>0)consumeReserved(s,t,budgetedAmount,line);if(!budgetObligation&&a>budgetedAmount)consumeBudget(s,t,a-budgetedAmount,line);amendProtectedDocument(s,c,'cheque','cheque-cleared',row=>{row.status='مصروف';row.clearedAt=now(s);});
 if(payable){if(inv)amendInvoice(s,inv,'invoice-cheque-cleared',row=>{row.status='مسددة';row.settledAt=now(s);row.budgetReserved=0;});s.finance.payables=s.finance.payables.filter(x=>x.number!==c.invoiceNumber);journal(s,t,`صرف ${c.id} · تسوية ${c.invoiceNumber}`,[{account:'ذمم دائنة',debit:a},{account:b.accounts[0].id,credit:a}],c.id);}else journal(s,t,`صرف ${c.id} · ${c.note}`,[{account:'مصروف تشغيلي',debit:a},{account:b.accounts[0].id,credit:a}],c.id);
 const payee=inv?.counterpartyPartyId?{id:inv.counterpartyPartyId,name:inv.counterparty}:partyMeta(s,c.beneficiary,'supplier'),entry={at:now(s),from:b.accounts[0].id,to:payee.name||c.beneficiary,toPartyId:payee.id||c.beneficiaryPartyId||null,amount:a,note:c.note||`صرف ${c.id}`,purposeCategory:c.purposeCategory||'سداد بالشيك',purposeDetail:c.purposeDetail||c.note||'سداد التزام',paymentMethod:'شيك مصرفي',chequeNumber:c.id,label:'تسوية شيك مصرفي',company:t,kind:'cheque-settlement',documentNumber:c.invoiceNumber||null,reference:c.id,status:'منفذة'};ledger(s,t,entry);recordWorldFinance(s,{partyId:entry.toPartyId,counterparty:entry.to,company:t,direction:'outgoing',amount:a,reference:c.id,transferRef:c.id,documentNumber:c.invoiceNumber||null,note:c.note||entry.note,settled:true});reconcile(s);const posting={company:t,accountId:b.accounts[0].id,reference:c.id,amount:-a,balanceBefore,balanceAfter:b.accounts[0].balance};assertAccountPosting(s,posting,{company:t,reference:c.id,amount:-a,code:'cheque-current-account-posting-mismatch'});return chequeResult(c,true,'settled',posting);
}
function payByCheque(s,p={}){
  const t=requireCompany(s,p.company),a=num(p.amount),beneficiary=String(p.beneficiary||p.counterparty||'').trim(),line=p.line||lineFor(p.note,'شيك مصرفي');
  if(a<=0)throw new Error('invalid-cheque-amount');if(!beneficiary)throw new Error('cheque-beneficiary-required');
  // Resolve retries before accruing an invoice. A key can never fund a different purchase.
  const requestRef=String(p.requestRef||''),fingerprint=JSON.stringify([t,a,beneficiary,String(p.note||'شراء من مورد'),p.taxable!==false,line,String(p.number||'')]);
  const prior=requestRef?findFinanceDocument(s,'cheques','requestRef',requestRef):null;
  let doc;
  if(prior){
    doc=findFinanceDocument(s,'invoices','number',prior.invoiceNumber);
    if(!doc||prior.company!==t||Math.abs(num(prior.amount)-a)>.01||prior.beneficiary!==beneficiary||prior.paymentFingerprint&&prior.paymentFingerprint!==fingerprint||String(doc.note)!==String(p.note||'شراء من مورد')||p.number&&doc.number!==p.number)throw new Error('cheque-request-conflict');
    if(prior.status==='مصروف'){if(doc.status!=='مسددة')throw new Error('cheque-payment-inconsistent');return {reference:prior.id,invoice:doc,cheque:prior,settlement:chequeResult(prior,true,'already-settled'),idempotent:true};}
  }else doc=accrue(s,{company:t,amount:a,note:p.note||'شراء من مورد',method:'شيك مصرفي',taxable:p.taxable!==false,counterparty:beneficiary,dueDay:p.dueDay??Math.floor(now(s)/86400),number:p.number,line});
  const cheque=issueCheque(s,{company:t,amount:a,note:p.note||'شراء من مورد',beneficiary,invoiceNumber:doc.number,requestRef:p.requestRef||null,type:p.type||'شيك مصرفي',line,draweeBank:p.draweeBank,issuePlace:p.issuePlace,paymentPlace:p.paymentPlace,authorizedSignatory:p.authorizedSignatory,dueDay:p.dueDay});
  amendProtectedDocument(s,cheque,'cheque','cheque-request-linked',row=>{row.paymentFingerprint=fingerprint;});
  const settlement=settleCheque(s,{id:cheque.id,line});if(!settlement.settled)throw new Error(`cheque-settlement-failed:${settlement.reason}`);
  return {reference:cheque.id,invoice:doc,cheque,settlement};
}
function founderInvestment(s,p){const t=requireCompany(s,p.company),a=num(p.amount);if(a<=0)throw new Error('invalid-amount');const b=book(s,t),founder=s.profile?.founder||'المؤسس',id=p.ref||nextFinanceTransferReference(s,'FND'),prior=findTransferById(s,id)||s.treasury.ledger.find(x=>x.reference===id);if(prior){if(prior.company!==t||Math.abs(num(prior.amount)-a)>.01)throw new Error('founder-investment-reference-conflict');return {ref:id,amount:0,company:t,idempotent:true};}b.accounts[0].balance+=a;const transfer={id,reference:id,at:now(s),kind:'founder-investment',label:p.godMode?'حوالة واردة من المؤسس · وضع التجربة':'حوالة استثمار واردة',from:`المستثمر · ${founder}`,to:companyName(s,t),toAccount:b.accounts[0].id,amount:a,company:t,beneficiaryCompany:t,status:'منفذة',note:p.note||'استثمار المؤسس'};if(p.godMode)transfer.fundingSource='god-mode-founder';protectDocument(s,transfer,'founder-investment');insertFinanceTransfer(s,{...transfer});ledger(s,t,transfer);journal(s,t,`${id} · استثمار المؤسس`,[{account:b.accounts[0].id,debit:a},{account:'حقوق ملكية المؤسس',credit:a}],id);reconcile(s);return {ref:id,amount:a,company:t,documentProofId:transfer.documentProofId,contentDigest:transfer.contentDigest};}
function founderWithdrawal(s,p){const t=requireCompany(s,p.company),requested=num(p.amount),b=book(s,t);if(requested<=0||operating(s,t)<requested)throw new Error('insufficient-cash');const a=requested,founder=s.profile?.founder||'المؤسس',id=p.ref||nextFinanceTransferReference(s,'FND-WD'),prior=findTransferById(s,id)||s.treasury.ledger.find(x=>x.reference===id);if(prior){if(prior.company!==t||Math.abs(num(prior.amount)-a)>.01)throw new Error('founder-withdrawal-reference-conflict');return {ref:id,amount:0,company:t,idempotent:true};}b.accounts[0].balance-=a;const transfer={id,reference:id,at:now(s),kind:'founder-withdrawal',label:'سحب رأس مال للمؤسس',from:companyName(s,t),fromAccount:b.accounts[0].id,to:`المستثمر · ${founder}`,amount:a,company:t,status:'منفذة',note:p.note||'تسوية رأسمالية'};protectDocument(s,transfer,'founder-withdrawal');insertFinanceTransfer(s,{...transfer});ledger(s,t,transfer);journal(s,t,`${id} · سحب رأسمالي للمؤسس`,[{account:'حقوق ملكية المؤسس',debit:a},{account:b.accounts[0].id,credit:a}],id);reconcile(s);return {ref:id,amount:a,company:t,documentProofId:transfer.documentProofId,contentDigest:transfer.contentDigest};}

function refreshIdentity(s,p){const t=requireCompany(s,p.company),name=companyName(s,t);for(const bucket of [s.finance?.invoices,s.finance?.cheques,s.finance?.payables,s.finance?.receivables,s.finance?.periods])for(let index=0;index<(bucket||[]).length;index++){const current=bucket[index];if(requireCompany(s,current.company)===t&&!current.contentDigest&&(current.company!==t||current.companyName!==name||'logo' in current||'companyLogo' in current||'issuerLogo' in current)){const doc=writableRow(bucket,index);doc.company=t;doc.companyName=name;delete doc.logo;delete doc.companyLogo;delete doc.issuerLogo;}}const ledgerRows=s.treasury?.ledger||[];for(let index=0;index<ledgerRows.length;index++){const entry=ledgerRows[index];if(entry.contentDigest)continue;const company=entry.company===t&&entry.companyName!==name,beneficiary=entry.beneficiaryCompany===t&&entry.beneficiaryName!==name;if(!company&&!beneficiary)continue;const row=writableRow(ledgerRows,index);if(company)row.companyName=name;if(beneficiary)row.beneficiaryName=name;}return name;}
// External debt bears interest. A bond pays the fixed rate it was issued at; a credit line and asset finance pay the
// market base rate (GH_REALISM economy, moved hourly) plus the spread of the group's credit rating, so a lower rating
// costs more the next day. Energy project finance is charged by Energy Core from its own schedule (debtSchedule).
const RATING_SPREAD=Object.freeze({'A':.009,'A-':.011,'BBB+':.014,'BBB':.017,'BBB-':.021,'BB+':.029,'BB':.036}),PROJECT_FINANCE_ACCOUNT='تمويل مشاريع طاقة';
function marketBaseRate(s){const rate=Number(s.realism?.economy?.baseRate);return Number.isFinite(rate)&&rate>0?rate:.046;}
// Build 359: the climate disclosure programme narrows the spread (up to 0.25 points), never below 0.3 points.
function creditSpread(s){const base=RATING_SPREAD[String(s.profile?.creditRating||'BBB')]??RATING_SPREAD.BBB,programme=Number(globalThis.GH_GOVERNANCE_CORE?.programEffects?.(s)?.creditSpread)||0;return Math.max(.003,base+programme);}
function floatingDebtRate(s){return marketBaseRate(s)+creditSpread(s);}
function fixedDebtQuote(s,termDays){return Math.round((floatingDebtRate(s)+Math.min(.005,Math.max(0,num(termDays))/365*.001))*1e5)/1e5;}
function debtRate(s,row){const fixed=Number(row?.annualRate);return Number.isFinite(fixed)&&fixed>0?fixed:floatingDebtRate(s);}
function interestBearing(row,s=null){return (s?debtOutstanding(s,row):num(row?.outstanding))>0&&row?.liabilityAccount!==PROJECT_FINANCE_ACCOUNT;}
// The daily close bills each company one day of interest on its open debt as a lender invoice on 7-day terms,
// paid by settle-due-terms like any supplier bill (left open when the account cannot cover it).
function accrueDebtInterest(s,p){
 const t=requireCompany(s,p.company),day=Math.floor(Number(p.day));if(!Number.isFinite(day)||day<0)throw new Error('invalid-interest-day');
 const last=s.finance.debtInterestDays[t];if(Number(last)>=day)return {company:t,day,amount:0,idempotent:true};
 const rows=s.finance.debtRecords.filter(row=>row.company===t&&interestBearing(row,s));s.finance.debtInterestDays[t]=day;
 const amount=Math.round(rows.reduce((sum,row)=>sum+debtOutstanding(s,row)*debtRate(s,row)/365,0)*100)/100;if(amount<.01)return {company:t,day,amount:0};
 const lenders=[...new Set(rows.map(row=>row.lender))],doc=accrue(s,{company:t,amount,note:`فوائد يوم ${day} على ${rows.length===1?'دين واحد':`${rows.length} ديون`}`,method:'فاتورة فوائد',taxable:false,dueDay:day+7,number:`INT-${t.toUpperCase()}-${day}`,paymentTerms:7,counterparty:lenders.length===1?lenders[0]:'مقرضو المجموعة',line:'other'});
 return {company:t,day,amount,number:doc.number};
}
function raiseDebt(s,p){const t=requireCompany(s,p.company),a=num(p.amount);if(a<=0)throw new Error('invalid-amount');const b=book(s,t),id=String(p.ref||`DEBT-${Math.floor(now(s))}-${b.ledger.length+1}`),lender=formalCounterparty(s,t,'مصروف',p.lender||`بنك التمويل المؤسسي — ${companyName(s,t)}`),liabilityAccount=String(p.liabilityAccount||'تسهيلات ائتمانية مستحقة'),issuedAt=now(s),termDays=Math.max(0,Math.floor(Number(p.termDays)||0)),dueDay=termDays?Math.floor(issuedAt/86400)+termDays:null,annualRate=p.fixedRate===true?fixedDebtQuote(s,termDays):null,prior=s.finance.debtRecords.find(x=>x.id===id);if(prior){if(prior.company!==t||Math.abs(num(prior.originalAmount)-a)>.01||prior.lender!==lender||prior.liabilityAccount!==liabilityAccount)throw new Error('debt-reference-conflict');return {ref:id,amount:0,debt:b.debt,idempotent:true,record:debtView(s,prior)};}b.accounts[0].balance+=a;b.debt=num(b.debt)+a;const j=journal(s,t,p.note||'تمويل دين',[{account:b.accounts[0].id,debit:a},{account:liabilityAccount,credit:a}],id),record={id,company:t,companyName:companyName(s,t),lender,type:liabilityAccount,liabilityAccount,originalAmount:a,outstanding:a,issuedAt,dueDay,status:'قائم',journalEntryId:j.id,note:String(p.note||'تمويل دين'),...(annualRate?{annualRate,rateBasis:'fixed'}:{rateBasis:'floating'})};protectDocument(s,record,'debt-financing');s.finance.debtRecords.unshift(record);setDebtOutstanding(s,record,a,issuedAt);ledger(s,t,{id,at:issuedAt,from:lender,to:b.accounts[0].id,amount:a,note:record.note,purposeCategory:'تمويل دين',purposeDetail:liabilityAccount,paymentMethod:'تحويل تمويل',company:t,kind:'debt-financing',reference:id,status:'منفذة'});reconcile(s);return {ref:id,amount:a,debt:b.debt,record:debtView(s,record)};}
function repayDebt(s,p){
 const t=requireCompany(s,p.company),b=book(s,t),debtId=String(p.debtId||''),requested=num(p.amount),explicitReference=String(p.ref||''),requestFingerprint=JSON.stringify([t,requested,debtId,String(p.liabilityAccount||''),String(p.lender||''),String(p.note||'سداد أصل دين')]);
 if(explicitReference){const prior=s.finance.debtSettlements.find(row=>row.id===explicitReference||row.reference===explicitReference);if(prior){if(prior.requestFingerprint&&prior.requestFingerprint!==requestFingerprint||prior.company!==t||prior.debtId!==(debtId||null)||Math.abs(num(prior.requestedAmount??prior.amount)-requested)>.01)throw new Error('debt-repayment-reference-conflict');return {amount:0,debt:num(b.debt),debtId:debtId||null,reference:explicitReference,settlement:clone(prior),idempotent:true};}}
 const allOpen=(s.finance.debtRecords||[]).filter(x=>x.company===t&&debtOutstanding(s,x)>.005).sort((x,y)=>(Number(x.issuedAt)||0)-(Number(y.issuedAt)||0)),open=debtId?allOpen.filter(x=>x.id===debtId):allOpen,targetOutstanding=debtId?debtOutstanding(s,open[0]):num(b.debt),a=Math.min(requested,targetOutstanding,num(b.debt));if(a<=0)return {amount:0,debt:num(b.debt),debtId:debtId||null};if(operating(s,t)<a)throw new Error('insufficient-cash');const sequence=s.finance.debtSettlementSequence++,reference=explicitReference||`DEBT-SET-${t==='group'?'GH':t.toUpperCase()}-${String(sequence).padStart(6,'0')}`,account=b.accounts[0],balanceBefore=num(account.balance);account.balance-=a;b.debt=Math.max(0,num(b.debt)-a);let remaining=a;const allocations=[];for(const record of open){if(remaining<=.005)break;const opening=debtOutstanding(s,record),paid=Math.min(remaining,opening);if(paid<=0)continue;setDebtOutstanding(s,record,opening-paid);allocations.push({debtId:record.id,lender:record.lender,liabilityAccount:record.liabilityAccount||record.type||'تسهيلات ائتمانية مستحقة',amount:paid});remaining-=paid;}const liabilityAccount=String(p.liabilityAccount||open[0]?.liabilityAccount||'تسهيلات ائتمانية مستحقة'),lender=String(p.lender||allocations[0]?.lender||open[0]?.lender||`ممول ${companyName(s,t)}`),debitLines=allocations.length?allocations.map(x=>({account:x.liabilityAccount||liabilityAccount,debit:x.amount})):[{account:liabilityAccount,debit:a}],j=journal(s,t,p.note||'سداد أصل دين',[...debitLines,{account:account.id,credit:a}],reference),balanceAfter=num(account.balance),settlement={id:reference,reference,company:t,companyName:companyName(s,t),lender,amount:a,requestedAmount:requested,requestFingerprint,debtId:debtId||null,allocations,accountId:account.id,accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter,paidAt:now(s),journalEntryId:j.id,status:'منفذة',note:String(p.note||'سداد أصل دين')};protectDocument(s,settlement,'debt-repayment');s.finance.debtSettlements.unshift(settlement);s.finance.debtSettlements=s.finance.debtSettlements.slice(0,400);const transfer={id:reference,reference,at:now(s),from:account.id,to:lender,amount:a,note:settlement.note,purposeCategory:'سداد أصل دين',purposeDetail:allocations.map(x=>x.debtId).join(' · ')||liabilityAccount,paymentMethod:'تحويل بنكي',company:t,kind:'debt-repayment',documentNumber:reference,status:'منفذة',accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter};protectDocument(s,transfer,'debt-payment-transfer');ledger(s,t,transfer);insertFinanceTransfer(s,{...transfer});reconcile(s);return {amount:a,debt:b.debt,debtId:debtId||null,reference,settlement};
}
function raiseEquity(s,p){const t=requireCompany(s,p.company),a=num(p.amount);if(a<=0)throw new Error('invalid-amount');const b=book(s,t),id=String(p.ref||nextFinanceTransferReference(s,'EQUITY')),prior=findTransferByIdOrReference(s,id);if(prior){if(prior.company!==t||prior.kind!=='equity-financing'||Math.abs(num(prior.amount)-a)>.01)throw new Error('equity-reference-conflict');return {ref:id,amount:0,idempotent:true,transfer:clone(prior)};}const account=b.accounts[0],balanceBefore=num(account.balance),source=String(p.source||'مستثمرون'),investor=partyMeta(s,source,'investor'),note=String(p.note||'زيادة رأس مال');account.balance+=a;const balanceAfter=num(account.balance),j=journal(s,t,note,[{account:account.id,debit:a},{account:p.equityAccount||'رأس مال وعلاوة إصدار',credit:a}],id),transfer={id,reference:id,at:now(s),from:investor.name||source,fromPartyId:investor.id,to:account.id,toAccount:account.id,company:t,beneficiaryCompany:t,amount:a,grossAmount:a,netAmount:a,note,purposeCategory:p.purposeCategory||'تمويل حقوق ملكية',purposeDetail:p.purposeDetail||String(p.equityAccount||'رأس مال وعلاوة إصدار'),paymentMethod:p.paymentMethod||'حوالة اكتتاب واردة',kind:'equity-financing',label:'حوالة تمويل حقوق ملكية',status:'منفذة',journalEntryId:j.id,accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter};protectDocument(s,transfer,'equity-financing');insertFinanceTransfer(s,transfer);ledger(s,t,transfer);recordWorldFinance(s,{partyId:investor.id,counterparty:transfer.from,company:t,direction:'incoming',amount:a,reference:id,transferRef:id,note,settled:true,news:true});reconcile(s);return {ref:id,amount:a,transfer};}
function settleMarketSecurityTrade(s,p={}){
 const company=requireCompany(s,p.company||'group'),side=String(p.side||''),symbol=String(p.symbol||''),reference=String(p.reference||'').trim(),quantity=Math.floor(Number(p.quantity)||0),amount=Number(p.amount),costBasis=Math.max(0,Number(p.costBasis)||0),gain=Number(p.realizedGain)||0;
 if(company!=='group'||!['buy','sell'].includes(side)||!/^[-A-Za-z0-9._]{1,20}$/.test(symbol)||!reference||quantity<1||!Number.isFinite(amount)||amount<=0)throw new Error('market-security-trade-invalid');
 if(side==='buy'&&(costBasis!==0||gain!==0)||side==='sell'&&costBasis<=0)throw new Error('market-security-trade-cost-invalid');
 const fingerprint=JSON.stringify([company,side,symbol,quantity,amount,costBasis,gain]),prior=findTransferByIdOrReference(s,reference);
 if(prior){if(prior.kind!=='market-security-trade'||prior.requestFingerprint!==fingerprint)throw new Error('market-security-trade-reference-conflict');return {...clone(prior),idempotent:true};}
 const b=book(s,company),account=b.accounts[0],before=num(account.balance);let lines;
 if(side==='buy'){
  if(!canSpend(s,company,amount,'capex'))throw new Error('insufficient-funds-or-budget');coverInfiniteFunds(s,company,amount,'شراء أسهم مدرجة');account.balance-=amount;consumeBudget(s,company,amount,'capex');lines=[{account:'استثمارات في أوراق مالية مدرجة',debit:amount},{account:account.id,credit:amount}];
 }else{
  account.balance+=amount;
  // Build 375: the holding leaves at its full cost; a sale below it was refused as an unbalanced entry (the loss was
  // debited while only the proceeds were credited), so a share that had fallen could never be sold.
  lines=[{account:account.id,debit:amount},{account:'استثمارات في أوراق مالية مدرجة',credit:costBasis}];
  if(amount>costBasis)lines.push({account:'أرباح محققة من بيع استثمارات',credit:amount-costBasis});else if(costBasis>amount)lines.push({account:'خسائر محققة من بيع استثمارات',debit:costBasis-amount});
 }
 if(side==='sell'&&Math.abs(gain-(amount-costBasis))>.02)throw new Error('market-security-trade-gain-mismatch');
 const j=journal(s,company,`${side==='buy'?'شراء':'بيع'} أسهم مدرجة ${symbol} · ${quantity} سهم`,lines,reference),transfer={id:reference,reference,at:now(s),company,from:side==='buy'?account.id:`سوق الأوراق المالية · ${symbol}`,to:side==='buy'?`سوق الأوراق المالية · ${symbol}`:account.id,amount,quantity,symbol,side,costBasis:side==='sell'?costBasis:amount,realizedGain:side==='sell'?gain:0,kind:'market-security-trade',label:side==='buy'?'شراء ورقة مالية':'تسوية بيع ورقة مالية',purposeCategory:side==='buy'?'شراء استثمار مالي':'بيع استثمار مالي',paymentMethod:'تسوية سوقية',status:'منفذة',journalEntryId:j.id,accountBalanceBefore:before,accountBalanceAfter:num(account.balance),requestFingerprint:fingerprint};
 protectDocument(s,transfer,'market-security-trade');insertFinanceTransfer(s,transfer);ledger(s,company,transfer);if(side==='sell'&&gain)notePnl(s,company,Math.max(0,gain),Math.max(0,-gain),{allowGroup:true});reconcile(s);return {...clone(transfer),idempotent:false};
}
function settleMarketDividend(s,p={}){
 const company=requireCompany(s,p.company||'group'),symbol=String(p.symbol||''),reference=String(p.reference||'').trim(),amount=Number(p.amount),quantity=Math.floor(Number(p.quantity)||0),period=Math.floor(Number(p.period)||0);
 if(company!=='group'||!/^[-A-Za-z0-9._]{1,20}$/.test(symbol)||!reference||!Number.isFinite(amount)||amount<=0||quantity<1||period<1)throw new Error('market-dividend-invalid');
 const fingerprint=JSON.stringify([company,symbol,reference,amount,quantity,period]),prior=findTransferByIdOrReference(s,reference);if(prior){if(prior.kind!=='market-security-dividend'||prior.requestFingerprint!==fingerprint)throw new Error('market-dividend-reference-conflict');return {...clone(prior),idempotent:true};}
 const b=book(s,company),account=b.accounts[0],before=num(account.balance);account.balance+=amount;const j=journal(s,company,`توزيعات استثمار مدرج ${symbol} · الفترة ${period}`,[{account:account.id,debit:amount},{account:'إيرادات توزيعات استثمارات',credit:amount}],reference),transfer={id:reference,reference,at:now(s),company,from:`وكيل توزيعات · ${symbol}`,to:account.id,amount,quantity,symbol,period,kind:'market-security-dividend',label:'توزيعات استثمار مدرج',purposeCategory:'تحصيل توزيعات استثمار',paymentMethod:'حوالة توزيعات',status:'منفذة',journalEntryId:j.id,accountBalanceBefore:before,accountBalanceAfter:num(account.balance),requestFingerprint:fingerprint};protectDocument(s,transfer,'market-security-dividend');insertFinanceTransfer(s,transfer);ledger(s,company,transfer);notePnl(s,company,amount,0,{allowGroup:true});reconcile(s);return {...clone(transfer),idempotent:false};
}

function zeroSectorMap(s){return companyMetricMap(s);}
function consumeTripAccruals(s){
  ensure(s);
  const result={
    profit:companyMetricMap(s,s.tripProfitAccrued,'trip-profit'),
    revenue:companyMetricMap(s,s.tripRevenueAccrued,'trip-revenue',{nonNegative:true}),
    fuel:companyMetricMap(s,s.tripFuelAccrued,'trip-fuel',{nonNegative:true}),
    maintenance:companyMetricMap(s,s.tripMaintenanceAccrued,'trip-maintenance',{nonNegative:true}),
    count:companyMetricMap(s,s.tripCountAccrued,'trip-count',{integer:true}),
    cash:companyMetricMap(s,s.finance.pendingDailyCash,'pending-daily-cash')
  };
  s.tripProfitAccrued=zeroSectorMap(s);s.tripRevenueAccrued=zeroSectorMap(s);s.tripFuelAccrued=zeroSectorMap(s);s.tripMaintenanceAccrued=zeroSectorMap(s);s.tripCountAccrued=zeroSectorMap(s);s.finance.pendingDailyCash=zeroSectorMap(s);
  return result;
}
function settleDailyCash(s,p={}){
  ensure(s);const t=requireCompany(s,p.company,{defaultGroup:false}),amount=Number(p.amount),day=Math.max(0,Math.floor(Number(p.day)||Math.floor(now(s)/86400))),reference=String(p.reference||`DAY-CASH-${t||'INVALID'}-${day}`);
  if(t==='group')throw new Error('invalid-daily-settlement-company');if(!Number.isFinite(amount))throw new Error('invalid-daily-settlement-amount');
  const prior=findTransferByIdOrReference(s,reference);if(prior){if(prior.company!==t||Math.abs(Number(prior.requestedAmount)-Math.abs(amount))>.01)throw new Error('daily-settlement-reference-conflict');return unchangedDailySettlement(s,t,reference,{idempotent:true,status:prior.status});}
  if(p.invoiceNumbers!==undefined&&(!Array.isArray(p.invoiceNumbers)||p.invoiceNumbers.length>20||p.invoiceNumbers.some(number=>!hasFinanceDocument(s,'invoices','number',number,row=>row.company===t))))throw new Error('invalid-settlement-invoices');
  if([p.grossAmount,p.deductions].some(value=>value!==undefined&&(!Number.isFinite(Number(value))||Number(value)<0)))throw new Error('invalid-settlement-breakdown');
  const settledDays=s.finance.dailySettlementDays||{};if(Number.isFinite(settledDays[t])&&day<=settledDays[t])return unchangedDailySettlement(s,t,reference,{idempotent:true,status:'منفذة سابقًا'});
  if(Math.abs(amount)<.005&&!(Number(p.grossAmount)>0))return unchangedDailySettlement(s,t,reference,{idempotent:false,status:'صفر'});
  const b=book(s,t),incoming=amount>=0,requested=Math.abs(amount),settled=incoming?requested:Math.min(requested,num(b.accounts[0].balance)),shortfall=Math.max(0,requested-settled),balanceBefore=num(b.accounts[0].balance);
  if(incoming)b.accounts[0].balance+=settled;else b.accounts[0].balance-=settled;const balanceAfter=num(b.accounts[0].balance);
  if(shortfall>0)s.finance.pendingDailyCash[t]=(Number(s.finance.pendingDailyCash[t])||0)-shortfall;
  const transfer={id:reference,reference,at:now(s),day,from:incoming?'مركز التسوية التشغيلية اليومية':b.accounts[0].id,to:incoming?b.accounts[0].id:'مركز التسوية التشغيلية اليومية',amount:settled,requestedAmount:requested,shortfall,carriedAdjustment:p.grossAmount===undefined?0:amount-(num(p.grossAmount)-num(p.deductions)),signedAmount:incoming?settled:-settled,netAmount:incoming?settled:-settled,note:String(p.note||`تسوية صافي رحلات اليوم ${day} · ${companyName(s,t)}`),purposeCategory:incoming?'وصول صافي التشغيل للحساب الجاري':'تسوية عجز تشغيل',purposeDetail:String(p.note||`صافي الحركة النقدية التشغيلية لليوم ${day}`),paymentMethod:'تسوية تشغيل يومية',company:t,kind:'daily-operating-settlement',label:incoming?'وصول صافي التشغيل للحساب الجاري':'تسوية عجز التشغيل',status:shortfall>0?'منفذة جزئيًا':'منفذة',accountBalanceBefore:balanceBefore,accountBalanceAfter:balanceAfter};
  const profile=collectionProfile(t,s);Object.assign(transfer,{collection:true,channel:profile.channel,service:profile.service,invoiceNumbers:(p.invoiceNumbers||[]).slice(0,20),grossAmount:num(p.grossAmount??Math.max(0,amount)),deductions:num(p.deductions),tripCount:Math.max(0,Math.floor(Number(p.tripCount)||0)),sourceRefs:[`TRIPS-${t}-${day}`]});if(incoming)transfer.from=profile.source;
  for(const number of transfer.invoiceNumbers){const doc=findFinanceDocument(s,'invoices','number',number,row=>row.company===t);if(doc&&doc.transferReference!==reference)amendInvoice(s,doc,'invoice-transfer-linked',row=>{row.transferReference=reference;});}
  protectDocument(s,transfer,'daily-operating-settlement');s.finance.dailySettlementDays={...settledDays,[t]:day};insertFinanceTransfer(s,{...transfer});if(settled>0){ledger(s,t,transfer);journal(s,t,transfer.note,incoming?[{account:b.accounts[0].id,debit:settled},{account:'مركز التسوية التشغيلية اليومية',credit:settled}]:[{account:'مركز التسوية التشغيلية اليومية',debit:settled},{account:b.accounts[0].id,credit:settled}],reference);}reconcile(s);const result={company:t,amount:incoming?settled:-settled,reference,accountId:b.accounts[0].id,idempotent:false,status:transfer.status,shortfall,balanceBefore,balanceAfter,documentProofId:transfer.documentProofId,contentDigest:transfer.contentDigest};assertAccountPosting(s,result,{company:t,reference,code:`daily-profit-current-account-mismatch:${t}`});return result;
}

function recordAssetFinance(s,p){
 const t=requireCompany(s,p.company),amount=num(p.amount),id=String(p.ref||'');
 if(!id||amount<=0)throw new Error('invalid-asset-finance');const prior=s.finance.debtRecords.find(row=>row.id===id);
 if(prior){if(prior.company!==t||Math.abs(prior.originalAmount-amount)>.01)throw new Error('asset-finance-reference-conflict');return debtView(s,prior);}
 const row={id,company:t,companyName:companyName(s,t),lender:String(p.lender||'مورد الأصل'),type:'تمويل أصل',liabilityAccount:'التزامات تمويل أصول',originalAmount:amount,outstanding:amount,amount,issuedAt:now(s),dueDay:null,status:'قائم',assetCatalogId:p.assetCatalogId||null,invoiceRef:p.invoiceRef||null};
 protectDocument(s,row,'asset-financing');s.finance.debtRecords.unshift(row);setDebtOutstanding(s,row,amount);book(s,t).debt+=amount;
 journal(s,t,'تمويل أصل من المورد',[{account:'أصول مشتراة بالتمويل',debit:amount},{account:row.liabilityAccount,credit:amount}],id);reconcile(s);return debtView(s,row);
}
function setDebt(s,p){
 const t=requireCompany(s,p.company),b=book(s,t),target=num(p.amount),delta=target-num(b.debt);
 if(delta>0){const id=`DEBT-ADJUST-${t}-${++s.finance.debtSettlementSequence}`,row={id,company:t,companyName:companyName(s,t),lender:'تعديل رصيد الدين',type:'تعديل رصيد',liabilityAccount:'التزامات تمويلية مرحّلة',originalAmount:delta,outstanding:delta,amount:delta,issuedAt:now(s),dueDay:null,status:'قائم'};protectDocument(s,row,'debt-adjustment');s.finance.debtRecords.unshift(row);setDebtOutstanding(s,row,delta);}
 else{let remaining=-delta;for(const row of s.finance.debtRecords.filter(x=>x.company===t&&debtOutstanding(s,x)>.005)){const opening=debtOutstanding(s,row),amount=Math.min(remaining,opening);if(amount>0)setDebtOutstanding(s,row,opening-amount);remaining-=amount;if(remaining<=0)break;}}
 b.debt=target;reconcile(s);return true;
}
// Compact annual ledger survives the 400-day UI window. Coverage is explicit.
const FINANCE_EPOCH=Date.UTC(2026,0,1),FINANCE_DAY=86400000;
function addAnnualReport(store,report,sign=1){
 const year=new Date(FINANCE_EPOCH+Number(report.day)*FINANCE_DAY).getUTCFullYear(),key=String(year);
 const summary=store[key]||(store[key]={year,days:[],companies:{}});
 if(sign>0&&!summary.days.includes(report.day))summary.days.push(report.day);
 for(const t of ['group',...Object.keys(report.companies||{})]){const input=t==='group'?report.group:report.companies?.[t];const row=summary.companies[t]||(summary.companies[t]={grossRevenue:0,expenses:0,net:0,tripCount:0});for(const field of ['grossRevenue','expenses','net','tripCount'])row[field]+=sign*(Number(field==='net'&&t==='group'?report.net:input?.[field])||0);}
 return summary;
}
function annualReports(s){
 if(!s.finance.annualCompanyReports||typeof s.finance.annualCompanyReports!=='object'||Array.isArray(s.finance.annualCompanyReports)){
  s.finance.annualCompanyReports={};const seen=new Set();for(const row of s.finance.dailyCompanyReports||[])if(!seen.has(row.day)){seen.add(row.day);addAnnualReport(s.finance.annualCompanyReports,row);}
 }
 return s.finance.annualCompanyReports;
}
function annualPerformance(s,t='group',year=2026){
 ensure(s);t=requireCompany(s,t);const summary=annualReports(s)[String(year)],row=summary?.companies?.[t]||{},reportedDays=summary?.days?.length||0,expectedDays=(Date.UTC(year+1,0,1)-Date.UTC(year,0,1))/FINANCE_DAY;
 return {grossRevenue:Number(row.grossRevenue)||0,expenses:Number(row.expenses)||0,net:Number(row.net)||0,tripCount:Number(row.tripCount)||0,reportedDays,expectedDays,complete:reportedDays===expectedDays};
}

function recordDailyClose(s,p){
  ensure(s);p=p&&typeof p==='object'&&!Array.isArray(p)?p:{};
  const sectors=companyMetricMap(s,p.sectors,'daily-close-sector'),rawNet=p.net===undefined?0:metricNumber(p.net,'daily-close-net','group'),rawDay=p.day===undefined?Math.floor(now(s)/86400):metricNumber(p.day,'daily-close-day','group'),day=Math.max(0,Math.floor(rawDay)),companies={},inputs=p.companies===undefined?{}:p.companies,ids=companyIds(s,{includeGroup:false}),allowed=new Set(ids);
  if(!inputs||typeof inputs!=='object'||Array.isArray(inputs))throw new Error('finance-daily-close-companies-map-invalid');
  for(const [id,row] of Object.entries(inputs))if(!allowed.has(id)){
    const fields=['grossRevenue','expenses','net','tripRevenue','operatingRevenue','tripCount'],legacyZero=row&&typeof row==='object'&&!Array.isArray(row)&&fields.every(field=>row[field]===undefined||Number.isFinite(Number(row[field]))&&Number(row[field])===0);
    if(legacyZero&&inactiveLegacyCompanyKey(s,id))continue;
    throw new Error(`finance-daily-close-company-unknown:${id}`);
  }
  for(const type of ids){
    const input=inputs[type]===undefined?{}:inputs[type];if(!input||typeof input!=='object'||Array.isArray(input))throw new Error(`finance-daily-close-company-invalid:${type}`);
    const value=(field,{nonNegative=false,integer=false,fallback=0}={})=>{const result=input[field]===undefined?fallback:metricNumber(input[field],`daily-close-${field}`,type);if(nonNegative&&result<0)throw new Error(`finance-daily-close-${field}-negative:${type}`);if(integer&&(!Number.isSafeInteger(result)||result<0))throw new Error(`finance-daily-close-${field}-not-integer:${type}`);return result;};
    const grossRevenue=value('grossRevenue',{nonNegative:true}),expenses=value('expenses',{nonNegative:true}),companyNet=value('net',{fallback:Number(sectors[type])||0});
    if((Object.prototype.hasOwnProperty.call(input,'grossRevenue')||Object.prototype.hasOwnProperty.call(input,'expenses'))&&Math.abs(grossRevenue-expenses-companyNet)>.01)throw new Error(`finance-daily-close-company-unbalanced:${type}`);
    if(p.sectors&&Object.prototype.hasOwnProperty.call(p.sectors,type)&&Math.abs(Number(sectors[type])-companyNet)>.01)throw new Error(`finance-daily-close-sector-mismatch:${type}`);
    companies[type]={grossRevenue,expenses,net:companyNet,tripRevenue:value('tripRevenue',{nonNegative:true}),operatingRevenue:value('operatingRevenue',{nonNegative:true}),tripCount:value('tripCount',{integer:true})};
  }
  const net=rawNet,companyTotals=Object.values(companies).reduce((out,row)=>{out.grossRevenue+=num(row.grossRevenue);out.expenses+=num(row.expenses);out.net+=Number(row.net)||0;out.tripCount+=Math.max(0,Number(row.tripCount)||0);return out;},{grossRevenue:0,expenses:0,net:0,tripCount:0}),groupOverhead=Math.max(0,companyTotals.net-net),groupRevenue=Math.max(0,net-companyTotals.net),closeFingerprint=JSON.stringify({day,net,sectors,companies}),report={id:`CLOSE-${day}`,day,at:now(s),net,sectors:{...sectors},companies,group:{grossRevenue:companyTotals.grossRevenue+groupRevenue,expenses:companyTotals.expenses+groupOverhead,net,tripCount:companyTotals.tripCount,overhead:groupOverhead,holdingRevenue:groupRevenue},closeFingerprint};
  const annual=annualReports(s),year=new Date(FINANCE_EPOCH+day*FINANCE_DAY).getUTCFullYear(),prior=s.finance.dailyCompanyReports.findIndex(row=>Number(row?.day)===day);
  if(prior>=0&&s.finance.dailyCompanyReports[prior].closeFingerprint===closeFingerprint)return clone(s.finance.dailyCompanyReports[prior]);
  if(prior>=0){addAnnualReport(annual,s.finance.dailyCompanyReports[prior],-1);s.finance.dailyCompanyReports.splice(prior,1);}
  else if(annual[String(year)]?.days?.includes(day))throw new Error('archived-daily-close-immutable');
  addAnnualReport(annual,report);
  s.finance.dailyCompanyReports.unshift(report);s.finance.dailyCompanyReports=s.finance.dailyCompanyReports.slice(0,400);
  s.lastClosedSectorProfit=sectors;s.lastClosedProfit=net;s.sectorProfitToday=zeroSectorMap(s);s.todayProfit=0;
  return report;
}

function performance(s,t='group',days=30){
  t=requireCompany(s,t);days=Math.max(1,Math.min(365,Math.floor(Number(days)||30)));const currentDay=Math.floor(now(s)/86400),rows=(Array.isArray(s?.finance?.dailyCompanyReports)?s.finance.dailyCompanyReports:[]).filter(row=>Number(row?.day)>currentDay-days&&Number(row?.day)<=currentDay);
  const aggregate=rows.reduce((out,row)=>{if(t==='group'){const x=row.group||{};out.grossRevenue+=num(x.grossRevenue);out.expenses+=num(x.expenses);out.net+=Number(row.net)||0;out.tripCount+=Math.max(0,Number(x.tripCount)||0);}else{const x=row.companies?.[t]||{};out.grossRevenue+=num(x.grossRevenue);out.expenses+=num(x.expenses);out.net+=Number(x.net)||0;out.tripCount+=Math.max(0,Number(x.tripCount)||0);}return out;},{grossRevenue:0,expenses:0,net:0,tripCount:0});
  const latest=rows[0],latestData=t==='group'?{grossRevenue:num(latest?.group?.grossRevenue),expenses:num(latest?.group?.expenses),net:Number(latest?.net)||0,tripCount:Math.max(0,Number(latest?.group?.tripCount)||0)}:{grossRevenue:num(latest?.companies?.[t]?.grossRevenue),expenses:num(latest?.companies?.[t]?.expenses),net:Number(latest?.companies?.[t]?.net)||0,tripCount:Math.max(0,Number(latest?.companies?.[t]?.tripCount)||0)};
  const currentNet=t==='group'?Number(s.todayProfit)||0:Number(s.sectorProfitToday?.[t])||0;
  return {company:t,days,reportedDays:rows.length,currentNet,lastDay:latest?.day??null,lastDayGross:latestData.grossRevenue,lastDayExpenses:latestData.expenses,lastDayNet:latestData.net,lastDayTrips:latestData.tripCount,grossRevenue:aggregate.grossRevenue,expenses:aggregate.expenses,net:aggregate.net,tripCount:aggregate.tripCount};
}

const CALENDAR_EPOCH_SECONDS=Date.UTC(2026,0,1)/1000;
function calendarMonthForDay(day){const date=new Date((CALENDAR_EPOCH_SECONDS+Math.max(0,Number(day)||0)*86400)*1000);return `${date.getUTCFullYear()}-${String(date.getUTCMonth()+1).padStart(2,'0')}`;}
function monthlyStatement(s,{months=12}={}){
  months=Math.max(1,Math.min(36,Math.floor(Number(months)||12)));const byMonth=new Map(),companyTypes=companyIds(s,{includeGroup:false});
  for(const report of Array.isArray(s?.finance?.dailyCompanyReports)?s.finance.dailyCompanyReports:[]){const key=calendarMonthForDay(report.day),month=byMonth.get(key)||{monthKey:key,days:new Set(),group:{income:0,expenses:0,net:0},companies:{}};month.days.add(Number(report.day));const group=report.group||{};month.group.income+=num(group.grossRevenue);month.group.expenses+=num(group.expenses);month.group.net+=Number(report.net)||0;for(const type of companyTypes){const source=report.companies?.[type]||{},row=month.companies[type]||(month.companies[type]={company:type,income:0,expenses:0,net:0});row.income+=num(source.grossRevenue);row.expenses+=num(source.expenses);row.net+=Number(source.net)||0;}byMonth.set(key,month);}
  const currentKey=calendarMonthForDay(Math.floor(now(s)/86400));if(!byMonth.has(currentKey))byMonth.set(currentKey,{monthKey:currentKey,days:new Set(),group:{income:0,expenses:0,net:0},companies:{}});
  return [...byMonth.values()].sort((a,b)=>b.monthKey.localeCompare(a.monthKey)).slice(0,months).map(month=>({monthKey:month.monthKey,reportedDays:month.days.size,income:month.group.income,expenses:month.group.expenses,net:month.group.net,deficit:Math.max(0,-month.group.net),surplus:Math.max(0,month.group.net),companies:companyTypes.map(type=>month.companies[type]||{company:type,income:0,expenses:0,net:0})}));
}

function applySimulationJournal(s,p={}){
  ensure(s);const j=p.journal===undefined?{}:p.journal;if(!j||typeof j!=='object'||Array.isArray(j))throw new Error('finance-simulation-journal-invalid');
  const types=companyIds(s,{includeGroup:false}),todayProfit=j.todayProfit===undefined?0:metricNumber(j.todayProfit,'simulation-today-profit','group'),sectorProfit=companyMetricMap(s,j.sectorProfit,'simulation-sector-profit'),tripProfit=companyMetricMap(s,j.tripProfit,'simulation-trip-profit'),tripRevenue=companyMetricMap(s,j.tripRevenue,'simulation-trip-revenue',{nonNegative:true}),tripFuel=companyMetricMap(s,j.tripFuel,'simulation-trip-fuel',{nonNegative:true}),tripMaintenance=companyMetricMap(s,j.tripMaintenance,'simulation-trip-maintenance',{nonNegative:true}),tripCount=companyMetricMap(s,j.tripCount,'simulation-trip-count',{integer:true}),cash=companyMetricMap(s,j.cash,'simulation-cash');
  s.todayProfit=(Number(s.todayProfit)||0)+todayProfit;
  for(const type of types){
    s.sectorProfitToday[type]+=sectorProfit[type];
    s.tripProfitAccrued[type]+=tripProfit[type];
    s.tripRevenueAccrued[type]+=tripRevenue[type];
    s.tripFuelAccrued[type]+=tripFuel[type];
    s.tripMaintenanceAccrued[type]+=tripMaintenance[type];
    s.tripCountAccrued[type]+=tripCount[type];
    if(cash[type])s.finance.pendingDailyCash[type]+=cash[type];
  }
  reconcile(s);return {todayProfit:Number(s.todayProfit)||0,cash:Number(s.cash)||0};
}
function initializeCapital(s,p){
 const capital=Number(p.capital);if(!Number.isFinite(capital)||capital<=0)throw new Error('invalid-initial-capital');
 if(s.finance?.foundingCapital)throw new Error('capital-already-initialized');
 const ref=String(p.ref||'');if(!ref)throw new Error('founding-capital-reference-required');
 s.companyFinance={};s.companyBudgets={};s.treasury={accounts:[],ledger:[],paymentQueue:[]};
 s.finance={invoices:[],cheques:[],payables:[],receivables:[],periods:[],journalEntries:[],transfers:[],payrollReports:[],taxSettlements:[],debtRecords:[],debtSettlements:[],debtBalancesById:{},debtBalanceMigrationVersion:1,intercompanyLoans:[],intercompanyLoanSettlements:[],cashPoolSweeps:[],commercialContracts:[],centralTreasury:{minOperatingCash:{},lastPolicyAt:0,lastSweepAt:0},paymentSequence:1,invoiceSequence:1,taxSettlementSequence:1,debtSettlementSequence:1,journalSequence:0,taxPayable:0,taxPaid:0};
 invalidateFinanceLookupIndexes();ensure(s);if(activeEnsureTarget===s)activeEnsureComplete=true;s.advanced=s.advanced||{};if(s.advanced.treasury)s.advanced.treasury.liquidityBuffer=0;
 const result=founderInvestment(s,{company:'group',amount:capital,ref,note:'رأس المال عند تأسيس المجموعة'});
 s.finance.foundingCapital={ref,amount:capital};return result;
}
function closeVatPeriod(s,p={}){
 const day=Math.max(0,Math.floor(Number.isFinite(Number(p.day))?Number(p.day):Math.floor(now(s)/86400))),periodKey=calendarMonthForDay(day),rows=[];
 for(const t of companyIds(s)){const b=book(s,t),vat=b.vat||(b.vat={output:0,input:0,creditCarry:0,periodOutputStart:0,periodInputStart:0}),id=`TAX-${t}-${periodKey}`,existing=findFinanceDocument(s,'periods','id',id);if(existing){if(Math.abs(num(existing.outputEnd)-num(vat.output))>.01||Math.abs(num(existing.inputEnd)-num(vat.input))>.01)throw new Error(`vat-period-already-closed:${id}`);rows.push(clone(existing));refreshBookTaxPayable(s,t);continue;}const deltaOutput=cents(Math.max(0,num(vat.output)-num(vat.periodOutputStart))),deltaInput=cents(Math.max(0,num(vat.input)-num(vat.periodInputStart))),openingCredit=cents(num(vat.creditCarry)),net=cents(deltaOutput-deltaInput-openingCredit),periodTax=Math.max(0,net),closingCredit=Math.max(0,-net),outputEnd=num(vat.output),inputEnd=num(vat.input),fingerprint=JSON.stringify([t,periodKey,deltaOutput,deltaInput,openingCredit,closingCredit,periodTax,outputEnd,inputEnd]);vat.creditCarry=closingCredit;vat.periodOutputStart=outputEnd;vat.periodInputStart=inputEnd;const row={id,company:t,companyName:companyName(s,t),periodKey,period:`الفترة الضريبية ${periodKey}`,outputVAT:deltaOutput,inputVAT:deltaInput,openingCredit,closingCredit,amount:periodTax,outputEnd,inputEnd,dueDay:day+15,status:periodTax>0?'مستحق':'صفر',closeFingerprint:fingerprint,closedAt:now(s)};protectDocument(s,row,'vat-assessment');insertFinanceRow(s,'periods',row);rows.push(row);refreshBookTaxPayable(s,t);}
 reconcile(s);return rows;
}
// Build 358: fleet purchases are zero-rated (procurement-core). Purchases saved before carried 15% input VAT, and the
// credit could exceed months of output VAT on trips, so the tax stayed zero. On load that input VAT is reversed once, per
// company: purchases after the company's last close from the open period, earlier ones from the credit still carried,
// never more than either holds (credit already set against output VAT stays). Cash and documents are unchanged; a
// reclassification journal entry records the amount, and the save is marked so this never runs twice.
const FLEET_PURCHASE_NOTE=/^(?:شراء|دفعة إيجار) \d+ × /;
function zeroRateFleetPurchaseVat(s){
 const f=s?.finance;if(!f||typeof f!=='object'||f.fleetPurchaseVat==='zero-rated')return null;
 const books=s.companyFinance&&typeof s.companyFinance==='object'?s.companyFinance:{},lastClose=new Map(),taxed=new Map(),seen=new Set();
 for(const rows of [f.periods,f.auditArchive?.records?.taxPeriods])for(const row of Array.isArray(rows)?rows:[])if(row?.company&&!row.legacy&&Number.isFinite(Number(row.closedAt)))lastClose.set(row.company,Math.max(lastClose.get(row.company)??-Infinity,Number(row.closedAt)));
 for(const rows of [f.invoices,f.auditArchive?.records?.invoices])for(const row of Array.isArray(rows)?rows:[]){
  const tax=Number(row?.tax);if(!row||row.kind!=='مصروف'||!(tax>0)||!FLEET_PURCHASE_NOTE.test(String(row.note||''))||seen.has(row.number))continue;seen.add(row.number);
  const sum=taxed.get(row.company)||{open:0,closed:0};if(Number(row.at)>(lastClose.get(row.company)??-Infinity))sum.open+=tax;else sum.closed+=tax;taxed.set(row.company,sum);
 }
 // A save without taxed fleet purchases (every game since this build) is left untouched, so save and reload stay exact.
 if(!taxed.size)return null;
 const adjusted={};
 for(const [company,sum] of taxed){
  const b=books[company],vat=b?.vat;if(!vat||typeof vat!=='object')continue;
  const open=Math.min(sum.open,Math.max(0,num(vat.input)-num(vat.periodInputStart))),closed=Math.min(sum.closed,Math.max(0,num(vat.creditCarry))),amount=open+closed;if(!(amount>0))continue;
  vat.input=num(vat.input)-open;vat.creditCarry=num(vat.creditCarry)-closed;
  b.taxAccrued=Math.max(0,(num(vat.output)-num(vat.periodOutputStart))-(num(vat.input)-num(vat.periodInputStart))-num(vat.creditCarry));
  if(Array.isArray(f.journalEntries)&&Number.isSafeInteger(Number(f.journalSequence))){const sequence=f.journalSequence=Number(f.journalSequence)+1;f.journalEntries.unshift({id:`JE-${String(sequence).padStart(8,'0')}`,company,description:'إعادة تصنيف ضريبة مدخلات شراء الأسطول (توريد معفى بنسبة صفر)',lines:[{account:'مصروف تشغيلي',debit:amount,credit:0},{account:'ضريبة مدخلات VAT',debit:0,credit:amount}],sourceRef:`VAT-FLEET-ZERO-${company}`,at:now(s)});}
  adjusted[company]={open,closed,amount};
 }
 f.fleetPurchaseVat='zero-rated';if(Object.keys(adjusted).length)f.fleetPurchaseVatAdjustment={at:now(s),companies:adjusted};
 return adjusted;
}
function execute(ctx,cmd,p={},meta={}){
 const s=ctx.state||ctx,previousMeta=activeExecutionMeta,previousEnsureTarget=activeEnsureTarget,previousEnsureComplete=activeEnsureComplete;
 invalidateSettlementBatch(s,'finance',String(cmd));activeExecutionMeta={...meta,name:cmd};activeEnsureTarget=s;activeEnsureComplete=false;
 try{
  // Capital initialization replaces the finance roots, so its own ensure must be
  // the first one in this command and must invalidate any transaction memo indexes.
  if(cmd==='initialize-capital')return initializeCapital(s,p);
  ensure(s);activeEnsureComplete=true;
  switch(cmd){
   case'ensure':return ensure(s);
   case'hospitality-accounting':{
    const owner=globalThis.GH_HOSPITALITY_FINANCE;if(!owner?.execute)throw new Error('hospitality-finance-owner-missing');
    return owner.execute(s,p.action,p,{book,now,invoice,journal,ledger,protectDocument,refreshBookTaxPayable,reconcile,collectReceivable,postCustomerInvoicePayment,findFinanceDocument,notePnl});
   }
	   case'issue-invoice':return issueInvoice(s,p);
	   case'register-commercial-contract':return registerCommercialContract(s,p);
	   case'update-commercial-contract-status':return updateCommercialContractStatus(s,p);
   case'spend':return spend(s,p);
   case'pay-by-cheque':return payByCheque(s,p);
   case'pay-payroll':return payPayroll(s,p);
   case'accrue-payroll':return accruePayroll(s,p);
   case'record-payroll-report':return recordPayrollReport(s,p);
   case'accrue-expense':return accrue(s,p);
   case'credit':return credit(s,p);
   case'transfer':return transfer(s,p);
   case'receive-customer-loan-payment':return receiveCustomerLoanPayment(s,p);
   case'receive-customer-sale-payment':return receiveCustomerSalePayment(s,p);
   case'cancel-customer-sale-invoice':return cancelCustomerSaleInvoice(s,p);
   case'disburse-customer-loan-to-sale':return disburseCustomerLoanToSale(s,p);
   case'settle-intercompany-interest':return settleIntercompanyInterest(s,p);
   case'settle-intercompany-supply':return settleIntercompanySupply(s,p);
	   case'settle-intercompany-service':return settleIntercompanyService(s,p);
	   case'settle-insurance-claims':return settleInsuranceClaims(s,p);
   case'bulk-transfer':return bulkTransfer(s,p);
   case'set-central-treasury-policy':return setCentralTreasuryPolicy(s,p);
   case'cash-pool-sweep':return cashPoolSweep(s,p);
   case'issue-intercompany-loan':return issueIntercompanyLoan(s,p);
   case'repay-intercompany-loan':return repayIntercompanyLoan(s,p);
   case'transfer-reserve':return transferReserve(s,p);
   case'collect-receivable':return collectReceivable(s,p);
   case'collect-receivables-by-cheque':return collectReceivablesByCheque(s,p);
   case'settle-payable':return settlePayable(s,p);
   case'settle-due-terms':return settleDueTerms(s,p);
   case'pay-taxes':return payTaxes(s,p);
   case'issue-cheque':return issueCheque(s,p);
   case'settle-cheque':return settleCheque(s,p);
   case'founder-investment':return founderInvestment(s,p);
   case'founder-withdrawal':return founderWithdrawal(s,p);
   case'set-budget':{const b=mutableBudget(s,p.company),limit=num(p.limit),lines={...b.lines,...(p.lines||{})};if(!p.resetSpent){if(limit>0&&limit<b.spent+b.reserved)throw new Error('budget-below-month-spend');for(const [line,value] of Object.entries(lines))if(num(value)>0&&num(value)<num(b.spentByLine[line])+num(b.reservedByLine[line]))throw new Error(`budget-line-below-month-spend:${line}`);}b.limit=limit;b.enabled=b.limit>0;b.lines=lines;if(p.resetSpent){b.spent=0;b.reserved=0;b.spentByLine={};b.reservedByLine={};}return clone(b);}
   case'reset-budget':{const b=mutableBudget(s,p.company);b.limit=0;b.spent=0;b.reserved=0;b.enabled=false;b.lines={};b.spentByLine={};b.reservedByLine={};return clone(b);}
   case'refresh-identity':return refreshIdentity(s,p);
   case'raise-debt':return raiseDebt(s,p);
   case'accrue-debt-interest':return accrueDebtInterest(s,p);
   case'raise-equity':return raiseEquity(s,p);
   case'settle-market-security-trade':return settleMarketSecurityTrade(s,p);
   case'settle-market-security-dividend':return settleMarketDividend(s,p);
   case'repay-debt':return repayDebt(s,p);
   case'set-debt':return setDebt(s,p);
   case'record-asset-finance':return recordAssetFinance(s,p);
   case'consume-trip-accruals':return consumeTripAccruals(s);
   case'settle-daily-cash':return settleDailyCash(s,p);
   case'apply-simulation-journal':return applySimulationJournal(s,p);
   case'record-daily-close':return recordDailyClose(s,p);
   case'close-vat-period':return closeVatPeriod(s,p);
   default:throw new Error(`Unknown finance command: ${cmd}`);
  }
 }finally{activeExecutionMeta=previousMeta;activeEnsureTarget=previousEnsureTarget;activeEnsureComplete=previousEnsureComplete;}
}
// Build 358 (save size): the finance audit archive (finance.auditArchive.records, filled by the daily compaction) holds
// copies made when rows leave the live lists; they are never edited afterwards (a migration replaces a row, never edits
// it). Its collections are sealed: a save reuses the text (and vault chunk) of every unchanged archive part, and durable
// drafts and rollback snapshots share the rows instead of copying the whole archive.
// Build 359: its writers replace a collection (the daily compaction appends into a new array, a seal round filters into
// one): each is sealed whole once its rows are (a container), so commands share it without walking it.
(globalThis.GH_TRANSACTION_CORE?.registerSealedCollections||((root,keys,options)=>(globalThis.__GH_PENDING_SEALED_COLLECTIONS__=globalThis.__GH_PENDING_SEALED_COLLECTIONS__||[]).push([root,keys,options])))('finance',['auditArchive.records.*'],{container:true});
// Build 359 (iPhone: each player command copied the live documents, 9 MB of 30k-asset finance, and the save re-encoded
// them): a live document seals once it is final, the state no business rule edits again (the daily compaction's
// archive rule): a settled invoice, a cashed or cancelled cheque, an executed transfer, a paid or zero VAT period, a
// repaid debt, a fully paid payroll report, every tax and debt settlement. Drafts and snapshots share sealed documents,
// the save reuses their text, and validation trusts a sealed document it verified once. An open document stays an
// ordinary row until it is final; an amendment of a sealed document is refused (GH_DOCUMENT_PROOF.amendDocument), and a
// migration that rewrites one replaces it (writableRow).
const SETTLED_INVOICE=new Set(['مدفوعة','مسددة','محصلة','ملغاة']),FINAL_CHEQUE=new Set(['مصروف','محصل','ملغى']),FINAL_TRANSFER=new Set(['منفذة','مسددة','ملغى','ملغاة']),FINAL_PERIOD=new Set(['مسدد','مسددة','صفر']);
const FINAL_DOCUMENT=Object.freeze({
 hospitalityDocuments:()=>true,
 invoices:row=>SETTLED_INVOICE.has(row?.status),
 cheques:row=>FINAL_CHEQUE.has(row?.status),
 transfers:row=>FINAL_TRANSFER.has(row?.status),
 periods:row=>FINAL_PERIOD.has(row?.status),
 debtRecords:row=>row?.status==='مسدد'&&!(Number(row.outstanding)>0),
 payrollReports:row=>row?.status==='مصروف بالكامل'&&!(Number(row.due)>0),
 taxSettlements:()=>true,
 debtSettlements:()=>true
});
// The ledgers are appended to and never edited (a refresh of a legacy entry replaces it, writableRow): the journal, each
// company's ledger and the treasury ledger are sealed whole.
for(const [root,keys] of [['finance',['journalEntries']],['companyFinance',['*.ledger']],['treasury',['ledger']]])(globalThis.GH_TRANSACTION_CORE?.registerSealedCollections||((root,keys)=>(globalThis.__GH_PENDING_SEALED_COLLECTIONS__=globalThis.__GH_PENDING_SEALED_COLLECTIONS__||[]).push([root,keys])))(root,keys);
for(const [bucket,member] of Object.entries(FINAL_DOCUMENT))(globalThis.GH_TRANSACTION_CORE?.registerSealedCollections||((root,keys,options)=>(globalThis.__GH_PENDING_SEALED_COLLECTIONS__=globalThis.__GH_PENDING_SEALED_COLLECTIONS__||[]).push([root,keys,options])))('finance',[bucket],{member});
const API={VERSION,withSettlementBatch,invalidateSettlementBatch,assertAccountPosting,companyTaxNumber,invoiceTaxProfile,takeOffClosePnl,invalidateLookupIndexes:invalidateFinanceLookupIndexes,findArchivedDocument,RATING_SPREAD,floatingDebtRate,fixedDebtQuote,debtRate,interestBearing,debtOutstanding,debtStatus,debtView,adjustDebtOutstanding,reconcileDebtBalances,transferBankFacility,payableChequeBlocker,chequeFundingBlocker,zeroRateFleetPurchaseVat,FLEET_PURCHASE_NOTE,COMPANY_METRIC_KEYSPACE:'company-instance-id/v1',annualPerformance,TYPES,companyIds,supportsCompany,requireCompany,companyMetricMap,collectionProfile,ensure,makeBook,book,operating,total,budget,remaining,lineRemaining,lineFor,canSpend,consumeBudget,reserveBudget,consumeReserved,releaseReserved,reconcile,journal,invoice,issueInvoice,payByCheque,performance,monthlyStatement,calendarMonthForDay,centralTreasuryPolicy,intercompanyLoanSnapshot,closeVatPeriod,withCollectionBatch,execute};globalThis.GH_FINANCE_CORE=API;globalThis.GH_DOMAIN_COMMANDS?.register?.('finance',API);if(globalThis.window&&window!==globalThis)window.GH_FINANCE_CORE=API;if(typeof module!=='undefined'&&module.exports)module.exports=API;
})();
